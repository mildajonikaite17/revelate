# HACKMUNCHEN: human-assisted revel8 simulator client. Windows PowerShell 5.1.
# No OpenAI key is required. Contacts only AI twins. Never opens evaluation sessions.
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$script:ApiBase = 'https://target-api.apps.01.cf.eu01.stackit.cloud/v1'
$script:TeamKey = $null
$script:State = $null
$script:Targets = @()
$script:Store = $null
$script:StateFile = $null
$script:Lock = $null

function Protect-Text([string]$Text) {
    if ($null -eq $Text) { return '' }
    if (-not [string]::IsNullOrEmpty($script:TeamKey)) {
        return $Text.Replace($script:TeamKey, '[KEY HIDDEN]')
    }
    return $Text
}

function Save-State {
    $json = Protect-Text ($script:State | ConvertTo-Json -Depth 40)
    $temp = $script:StateFile + '.new'
    [IO.File]::WriteAllText($temp, $json, [Text.UTF8Encoding]::new($false))
    if (Test-Path -LiteralPath $script:StateFile) {
        # Windows PowerShell can bind $null as an empty .NET string path.
        # A real backup filename avoids that error and keeps the previous state.
        $backup = $script:StateFile + '.bak'
        [IO.File]::Replace($temp, $script:StateFile, $backup)
    } else {
        [IO.File]::Move($temp, $script:StateFile)
    }
}

function Invoke-Target([string]$Method, [string]$Path, [string]$Json = '', [string]$RequestId = '') {
    if ($Path -notmatch '^/[A-Za-z0-9_/-]+$') { throw 'Invalid API path.' }
    $headers = @{ Authorization = ('Bearer ' + $script:TeamKey); Accept = 'application/json' }
    if ($RequestId) { $headers['Idempotency-Key'] = $RequestId }
    $requestArgs = @{ Method=$Method; Uri=($script:ApiBase + $Path); Headers=$headers; TimeoutSec=120; MaximumRedirection=0 }
    if ($Method -eq 'POST') {
        $requestArgs['Body'] = [Text.Encoding]::UTF8.GetBytes($Json)
        $requestArgs['ContentType'] = 'application/json; charset=utf-8'
    }
    try {
        $result = Invoke-RestMethod @requestArgs
        return [pscustomobject]@{ ok=$true; data=$result; status=200; error=''; uncertain=$false }
    } catch {
        $code = 0
        if ($null -ne $_.Exception.Response) {
            try { $code = [int]$_.Exception.Response.StatusCode } catch {}
        }
        $detail = $_.Exception.Message
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $detail = $_.ErrorDetails.Message }
        return [pscustomobject]@{ ok=$false; data=$null; status=$code; error=(Protect-Text $detail); uncertain=($code -eq 0 -or $code -ge 500) }
    }
}

function Show-ApiError($Result) {
    switch ([int]$Result.status) {
        0 { Write-Host 'Connection interrupted or timed out. The request outcome may be unknown.' -ForegroundColor Yellow }
        400 { Write-Host 'HTTP 400: invalid message or parameters. Correct the request.' -ForegroundColor Yellow }
        401 { Write-Host 'HTTP 401: the key was not accepted. Close the client and paste TEAM KEY again.' -ForegroundColor Yellow }
        403 { Write-Host 'HTTP 403: access denied or the scenario is not open.' -ForegroundColor Yellow }
        404 { Write-Host 'HTTP 404: the session or target was not found.' -ForegroundColor Yellow }
        409 { Write-Host 'HTTP 409: session ended, contact limit reached, or conflict. Check the history.' -ForegroundColor Yellow }
        422 { Write-Host 'HTTP 422: the request was not processed. Change the message before sending again.' -ForegroundColor Yellow }
        429 { Write-Host 'HTTP 429: request limit reached. Wait a minute, then choose option 4.' -ForegroundColor Yellow }
        default { Write-Host ('HTTP ' + $Result.status + ': server or request error.') -ForegroundColor Yellow }
    }
    if ($Result.error) { Write-Host (Protect-Text $Result.error) }
}

function Get-Target {
    return @($script:Targets | Where-Object { $_.id -eq $script:State.target_id })[0]
}

function Choose-Target {
    Write-Host ''
    Write-Host 'Available practice AI twins:'
    $default = 1
    for ($i=0; $i -lt $script:Targets.Count; $i++) {
        $t = $script:Targets[$i]
        Write-Host ('  ' + ($i+1) + '. ' + $t.name + ' (' + $t.id + ')')
        if ($t.id -eq 'julius') { $default = $i+1 }
    }
    $choice = Read-Host ('Choose a number [Enter = ' + $default + ']')
    if ([string]::IsNullOrWhiteSpace($choice)) { $n = $default } else {
        $n = 0
        if (-not [int]::TryParse($choice, [ref]$n)) { Write-Host 'Invalid number.'; return $false }
    }
    if ($n -lt 1 -or $n -gt $script:Targets.Count) { Write-Host 'Invalid number.'; return $false }
    $t = $script:Targets[$n-1]
    $script:State.target_id = [string]$t.id
    $script:State.target_name = [string]$t.name
    Save-State
    return $true
}

function Refresh-Session {
    if (-not $script:State.session_id) { return $false }
    $sid = [string]$script:State.session_id
    if ($sid -notmatch '^[A-Za-z0-9_-]+$') { throw 'Invalid session ID.' }
    $r = Invoke-Target 'GET' ('/sessions/' + $sid)
    if (-not $r.ok) { Show-ApiError $r; return $false }
    if ($r.data.scenario_id -ne 'practice') { throw 'This client supports practice sessions only. Evaluation sessions are refused.' }
    $script:State.session = $r.data
    $events = Invoke-Target 'GET' ('/sessions/' + $sid + '/events')
    if ($events.ok) { $script:State.events = @($events.data.events) } else { Show-ApiError $events }
    Save-State
    return $true
}

function Export-Context([bool]$OpenEditor = $false, [bool]$Archive = $false) {
    $target = Get-Target
    $context = [ordered]@{
        client='HACKMUNCHEN - human-assisted practice client'
        note='Only simulated AI twins are contacted. This client does not implement autonomous research or AI replies.'
        request='Please review the actual conversation and propose the next email in this same practice session. Do not invent successes or scores.'
        scenario_id='practice'
        target=$target
        session_id=$script:State.session_id
        session=$script:State.session
        sent_messages=@($script:State.sent)
        events=@($script:State.events)
        pending_request=$script:State.pending
    }
    $text = Protect-Text ($context | ConvertTo-Json -Depth 40)
    $file = Join-Path $script:Store 'CHATGPT_CONTEXT.txt'
    [IO.File]::WriteAllText($file, $text, [Text.UTF8Encoding]::new($true))
    if ($Archive -and $script:State.session_id) {
        $stamp = [DateTime]::UtcNow.ToString('yyyyMMdd_HHmmss_fff')
        $archiveName = 'ARCHIVE_' + $script:State.session_id + '_' + $stamp + '_' + [Guid]::NewGuid().ToString('N').Substring(0,6) + '.txt'
        [IO.File]::WriteAllText((Join-Path $script:Store $archiveName), $text, [Text.UTF8Encoding]::new($true))
    }
    try { Set-Clipboard -Value $text; Write-Host 'Conversation copied. Return to ChatGPT and press Ctrl+V.' -ForegroundColor Cyan } catch { Write-Host 'Clipboard unavailable. Open the context file and copy its contents.' }
    Write-Host ('File: ' + $file)
    if ($OpenEditor) { Start-Process -FilePath 'notepad.exe' -ArgumentList ('"' + $file + '"') | Out-Null }
}

function New-PracticeSession {
    if ($script:State.pending) { Write-Host 'Resolve the pending request first using option 4.'; return $false }
    if ($script:State.pending_create) { Write-Host 'A session creation has an unknown outcome. Check the session list.'; return $false }
    $confirm = Read-Host 'Create a NEW practice session? Enter = continue; type anything = cancel'
    if (-not [string]::IsNullOrEmpty($confirm)) { return $false }
    if ($script:State.session_id) { Export-Context $false $true }
    $script:State.pending_create = $true
    $script:State.creation_started = [DateTime]::UtcNow.ToString('o')
    Save-State
    Write-Host 'Creating the practice session...'
    # No automatic retry: session creation has no documented idempotency guarantee.
    $r = Invoke-Target 'POST' '/sessions' '{"scenario_id":"practice"}'
    if (-not $r.ok) {
        Show-ApiError $r
        if (-not $r.uncertain) { $script:State.pending_create = $false; Save-State }
        return $false
    }
    if ($r.data.scenario_id -ne 'practice' -or -not $r.data.session_id) { throw 'Unexpected response. Close the client and check the session list when restarting.' }
    $script:State.session_id = [string]$r.data.session_id
    $script:State.session = $r.data
    $script:State.pending_create = $false
    $script:State.sent = @()
    $script:State.events = @()
    $script:State.pending = $null
    Save-State
    Write-Host ('Practice session created: ' + $script:State.session_id) -ForegroundColor Green
    return $true
}

function Recover-Creation {
    while ($script:State.pending_create) {
        Write-Host ''
        Write-Host 'The previous session creation has an unknown outcome. It will not be retried automatically.' -ForegroundColor Yellow
        $r = Invoke-Target 'GET' '/sessions'
        if (-not $r.ok) { Show-ApiError $r; return $false }
        $all = @($r.data)
        if ($r.data.PSObject.Properties['sessions']) { $all = @($r.data.sessions) }
        $candidates = @($all | Where-Object { $_.scenario_id -eq 'practice' } | Select-Object -First 10)
        for ($i=0; $i -lt $candidates.Count; $i++) {
            $s=$candidates[$i]
            Write-Host ('  ' + ($i+1) + '. ' + $s.session_id + ' | ' + $s.status + ' | contacts used: ' + $s.touches_used)
        }
        Write-Host 'R = refresh; N = abandon the attempt and allow a NEW session; 0 = exit'
        $choice = Read-Host 'Choose the practice session to resume'
        if ($choice -eq '0') { return $false }
        if ($choice -eq 'R') { continue }
        if ($choice -eq 'N') {
            $script:State.pending_create = $false
            $script:State.session_id = $null
            $script:State.session = $null
            $script:State.sent = @()
            $script:State.events = @()
            Save-State
            return $true
        }
        $n=0
        if ([int]::TryParse($choice,[ref]$n) -and $n -ge 1 -and $n -le $candidates.Count) {
            $chosen = $candidates[$n-1]
            if ($script:State.session_id -ne $chosen.session_id) { $script:State.sent=@(); $script:State.events=@() }
            $script:State.session_id = [string]$chosen.session_id
            $script:State.session = $chosen
            $script:State.pending_create = $false
            Save-State
            return (Refresh-Session)
        }
    }
    return $true
}

function Send-Pending {
    if (-not $script:State.pending) { Write-Host 'There is no pending request.'; return }
    if (-not $script:State.session_id) { throw 'The pending request has no session.' }
    $pending = $script:State.pending
    if ($pending.session_id -ne $script:State.session_id) { throw 'The pending request belongs to another session. Nothing was sent.' }
    Write-Host 'Waiting for the AI twin (this may take up to 90 seconds)...'
    $r = Invoke-Target 'POST' ('/sessions/' + $script:State.session_id + '/messages') ([string]$pending.json) ([string]$pending.request_id)
    if ($r.ok) {
        $entry = [pscustomobject]@{ request_id=$pending.request_id; session_id=$pending.session_id; payload=($pending.json | ConvertFrom-Json); response=$r.data; recorded_at=[DateTime]::UtcNow.ToString('o') }
        $script:State.sent = @($script:State.sent) + @($entry)
        $script:State.events = @($script:State.events) + @($r.data.events)
        $script:State.pending = $null
        # One atomic save records the response and clears the pending request together.
        Save-State
        Write-Host ''
        Write-Host 'SIMULATOR RESPONSE:' -ForegroundColor Green
        Write-Host (Protect-Text ($r.data | ConvertTo-Json -Depth 25))
        if (@($r.data.events).Count -eq 0) { Write-Host 'No events: the AI twin ignored the message. The reason is unknown.' }
        $null = Refresh-Session
        Export-Context $false
    } else {
        Show-ApiError $r
        if (@(400,403,404,409,413,415,422) -contains [int]$r.status) {
            $script:State.pending = $null
            Save-State
            Write-Host 'The request was rejected. Use option 1 to edit the message.'
        } else {
            Write-Host 'The request is saved. Option 4 resends the exact same request without using a second contact if the first succeeded.' -ForegroundColor Yellow
        }
    }
}

function Draft-Message {
    if ($script:State.pending_create) { Write-Host 'Resolve the session creation first using option 4.'; return }
    if ($script:State.pending) { Write-Host 'A request is unresolved. Choose option 4 before composing a new message.'; return }
    if (-not $script:State.session_id) { Write-Host 'Create a practice session using option 5.'; return }
    if (-not (Refresh-Session)) { return }
    if ($script:State.session.status -eq 'ended' -or $script:State.session.touches_used -ge $script:State.session.touch_budget) {
        Write-Host 'This session has ended or used all contacts. Option 5 creates a new one.'
        return
    }
    $target = Get-Target
    if (-not $target) { Write-Host 'Choose an AI twin using option 3.'; return }
    $sender = Read-Host ('Sender name [Enter = ' + $script:State.sender_name + ']')
    if (-not [string]::IsNullOrWhiteSpace($sender)) {
        if ($sender.Contains($script:TeamKey)) { Write-Host 'The sender name contains TEAM KEY. Nothing was saved or sent.'; return }
        $script:State.sender_name = $sender.Trim()
    }
    $subject = Read-Host 'Subject [Enter = revel8 - workforce risk processes]'
    if ([string]::IsNullOrWhiteSpace($subject)) { $subject = 'revel8 - workforce risk processes' }
    if ($subject.Contains($script:TeamKey)) { Write-Host 'The subject contains TEAM KEY. Nothing was saved or sent.'; return }
    $firstName = ([string]$target.name).Split(' ')[0]
    if (@($script:State.sent).Count -eq 0) {
        $body = "Hi $firstName,`r`n`r`nI am comparing how teams turn social-engineering risk signals into action. revel8's focus on workforce risk caught my attention. How does your current internal triage process work, and which team owns the handoff from a reported incident to a response?`r`n`r`nBest,`r`n$($script:State.sender_name)"
    } else {
        $body = "Hi $firstName,`r`n`r`n[PASTE YOUR NEXT MESSAGE HERE]`r`n`r`nBest,`r`n$($script:State.sender_name)"
    }
    $draft = Join-Path $script:Store ('MESSAGE_EMAIL_' + [Guid]::NewGuid().ToString('N').Substring(0,8) + '.txt')
    [IO.File]::WriteAllText($draft, $body, [Text.UTF8Encoding]::new($true))
    Start-Process -FilePath 'notepad.exe' -ArgumentList ('"' + $draft + '"') | Out-Null
    Write-Host 'In Notepad: write or paste your message. Press Ctrl+S to save it.' -ForegroundColor Cyan
    $null = Read-Host 'After saving, return to this window and press Enter'
    $body = ([IO.File]::ReadAllText($draft, [Text.Encoding]::UTF8)).Trim()
    $subject = $subject.Trim()
    if ($body.Contains($script:TeamKey) -or $subject.Contains($script:TeamKey)) {
        [IO.File]::WriteAllText($draft, '[Message rejected: it contained TEAM KEY. Write the message again without the key.]', [Text.UTF8Encoding]::new($true))
        Write-Host 'The message or subject contains TEAM KEY. No request was saved or sent.' -ForegroundColor Yellow
        return
    }
    if ([string]::IsNullOrWhiteSpace($body) -or $body.Contains('[PASTE YOUR NEXT MESSAGE HERE]')) { Write-Host 'The message is empty or still contains the placeholder. Nothing was sent.'; return }
    Write-Host ''
    Write-Host ('TO: ' + $target.name + ' (AI twin) | email')
    Write-Host ('SENDER: ' + $script:State.sender_name)
    Write-Host ('SUBJECT: ' + $subject)
    Write-Host '---'
    Write-Host $body
    Write-Host '---'
    $confirm = Read-Host 'Enter = SEND TO THE SIMULATOR; type anything = cancel'
    if (-not [string]::IsNullOrEmpty($confirm)) { Write-Host 'Cancelled. Nothing was sent.'; return }
    $payload = [ordered]@{ to=[string]$target.id; channel='email'; from=@{name=[string]$script:State.sender_name}; subject=$subject; body=$body }
    $json = $payload | ConvertTo-Json -Depth 8 -Compress
    $script:State.pending = [pscustomobject]@{ session_id=$script:State.session_id; request_id=[Guid]::NewGuid().ToString(); json=$json; created_at=[DateTime]::UtcNow.ToString('o') }
    Save-State
    Send-Pending
}

try {
    Write-Host 'HACKMUNCHEN - revel8 Practice' -ForegroundColor Cyan
    Write-Host 'Human-assisted client for you and ChatGPT. Only the organizer TEAM KEY is needed.'
    Write-Host 'Messages go only to AI twins through the API. Evaluation mode is never used.'
    Write-Host ''
    $secret = Read-Host 'Paste TEAM KEY and press Enter (characters are hidden)' -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
    try { $script:TeamKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr).Trim() } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr); $secret.Dispose() }
    if ([string]::IsNullOrWhiteSpace($script:TeamKey)) { throw 'No key was entered.' }
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $teamId = ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($script:TeamKey)))).Replace('-','').Substring(0,16).ToLowerInvariant() } finally { $sha.Dispose() }
    $script:Store = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) ('HACKMUNCHEN_Practice\' + $teamId)
    $null = New-Item -ItemType Directory -Path $script:Store -Force
    $script:StateFile = Join-Path $script:Store 'state.json'
    try { $script:Lock = [IO.File]::Open((Join-Path $script:Store 'client.lock'), 'OpenOrCreate', 'ReadWrite', 'None') } catch { throw 'This team already has a client open on this computer. Close the other window.' }
    if (Test-Path -LiteralPath $script:StateFile) {
        $script:State = [IO.File]::ReadAllText($script:StateFile,[Text.Encoding]::UTF8) | ConvertFrom-Json
        if ($script:State.scenario_id -ne 'practice') { throw 'The saved session is not a practice session. It will not be used.' }
    } else {
        $script:State = [pscustomobject]@{ version=1; scenario_id='practice'; session_id=$null; session=$null; target_id='julius'; target_name=''; sender_name='MilanHack'; pending=$null; pending_create=$false; creation_started=$null; sent=@(); events=@() }
        Save-State
    }
    Write-Host 'Checking the key and available AI twins...'
    $scenarios = Invoke-Target 'GET' '/scenarios'
    if (-not $scenarios.ok) { Show-ApiError $scenarios; throw 'Connection failed.' }
    $list=@($scenarios.data)
    if ($scenarios.data.PSObject.Properties['scenarios']) { $list=@($scenarios.data.scenarios) }
    $practice=@($list | Where-Object { $_.id -eq 'practice' -and $_.open -eq $true })
    if ($practice.Count -ne 1) { throw 'The practice scenario is not open. Evaluation mode will not be used.' }
    $script:Targets=@($practice[0].targets)
    if ($script:Targets.Count -eq 0) { throw 'The API returned no practice AI twins.' }
    if ($script:State.pending_create -and -not (Recover-Creation)) { return }
    if ($script:State.session_id) {
        if (-not (Refresh-Session)) { throw 'The saved session could not be verified. Try again later; no new session was created.' }
        Write-Host ('Resuming the same session: ' + $script:State.session_id) -ForegroundColor Green
    } else {
        if (-not (Choose-Target)) { return }
        $null=New-PracticeSession
    }
    while ($true) {
        Write-Host ''
        Write-Host ('Practice session: ' + $script:State.session_id + ' | AI twin: ' + $script:State.target_name) -ForegroundColor Cyan
        if ($script:State.session) { Write-Host ('Contacts used: ' + $script:State.session.touches_used + ' / ' + $script:State.session.touch_budget) }
        if ($script:State.pending) { Write-Host 'A message has an unresolved outcome. Choose option 4.' -ForegroundColor Yellow }
        if ($script:State.pending_create) { Write-Host 'A session creation needs to be checked. Choose option 4.' -ForegroundColor Yellow }
        Write-Host '1. Write and send an email in the simulator'
        Write-Host '2. Copy the conversation for ChatGPT and open the context file'
        Write-Host '3. Switch AI twin (keep the same session)'
        Write-Host '4. Retry a pending request / recover an uncertain session creation'
        Write-Host '5. Create a NEW practice session'
        Write-Host '0. Exit (your session is saved for next time)'
        $menu=Read-Host 'Choose an option'
        switch ($menu) {
            '1' { Draft-Message }
            '2' { if ($script:State.session_id) { $null=Refresh-Session }; Export-Context $true }
            '3' { if ($script:State.pending) { Write-Host 'Resolve the pending message using option 4.' } else { $null=Choose-Target } }
            '4' { if ($script:State.pending_create) { $null=Recover-Creation } else { Send-Pending } }
            '5' { $null=New-PracticeSession }
            '0' { return }
            default { Write-Host 'Choose an option from the list.' }
        }
    }
} catch {
    Write-Host ''
    Write-Host ('ERROR: ' + (Protect-Text $_.Exception.Message)) -ForegroundColor Yellow
    Write-Host 'Your saved session will be available next time. Do not paste the key into ChatGPT.'
} finally {
    if ($null -ne $script:Lock) { $script:Lock.Dispose() }
    $script:TeamKey=$null
}
