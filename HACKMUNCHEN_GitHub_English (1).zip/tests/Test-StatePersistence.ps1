# Offline regression test for the actual client's state writer.
# Compatible with Windows PowerShell 5.1; no Pester or network access needed.
# From the repository root:
# Double-click TEST_STATE.bat, or run it from the repository root.

param([string]$ClientPath = '')

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$testRoot = $null
$script:StateFile = $null
$script:State = $null
$script:TeamKey = $null
$script:TestFakeKey = 'OFFLINE_TEST_KEY_NOT_A_REAL_CREDENTIAL_83b7c9'

function Assert-True([bool]$Condition, [string]$Message) {
    if (-not $Condition) { throw $Message }
}

function Read-TestState {
    Assert-True (Test-Path -LiteralPath $script:StateFile -PathType Leaf) 'The state file was not created.'
    $raw = [IO.File]::ReadAllText($script:StateFile, [Text.Encoding]::UTF8)
    Assert-True (-not $raw.Contains($script:TestFakeKey)) 'The fake key leaked into the state file.'
    try { $loaded = $raw | ConvertFrom-Json -ErrorAction Stop } catch { throw 'The saved state is not valid JSON.' }
    Assert-True ($null -ne $loaded) 'The state file contains no JSON object.'
    return $loaded
}

function Assert-PendingRequest($Loaded, [string]$ExpectedJson, [string]$ExpectedRequestId) {
    Assert-True ($null -ne $Loaded.pending) 'The pending request was lost.'
    Assert-True ($Loaded.pending.request_id -ceq $ExpectedRequestId) 'The idempotency key changed during persistence.'
    Assert-True ($Loaded.pending.json -ceq $ExpectedJson) 'The serialized pending body changed during persistence.'
    Assert-True ($Loaded.pending.session_id -ceq 's_offline_test') 'The pending request moved to another session.'
    $message = $Loaded.pending.json | ConvertFrom-Json -ErrorAction Stop
    Assert-True ($message.to -ceq 'julius') 'The stored pending message is not valid message JSON.'
    Assert-True ($message.from.name -ceq 'MilanHack') 'The pending sender was not preserved.'
}

try {
    if ([string]::IsNullOrWhiteSpace($ClientPath)) {
        if ($PSScriptRoot) { $ClientPath = Join-Path $PSScriptRoot '..\practice-client.ps1' }
        else { $ClientPath = Join-Path (Get-Location).Path 'practice-client.ps1' }
    }
    $resolvedClientPath = [IO.Path]::GetFullPath($ClientPath)
    Assert-True (Test-Path -LiteralPath $resolvedClientPath -PathType Leaf) 'Run this test from the complete extracted repository or supply -ClientPath.'

    # Parse, then load ONLY these definitions. Never dot-source the client: its
    # main program prompts for a key and can contact the API.
    $tokens = $null
    $parseErrors = $null
    $ast = [Management.Automation.Language.Parser]::ParseFile($resolvedClientPath, [ref]$tokens, [ref]$parseErrors)
    Assert-True (@($parseErrors).Count -eq 0) 'The client has PowerShell syntax errors.'
    $definitions = @($ast.FindAll({
        param($node)
        $node -is [Management.Automation.Language.FunctionDefinitionAst] -and
        @('Protect-Text', 'Save-State') -contains $node.Name
    }, $true))
    foreach ($name in @('Protect-Text', 'Save-State')) {
        $matchedDefinitions = @($definitions | Where-Object { $_.Name -eq $name })
        Assert-True ($matchedDefinitions.Count -eq 1) ('Expected exactly one client definition of ' + $name + '.')
        . ([scriptblock]::Create($matchedDefinitions[0].Extent.Text))
    }

    $testRoot = Join-Path ([IO.Path]::GetTempPath()) ('revel8 persistence test ' + [Guid]::NewGuid().ToString('N'))
    $nested = Join-Path (Join-Path $testRoot 'local data with spaces') 'nested team history'
    $null = [IO.Directory]::CreateDirectory($nested)
    $script:StateFile = Join-Path $nested 'state with spaces.json'
    $script:TeamKey = $script:TestFakeKey

    # Quotes, backslashes, newlines and non-ASCII characters must survive the
    # JSON string nested inside state JSON. Build non-ASCII without source-file
    # encoding assumptions in Windows PowerShell 5.1.
    $body = 'Hi Julius,' + "`r`n`r`n" + 'A quote: "yes"; a backslash: \; accent: ' + [char]0x00E9 + '; euro: ' + [char]0x20AC
    $payload = [ordered]@{
        to = 'julius'
        channel = 'email'
        from = @{ name = 'MilanHack' }
        subject = 'Offline persistence test only'
        body = $body
    }
    $pendingJson = $payload | ConvertTo-Json -Depth 8 -Compress
    $requestId = '00000000-1111-4222-8333-444444444444'
    $script:State = [pscustomobject]@{
        version = 1
        scenario_id = 'practice'
        session_id = 's_offline_test'
        target_id = 'julius'
        target_name = ''
        counter = 0
        secret_note = ('Do not persist this fake key: ' + $script:TestFakeKey)
        nested = [pscustomobject]@{ note = ('Bearer ' + $script:TestFakeKey) }
        pending = [pscustomobject]@{
            session_id = 's_offline_test'
            request_id = $requestId
            json = $pendingJson
            created_at = '2026-01-01T00:00:00.0000000Z'
        }
        sent = @()
        events = @()
    }

    Save-State
    $loaded = Read-TestState
    Assert-True ($loaded.counter -eq 0) 'The initial state was not saved.'
    Assert-PendingRequest $loaded $pendingJson $requestId
    Write-Host 'PASS: first save creates valid JSON in nested paths with spaces.'

    # The reported regression occurred on the first replacement, after target
    # selection. Repeated overwrites also catch backup-name reuse problems.
    for ($round = 1; $round -le 3; $round++) {
        $script:State.target_name = 'Julius Muth'
        $script:State.counter = $round
        Save-State
        $loaded = Read-TestState
        Assert-True ($loaded.counter -eq $round) ('Overwrite ' + $round + ' did not replace the old state.')
        Assert-True ($loaded.target_name -ceq 'Julius Muth') 'The selected target was not saved.'
        Assert-PendingRequest $loaded $pendingJson $requestId
        $backupPath = $script:StateFile + '.bak'
        Assert-True (Test-Path -LiteralPath $backupPath -PathType Leaf) 'The previous state backup was not created.'
        $backup = [IO.File]::ReadAllText($backupPath, [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop
        Assert-True ($backup.counter -eq ($round - 1)) 'The backup is not the immediately previous state revision.'
        Assert-PendingRequest $backup $pendingJson $requestId
    }
    Write-Host 'PASS: three overwrites retain the pending request and back up the previous revision.'

    # Simulate a restart: discard the in-memory state and key, read the saved
    # state as the real client does, then overwrite it once more.
    $script:State = $null
    $script:TeamKey = $null
    $script:TeamKey = $script:TestFakeKey
    $script:State = Read-TestState
    Assert-PendingRequest $script:State $pendingJson $requestId
    $script:State.counter = 4
    Save-State
    $loaded = Read-TestState
    Assert-True ($loaded.counter -eq 4) 'Saving after a restart-style reload failed.'
    Assert-PendingRequest $loaded $pendingJson $requestId
    $reloadedMessage = $loaded.pending.json | ConvertFrom-Json -ErrorAction Stop
    Assert-True ($reloadedMessage.body -ceq $body) 'Unicode, newlines or punctuation in the pending body changed.'
    Write-Host 'PASS: disk reload and overwrite retain the exact body and idempotency key.'

    # On Windows, a handle with FileShare.None prevents replacement. A failed
    # write must leave the last confirmed JSON and its backup untouched.
    if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
        $beforeFailure = [IO.File]::ReadAllText($script:StateFile, [Text.Encoding]::UTF8)
        $beforeBackup = [IO.File]::ReadAllText(($script:StateFile + '.bak'), [Text.Encoding]::UTF8)
        $handle = [IO.File]::Open($script:StateFile, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::None)
        $writeRejected = $false
        try {
            $script:State.counter = 5
            try { Save-State } catch { $writeRejected = $true }
        } finally { $handle.Dispose() }
        Assert-True $writeRejected 'Replacing a locked destination unexpectedly succeeded.'
        Assert-True ([IO.File]::ReadAllText($script:StateFile, [Text.Encoding]::UTF8) -ceq $beforeFailure) 'A failed save changed the confirmed state.'
        Assert-True ([IO.File]::ReadAllText(($script:StateFile + '.bak'), [Text.Encoding]::UTF8) -ceq $beforeBackup) 'A failed save changed the previous backup.'
        Save-State
        $loaded = Read-TestState
        Assert-True ($loaded.counter -eq 5) 'Saving did not recover after releasing the destination lock.'
        Assert-PendingRequest $loaded $pendingJson $requestId
        Write-Host 'PASS: a locked-destination failure preserves state; retry succeeds after unlock.'
    } else {
        Write-Host 'SKIP: the Windows destination-lock check requires Windows.'
    }

    Assert-True ($loaded.secret_note.StartsWith('Do not persist this fake key: ')) 'Redaction damaged surrounding note text.'
    Assert-True ($loaded.nested.note.StartsWith('Bearer ')) 'Nested redaction damaged surrounding note text.'
    foreach ($file in @(Get-ChildItem -LiteralPath $testRoot -File -Recurse)) {
        $content = [IO.File]::ReadAllText($file.FullName, [Text.Encoding]::UTF8)
        Assert-True (-not $content.Contains($script:TestFakeKey)) 'A temporary or backup file contains the fake key.'
    }
    Assert-True (-not (Test-Path -LiteralPath ($script:StateFile + '.new'))) 'A successful save left an uncommitted temporary state file.'
    Write-Host 'PASS: state, temporary files and backups contain no fake key.'
    Write-Host 'All offline state-persistence tests passed.' -ForegroundColor Green
} catch {
    [Console]::Error.WriteLine('FAIL: ' + $_.Exception.Message)
    exit 1
} finally {
    $script:TeamKey = $null
    $script:State = $null
    if ($null -ne $testRoot -and [IO.Directory]::Exists($testRoot)) {
        Remove-Item -LiteralPath $testRoot -Recurse -Force -ErrorAction Stop
    }
}
