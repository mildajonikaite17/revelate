@echo off
setlocal DisableDelayedExpansion
title HACKMUNCHEN - Offline state-save test
cd /d "%~dp0"
set "HACKMUNCHEN_TEST_ROOT=%~dp0"
echo Offline state-save regression test. No API calls or team key are needed.
powershell.exe -NoLogo -NoProfile -STA -Command "try { $taskTest = [IO.Path]::Combine($env:HACKMUNCHEN_TEST_ROOT, 'tests\Test-StatePersistence.ps1'); $taskClient = [IO.Path]::Combine($env:HACKMUNCHEN_TEST_ROOT, 'practice-client.ps1'); $taskSource = [IO.File]::ReadAllText($taskTest, [Text.Encoding]::UTF8); & ([scriptblock]::Create($taskSource)) -ClientPath $taskClient } catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }"
if errorlevel 1 echo The test failed. Copy the error message for troubleshooting.
echo.
pause
endlocal
