"""Autonomous, bounded practice runner for the authorized revel8 AI-twin API."""
from __future__ import annotations

import argparse
import copy
import getpass
import json
import os
from pathlib import Path
import re
import sys
import unicodedata
import uuid
from datetime import datetime, timezone

from models import OpenAIModel, ModelError
from policy import validate_action, compute_metrics
from protocol import TargetAPI, APIError, RunStore


class AgentError(Exception):
    pass


def now():
    return datetime.now(timezone.utc).isoformat()


def normalized(text):
    return " ".join(unicodedata.normalize("NFKC", str(text)).replace("\u2019", "'").split()).casefold()


def merge_events(existing, incoming):
    """Refreshing server events must not double-count previously observed actions."""
    result, seen = [], set()
    for event in list(existing or []) + list(incoming or []):
        key = event.get("id") or json.dumps(event, ensure_ascii=False, sort_keys=True)
        if key not in seen:
            seen.add(key)
            result.append(copy.deepcopy(event))
    return result


class AgentRunner:
    def __init__(self, api, model, campaign, store, log=print):
        self.api = api
        self.model = model
        self.campaign = copy.deepcopy(campaign)
        self.store = store
        self.log = log
        self.state = None
        self.base_model_calls = 0

    def save(self):
        self.state["updated_at"] = now()
        self.state["model_calls"] = self.base_model_calls + self.model.calls
        self.store.save(self.state)

    def context(self):
        return {"campaign": self.campaign, "state": copy.deepcopy(self.state)}

    def model_call(self, method, *args, **kwargs):
        # A resumed run retains its cumulative allowance, including research,
        # observations, revisions and reviews, rather than resetting it.
        if self.base_model_calls + self.model.calls >= int(self.campaign.get("max_model_calls", 36)):
            raise ModelError("Configured model-call budget reached for this attempt.")
        return getattr(self.model, method)(*args, **kwargs)

    def fresh(self, target):
        self.state = {
            "version": 6, "status": "initializing", "created_at": now(),
            "scenario_id": "practice", "target": copy.deepcopy(target),
            "session": None, "profile": None, "plan": None,
            "campaign": copy.deepcopy(self.campaign), "model_calls": 0,
            "operations_used": 0, "pending": None,
            "messages": [], "conversations": [], "active_conversation": None,
            "registered_pages": [], "events": [], "inbound": [],
            "evidence": [], "requirements": [], "candidate_disclosures": [],
            "constraints": {"preferred_channel": None, "no_registration": False,
                "plain_text_only": False, "no_links": False,
                "stop_contact": False, "email_requested": False},
            "engagement": {"registration_interest": False},
            "operations": [], "rejected_drafts": [], "last_errors": [],
        }
        self.save()

    def restore(self):
        self.state = self.store.load()
        if self.state.get("version") != 6 or self.state.get("scenario_id") != "practice":
            raise AgentError("This runner resumes only its own v6 practice runs.")
        self.campaign = copy.deepcopy(self.state["campaign"])
        self.base_model_calls = int(self.state.get("model_calls", 0))
        active = self.state.get("active_conversation")
        if active:
            matches = [c for c in self.state["conversations"] if c["id"] == active["id"]]
            if len(matches) != 1:
                raise AgentError("Saved conversation history is inconsistent; no request was sent.")
            self.state["active_conversation"] = matches[0]
        self.state["status"] = "resuming"

    def initialize(self):
        if not self.state.get("profile"):
            self.log("Researching public professional context...")
            self.state["profile"] = self.model_call("research", self.state["target"])
            for fact in self.state["profile"].get("facts", []):
                self.state["evidence"].append({
                    "id": fact["id"], "kind": "public_fact", "text": fact["text"],
                    "source_url": fact["source_url"],
                })
            self.save()
        if not self.state.get("plan"):
            self.log("Selecting an approach, channel and approved sender...")
            plan = self.model_call("plan", self.context())
            if plan.get("primary_objective") not in self.campaign.get("objectives", ["disclosure"]):
                raise AgentError("The proposed objective is outside this campaign's configured scope.")
            senders = self.campaign.get("approved_senders", [self.campaign["sender"]])
            selected = next((s for s in senders if s["name"] == plan.get("sender_name")), None)
            if selected is None:
                raise AgentError("The planner did not select an approved sender identity.")
            fact_ids = {f["id"] for f in self.state["profile"].get("facts", [])}
            if not set(plan.get("fact_ids", [])).issubset(fact_ids):
                raise AgentError("The planner cited research evidence that does not exist.")
            self.campaign["sender"] = copy.deepcopy(selected)
            self.state["campaign"] = copy.deepcopy(self.campaign)
            self.state["plan"] = plan
            self.save()
            self.log("Selected sender: " + selected["name"] + " | Initial channel: " + plan["first_channel"])
            self.log("Plan: " + plan["rationale"])
        if not self.state.get("session"):
            if self.state.get("pending"):
                self.execute_pending()
                return
            # Creation is deliberately never retried blindly: its idempotency is undocumented.
            self.state["pending"] = {
                "kind": "create_session", "path": "/sessions",
                "payload": {"scenario_id": "practice"}, "request_id": None,
                "created_at": now(),
            }
            self.save()
            self.execute_pending(first_attempt=True)

    def refresh(self):
        if not self.state.get("session"):
            return
        sid = self.state["session"]["session_id"]
        session = self.api.request("GET", "/sessions/" + sid)
        if session.get("scenario_id") != "practice":
            raise AgentError("The server session is not a practice session.")
        self.state["session"] = session
        response = self.api.request("GET", "/sessions/" + sid + "/events")
        self.state["events"] = merge_events(self.state["events"], response.get("events", []))
        self.add_event_replies(response.get("events", []))
        self.save()

    def inbound(self, kind, text, source_event=None):
        if not text:
            return
        if source_event and any(x.get("source_event") == source_event for x in self.state["inbound"]):
            return
        identifier = "inbound_" + str(len(self.state["inbound"]) + 1)
        record = {"id": identifier, "kind": kind, "text": str(text),
                  "source_event": source_event, "processed": False}
        self.state["inbound"].append(record)
        self.state["evidence"].append({"id": identifier, "kind": kind, "text": str(text)})
        self.log("AI twin [" + kind + "]: " + str(text))

    def add_event_replies(self, events):
        for event in events or []:
            if event.get("type") == "reply":
                event_key = event.get("id") or json.dumps(event, sort_keys=True)
                self.inbound("message_reply", event.get("body", ""), event_key)

    def observe_pending(self):
        for incoming in self.state["inbound"]:
            if incoming["processed"]:
                continue
            result = self.model_call("observe", {"inbound": incoming, "state": self.context()})
            findings = result.get("findings", [])
            # Validate the entire observation before changing memory, so a bad
            # later quote cannot leave a partially applied, replayable update.
            for finding in findings:
                quote = finding.get("quote", "")
                if not quote or normalized(quote) not in normalized(incoming["text"]):
                    raise AgentError("The observer could not ground a finding in the actual target reply.")
            for finding in findings:
                self.apply_finding(incoming, finding)
            incoming["processed"] = True
            self.save()

    def apply_finding(self, incoming, finding):
        kind, quote = finding["kind"], finding["quote"]
        constraints = self.state["constraints"]
        if kind in ("email_requested", "prefer_email"):
            constraints["preferred_channel"] = "email"
            if kind == "email_requested":
                constraints["email_requested"] = True
        elif kind in ("no_registration", "plain_text_only", "no_links", "stop_contact"):
            constraints[kind] = True
        elif kind == "registration_interest":
            self.state["engagement"]["registration_interest"] = True
        elif kind == "candidate_disclosure":
            self.state["candidate_disclosures"].append({
                "source_id": incoming["id"], "quote": quote,
                "interpretation": finding["detail"], "verified_nonpublic": False,
            })
        if kind in ("verification_question", "email_requested", "plain_text_only", "no_links", "no_registration"):
            self.state["requirements"].append({
                "id": "requirement_" + str(len(self.state["requirements"]) + 1),
                "kind": kind, "quote": quote, "detail": finding["detail"],
                "source_id": incoming["id"], "status": "open",
            })

    def prepare_operation(self, action):
        kind = action["action"]
        sid = self.state["session"]["session_id"]
        sender = {"name": self.campaign["sender"]["name"]}
        if kind == "message":
            path = "/sessions/" + sid + "/messages"
            payload = {"to": self.state["target"]["id"], "channel": action["channel"],
                       "from": sender, "subject": action.get("subject") or "", "body": action["body"]}
        elif kind == "start_call":
            path = "/sessions/" + sid + "/conversations"
            payload = {"to": self.state["target"]["id"], "channel": action["channel"], "from": sender}
        elif kind == "say":
            path = "/conversations/" + self.state["active_conversation"]["id"] + "/turns"
            payload = {"say": action["say"]}
        elif kind == "end_call":
            path = "/conversations/" + self.state["active_conversation"]["id"] + "/end"
            payload = {}
        elif kind == "register_page":
            path = "/sessions/" + sid + "/pages"
            payload = copy.deepcopy(action["page"])
        else:
            raise AgentError("Unsupported outbound operation.")
        self.state["pending"] = {
            "kind": kind, "path": path, "payload": payload,
            "request_id": str(uuid.uuid4()) if kind in ("message", "start_call", "say") else None,
            "session_id": sid, "action": copy.deepcopy(action), "created_at": now(),
        }
        self.state["operations_used"] += 1
        self.save()  # This must complete before the first HTTP request.

    def execute_pending(self, first_attempt=False):
        pending = self.state["pending"]
        if not pending:
            return
        kind = pending["kind"]
        if kind == "create_session" and not first_attempt:
            raise AgentError("Session creation had an uncertain outcome. Resume with --session-id after checking the team's session list; it was not repeated.")
        if kind != "create_session" and pending.get("session_id") != self.state["session"]["session_id"]:
            raise AgentError("The pending operation belongs to another session.")
        try:
            response = self.api.request("POST", pending["path"], pending["payload"], pending.get("request_id"))
        except APIError as exc:
            if kind == "end_call" and exc.status == 409:
                # A generic 409 cannot prove which remote resource ended.
                # Keep the unresolved cleanup rather than inventing a success.
                raise AgentError("The server rejected conversation cleanup (409). Its final status is unconfirmed; pending state was retained.") from None
            # These definite rejections do not reach the target. Do not erase an
            # uncertain request or an authentication failure that could be resumed.
            if not exc.uncertain and exc.status in (400, 403, 404, 409, 413, 415, 422):
                self.state["operations"].append({"kind": kind, "failed": True,
                    "status": exc.status, "error": str(exc), "action": pending.get("action")})
                self.state["pending"] = None
                self.state["last_errors"] = ["Previous request rejected: " + str(exc)]
                self.save()
                if exc.status in (400, 422) and kind != "create_session":
                    return
            raise
        if kind == "create_session":
            if response.get("scenario_id") != "practice" or not response.get("session_id"):
                raise AgentError("Session creation returned an unexpected response; no contact followed.")
            self.state["session"] = response
        else:
            self.commit_response(pending, response)
        self.state["pending"] = None
        self.state["last_errors"] = []
        self.save()  # If this fails, disk still holds the exact pending operation.

    def commit_response(self, pending, response):
        kind, action = pending["kind"], pending["action"]
        self.state["operations"].append({"kind": kind, "payload": pending["payload"],
            "response": response, "request_id": pending.get("request_id"), "recorded_at": now()})
        if "touches_used" in response:
            self.state["session"]["touches_used"] = max(
                int(self.state["session"].get("touches_used", 0)), int(response["touches_used"]))
        events = response.get("events", [])
        self.state["events"] = merge_events(self.state["events"], events)
        self.add_event_replies(events)
        if kind == "message":
            self.state["messages"].append({"payload": pending["payload"], "response": response})
            if pending["payload"]["channel"] == "email":
                self.state["constraints"]["email_requested"] = False
        elif kind == "start_call":
            cid = response.get("conversation_id")
            if not cid:
                raise AgentError("The call response omitted its conversation ID; pending state was retained.")
            conversation = {"id": cid, "channel": pending["payload"]["channel"],
                "status": response.get("status", "answered"), "turns_used": 0,
                "start_response": response, "dialogue": []}
            self.state["conversations"].append(conversation)
            self.state["active_conversation"] = conversation if conversation["status"] == "answered" else None
            self.inbound("call_greeting", response.get("persona_says", ""))
        elif kind == "say":
            conversation = self.state["active_conversation"]
            conversation["dialogue"].append({"say": pending["payload"]["say"], "response": response})
            conversation["turns_used"] = max(conversation["turns_used"] + 1, int(response.get("turns_used", 0)))
            self.inbound("conversation_response", response.get("persona_says", ""))
            if response.get("ended"):
                conversation["status"] = "ended"
                self.state["active_conversation"] = None
        elif kind == "end_call":
            self.state["active_conversation"]["status"] = "ended"
            self.state["active_conversation"] = None
        elif kind == "register_page":
            page = dict(pending["payload"], page_id=response.get("page_id"))
            self.state["registered_pages"] = [p for p in self.state["registered_pages"] if p["url"] != page["url"]] + [page]
        addressed = set(action.get("addresses_requirements", [])) if kind in ("message", "say") else set()
        for requirement in self.state["requirements"]:
            if requirement["id"] in addressed:
                # Responded does not mean the target accepted verification.
                requirement["status"] = "responded"

    def cleanup_action(self, reason):
        return {"action": "end_call", "channel": None,
            "sender_name": self.campaign["sender"]["name"], "subject": None,
            "body": None, "say": None, "page": None, "reason": reason,
            "evidence_ids": [], "addresses_requirements": []}

    def finish(self, status, reason):
        if self.state.get("active_conversation") and not self.state.get("pending"):
            try:
                self.prepare_operation(self.cleanup_action("Close the conversation before this attempt stops."))
                self.execute_pending()
            except (APIError, AgentError) as exc:
                status = "paused_uncertain" if self.state.get("pending") else "stopped_error"
                reason += " Conversation cleanup: " + str(exc)
        self.state["status"] = status
        self.state["stop_reason"] = reason
        self.state["metrics"] = compute_metrics(self.state)
        self.save()
        self.log("Observed outcomes: " + json.dumps(self.state["metrics"], ensure_ascii=False))
        self.log("Stop reason: " + reason)
        self.log("Candidate internal details: " + str(len(self.state["candidate_disclosures"])) + " (not a verified score)")
        return self.state

    def run(self, target=None, resume=False, recovered_session_id=None):
        try:
            if resume:
                self.restore()
                if recovered_session_id:
                    pending = self.state.get("pending")
                    if not pending or pending["kind"] != "create_session":
                        raise AgentError("--session-id is only for recovering an uncertain session creation.")
                    if not re.fullmatch(r"[A-Za-z0-9_-]+", recovered_session_id):
                        raise AgentError("Invalid recovery session ID.")
                    session = self.api.request("GET", "/sessions/" + recovered_session_id)
                    if session.get("scenario_id") != "practice":
                        raise AgentError("Recovery requires a practice session.")
                    self.state["session"] = session
                    self.state["pending"] = None
                    self.save()
            else:
                self.fresh(target)
            self.initialize()
            self.refresh()
            if self.state.get("pending"):
                self.execute_pending()
            self.state["status"] = "running"
            self.save()
            while self.state["operations_used"] < int(self.campaign.get("max_actions", 16)):
                if self.base_model_calls + self.model.calls >= int(self.campaign.get("max_model_calls", 36)):
                    return self.finish("stopped_budget", "Configured model-call budget reached for this attempt.")
                self.observe_pending()
                active = self.state["active_conversation"]
                constraints = self.state["constraints"]
                forced = None
                if active and (constraints["email_requested"] or constraints["stop_contact"] or active["turns_used"] >= 10):
                    forced = self.cleanup_action("End the active conversation before honoring the target's channel preference or stopping.")
                elif constraints["stop_contact"]:
                    return self.finish("stopped_refusal", "The target explicitly declined further contact in this attempt.")
                if not active:
                    budget = min(int(self.state["session"]["touch_budget"]), int(self.campaign.get("max_contacts", 5)))
                    if int(self.state["session"]["touches_used"]) >= budget:
                        return self.finish("stopped_budget", "Configured contact budget reached for this session.")
                feedback = list(self.state.get("last_errors", []))
                chosen = None
                for _ in range(3):
                    action = forced or self.model_call("decide", self.context(), feedback=feedback)
                    errors = validate_action(action, self.state, self.campaign)
                    if not errors and action["action"] != "stop" and not forced:
                        review = self.model_call("review", self.context(), action)
                        if not review.get("allow"):
                            errors = review.get("errors") or [review.get("summary", "Draft did not pass the claims review.")]
                    if errors:
                        self.state["rejected_drafts"].append({"action": action, "errors": errors, "sent": False})
                        feedback = list(errors)
                        self.save()
                        self.log("Draft revised before sending: " + "; ".join(errors))
                        if forced:
                            break
                        continue
                    chosen = action
                    break
                if chosen is None:
                    return self.finish("stopped_validation", "Three drafts failed the configured evidence/consistency checks; this attempt stopped.")
                if chosen["action"] == "stop":
                    return self.finish("stopped_planner", "Planner stopped this attempt: " + chosen["reason"])
                self.log("Next action: " + chosen["action"] + " | " + chosen["reason"])
                self.prepare_operation(chosen)
                self.execute_pending()
            self.observe_pending()
            return self.finish("stopped_budget", "Configured operation budget reached for this attempt.")
        except (APIError, ModelError, AgentError) as exc:
            if self.state is None:
                raise
            status = "paused_uncertain" if self.state.get("pending") else "stopped_error"
            if isinstance(exc, ModelError) and self.base_model_calls + self.model.calls >= int(self.campaign.get("max_model_calls", 36)):
                status = "stopped_budget" if not self.state.get("pending") else status
            return self.finish(status, str(exc))


def write_transcript(state, path):
    parts = ["# Autonomous practice run", "", "Target: " + state["target"]["name"],
             "Status: " + state["status"], "", "This is observed simulation output, not an official score.", ""]
    for op in state["operations"]:
        parts.extend(["## " + op["kind"], "", "```json", json.dumps(op, ensure_ascii=False, indent=2), "```", ""])
    parts.extend(["## Outcome", "", "```json", json.dumps(state.get("metrics", {}), ensure_ascii=False, indent=2),
                  "```", "", state.get("stop_reason", "")])
    Path(path).write_text("\n".join(parts), encoding="utf-8")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--campaign", default=str(Path(__file__).with_name("campaign.json")))
    parser.add_argument("--targets", default="julius", help="Comma-separated scenario IDs, or all.")
    parser.add_argument("--model", help="Reuse your available OpenAI API model; default is the campaign setting.")
    parser.add_argument("--runs-dir", default=str(Path(__file__).with_name("runs")))
    parser.add_argument("--resume", help="Path to a v6 run JSON saved by this runner.")
    parser.add_argument("--session-id", help="Only for recovery after uncertain session creation.")
    parser.add_argument("--no-web-search", action="store_true", help="Use scenario facts only; do not invent web research.")
    args = parser.parse_args(argv)
    if args.session_id and not args.resume:
        parser.error("--session-id requires --resume with a saved run that has uncertain session creation.")
    if sys.version_info < (3, 10):
        parser.error("Python 3.10 or newer is required.")
    campaign = json.loads(Path(args.campaign).read_text(encoding="utf-8-sig"))
    team_key = os.environ.get("REVEL8_TEAM_KEY") or getpass.getpass("Paste the organizer TEAM KEY (hidden): ").strip()
    openai_key = os.environ.get("OPENAI_API_KEY") or getpass.getpass("Paste your EXISTING OpenAI API key (hidden): ").strip()
    if not team_key or not openai_key:
        parser.error("Both existing credentials are required for this autonomous API-based runner. They are not saved.")
    api = TargetAPI(team_key)
    scenarios = api.request("GET", "/scenarios")
    if isinstance(scenarios, dict):
        scenarios = scenarios.get("scenarios", [])
    practice = next((s for s in scenarios if s.get("id") == "practice" and s.get("open")), None)
    if not practice:
        raise AgentError("Practice is not open. This runner never uses evaluation sessions.")
    targets = {t["id"]: t for t in practice["targets"]}
    selected = list(targets) if args.targets == "all" else [x.strip() for x in args.targets.split(",") if x.strip()]
    if not selected:
        parser.error("Select at least one target, or all.")
    if any(x not in targets for x in selected):
        parser.error("Select only target IDs returned by the current practice scenario.")
    runs = Path(args.runs_dir)
    runs.mkdir(parents=True, exist_ok=True)
    paths = [Path(args.resume)] if args.resume else [runs / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ_") + t + "_" + uuid.uuid4().hex[:8] + ".json") for t in selected]
    exit_code = 0
    for index, path in enumerate(paths):
        store = RunStore(path, secrets=(team_key, openai_key))
        effective_campaign = store.load()["campaign"] if args.resume else campaign
        model = OpenAIModel(openai_key, model=args.model or effective_campaign.get("model", "gpt-4.1"),
            max_calls=int(effective_campaign.get("max_model_calls", 36)),
            max_output_tokens=int(effective_campaign.get("max_output_tokens", 2200)),
            enable_web_search=not args.no_web_search and bool(effective_campaign.get("enable_web_search", True)))
        runner = AgentRunner(api, model, effective_campaign, store)
        result = runner.run(target=None if args.resume else targets[selected[index]],
                            resume=bool(args.resume), recovered_session_id=args.session_id)
        write_transcript(result, path.with_suffix(".md"))
        print("Saved run:", path)
        print("Readable transcript:", path.with_suffix(".md"))
        if result["status"] in ("paused_uncertain", "stopped_error", "stopped_validation"):
            exit_code = 1
    return exit_code


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AgentError, APIError, ModelError, OSError, ValueError) as exc:
        print("Stopped:", str(exc), file=sys.stderr)
        raise SystemExit(1)
