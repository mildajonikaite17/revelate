"""Offline model-contract tests. No API credentials or network calls are used."""

import copy
import json
import unittest

from models import ModelError, OpenAIModel, SCHEMAS


def response(value, **extra):
    return {"status": "completed", "output": [{"type": "message", "role": "assistant",
            "content": [{"type": "output_text", "text": json.dumps(value), "annotations": []}]}], **extra}


def decision():
    return {"action": "message", "channel": "email", "sender_name": "Alex",
            "subject": "Workflow discussion", "body": "Please send the public overview.",
            "say": None, "page": None, "reason": "Respond to the email request.",
            "evidence_ids": ["inbound_1"], "addresses_requirements": ["email_requested"]}


def research_result():
    return {"facts": [], "hypotheses": [], "unknowns": [], "sources": []}


class ModelTests(unittest.TestCase):
    def model(self, value=None, raw=None, **kwargs):
        sent = []

        def transport(payload):
            sent.append(payload)
            return copy.deepcopy(raw if raw is not None else response(value))

        return OpenAIModel("test-secret-key", transport=transport, **kwargs), sent

    def test_decision_raw_responses_contract(self):
        model, sent = self.model(decision())
        self.assertEqual(model.decide({"history": []}, ["Use email"]), decision())
        payload = sent[0]
        self.assertEqual(model.calls, 1)
        self.assertEqual(payload["model"], "gpt-4.1")
        self.assertIs(payload["store"], False)
        self.assertEqual(payload["text"]["format"]["type"], "json_schema")
        self.assertIs(payload["text"]["format"]["strict"], True)
        self.assertNotIn("tools", payload)
        self.assertNotIn("include", payload)
        content = json.loads(payload["input"][0]["content"][0]["text"])
        self.assertEqual(content["revision_feedback"], ["Use email"])
        self.assertNotIn("test-secret-key", json.dumps(payload))

    def test_every_object_schema_is_strict(self):
        def check(schema):
            if schema.get("type") == "object":
                self.assertIs(schema["additionalProperties"], False)
                self.assertEqual(set(schema["required"]), set(schema["properties"]))
                for child in schema["properties"].values():
                    check(child)
            if "items" in schema:
                check(schema["items"])
            for child in schema.get("anyOf", []):
                check(child)
        for schema in SCHEMAS.values():
            check(schema)

    def test_all_public_methods_use_their_schema(self):
        examples = {
            "plan": {"strategy": "workflow_interview", "hypothesis": "Role may fit public workflow discussion.",
                     "primary_objective": "disclosure", "first_channel": "email", "sender_name": "Alex",
                     "rationale": "Role-based hypothesis only.", "fact_ids": []},
            "observation": {"findings": [{"kind": "plain_text_only", "quote": "plain text", "detail": "Format request"}]},
            "review": {"allow": False, "errors": ["Use plain text"], "summary": "Requested format absent."},
        }
        for name, value in examples.items():
            model, sent = self.model(value)
            if name == "observation":
                result = model.observe({"inbound": {"text": "Send plain text"}})
            elif name == "review":
                result = model.review({}, decision())
            else:
                result = model.plan({})
            self.assertEqual(result, value)
            self.assertEqual(sent[0]["text"]["format"]["name"], name)

    def test_missing_field_unknown_field_and_wrong_enum_rejected(self):
        cases = []
        missing = decision()
        del missing["reason"]
        cases.append(missing)
        cases.append({**decision(), "extra": True})
        cases.append({**decision(), "action": "send_real_email"})
        cases.append({**decision(), "body": 7})
        for value in cases:
            with self.subTest(value=value):
                model, _ = self.model(value)
                with self.assertRaises(ModelError):
                    model.decide({})

    def test_refusal_is_terminal_for_the_request(self):
        raw = {"output": [{"type": "message", "content": [{"type": "refusal", "refusal": "No"}]}]}
        model, sent = self.model(raw=raw)
        with self.assertRaisesRegex(ModelError, "refused"):
            model.decide({})
        self.assertEqual(len(sent), 1)

    def test_noncompleted_responses_are_not_actions(self):
        for status in ("incomplete", "failed", "cancelled", "queued", "in_progress"):
            model, _ = self.model(raw=response(decision(), status=status))
            with self.subTest(status=status), self.assertRaises(ModelError):
                model.decide({})

    def test_only_assistant_message_output_is_parsed(self):
        raw = {"output": [{"type": "web_search_call", "text": json.dumps(decision())}],
               "output_text": json.dumps(decision())}
        model, _ = self.model(raw=raw)
        with self.assertRaisesRegex(ModelError, "structured JSON"):
            model.decide({})

    def test_invalid_json_is_model_error(self):
        raw = response(decision())
        raw["output"][0]["content"][0]["text"] = "```json\n{}\n```"
        model, _ = self.model(raw=raw)
        with self.assertRaisesRegex(ModelError, "structured JSON"):
            model.decide({})

    def test_malformed_message_content_is_model_error(self):
        for content in (None, "wrong", {}):
            model, _ = self.model(raw={"output": [{"type": "message", "content": content}]})
            with self.subTest(content=content), self.assertRaises(ModelError):
                model.decide({})

    def test_incomplete_message_does_not_become_action(self):
        raw = response(decision())
        raw["output"][0]["status"] = "incomplete"
        model, _ = self.model(raw=raw)
        with self.assertRaisesRegex(ModelError, "not completed"):
            model.decide({})

    def test_failed_calls_consume_budget_and_never_retry(self):
        attempts = []

        def failing(payload):
            attempts.append(payload)
            raise TimeoutError("request timed out")

        model = OpenAIModel("test-secret-key", transport=failing, max_calls=1)
        with self.assertRaises(ModelError):
            model.decide({})
        with self.assertRaisesRegex(ModelError, "budget exhausted"):
            model.decide({})
        self.assertEqual(model.calls, 1)
        self.assertEqual(len(attempts), 1)

    def test_error_is_redacted(self):
        model, _ = self.model(raw={"error": {"message": "bad test-secret-key credential"}})
        with self.assertRaises(ModelError) as raised:
            model.decide({})
        self.assertNotIn("test-secret-key", str(raised.exception))
        self.assertIn("[REDACTED]", str(raised.exception))

    def test_context_secret_rejected_before_paid_request(self):
        model, sent = self.model(decision())
        with self.assertRaisesRegex(ModelError, "secrets"):
            model.decide({"accidental_key": "test-secret-key"})
        self.assertEqual(model.calls, 0)
        self.assertEqual(sent, [])

    def test_secret_in_output_rejected(self):
        model, _ = self.model({**decision(), "body": "test-secret-key"})
        with self.assertRaisesRegex(ModelError, "authentication secret"):
            model.decide({})

    def test_research_requires_actual_search_metadata(self):
        value = research_result()
        value["facts"] = [
            {"id": "f1", "text": "Public company fact", "source_url": "https://company.example/about#team"},
            {"id": "f2", "text": "Invented claim", "source_url": "https://invented.example/"},
        ]
        value["sources"] = [{"url": "https://invented.example/", "title": "Invented"}]
        value["hypotheses"] = [
            {"text": "Supported hypothesis", "supporting_fact_ids": ["f1"]},
            {"text": "Partly unsupported hypothesis", "supporting_fact_ids": ["f1", "f2"]},
            {"text": "Unsupported hypothesis", "supporting_fact_ids": ["f2"]},
        ]
        raw = response(value)
        raw["output"].insert(0, {"type": "web_search_call", "action": {"type": "search", "sources": [
            {"type": "url", "url": "https://company.example/about", "title": "Company"}]}})
        model, sent = self.model(raw=raw)
        result = model.research({"name": "Julius", "role": "Founder"})
        self.assertEqual([f["id"] for f in result["facts"]], ["f1"])
        self.assertEqual(result["facts"][0]["source_url"], "https://company.example/about")
        self.assertEqual(result["sources"], [{"url": "https://company.example/about", "title": "Company"}])
        self.assertEqual(result["hypotheses"], [{"text": "Supported hypothesis", "supporting_fact_ids": ["f1"]}])
        self.assertIn("Unverified research hypothesis: Partly unsupported hypothesis", result["unknowns"])
        self.assertEqual(result["provenance"]["rejected_fact_count"], 1)
        self.assertEqual(sent[0]["tools"], [{"type": "web_search"}])
        self.assertEqual(sent[0]["include"], ["web_search_call.action.sources"])

    def test_citation_annotations_can_verify_source(self):
        value = research_result()
        value["facts"] = [{"id": "f", "text": "Professional role", "source_url": "https://company.example/"}]
        raw = response(value)
        raw["output"][0]["content"][0]["annotations"] = [
            {"type": "url_citation", "url": "https://company.example/", "title": "Official"}]
        model, _ = self.model(raw=raw)
        self.assertEqual(len(model.research({})["facts"]), 1)

    def test_null_citation_metadata_is_ignored(self):
        raw = response(research_result())
        raw["output"][0]["content"][0]["annotations"] = None
        model, _ = self.model(raw=raw)
        self.assertEqual(model.research({})["sources"], [])

    def test_disabled_web_has_no_tools_or_verified_public_facts(self):
        value = research_result()
        value["facts"] = [{"id": "f", "text": "Unsourced", "source_url": "https://company.example/"}]
        model, sent = self.model(value, enable_web_search=False)
        result = model.research({"id": "julius", "role": "Founder"})
        self.assertNotIn("tools", sent[0])
        self.assertNotIn("include", sent[0])
        self.assertEqual(result["facts"], [])
        self.assertEqual(result["sources"], [])
        self.assertFalse(result["provenance"]["web_search_enabled"])

    def test_usage_is_aggregated(self):
        model, _ = self.model(raw=response(decision(), usage={"input_tokens": 10, "output_tokens": 6}))
        model.decide({})
        model.decide({})
        self.assertEqual(model.usage, {"input_tokens": 20, "output_tokens": 12})


if __name__ == "__main__":
    unittest.main()
