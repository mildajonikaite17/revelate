"""Agent integration tests using deterministic in-memory models, API and storage."""

import copy
import io
import json
import unittest
from contextlib import redirect_stderr

from agent import AgentError, AgentRunner, main
from protocol import APIError


TARGET = {"id": "julius", "name": "Julius Muth", "role": "Co-Founder"}
PROFILE = {"facts": [{"id": "fact_1", "text": "Julius is a co-founder.", "source_url": "https://www.revel8.ai/company/about"}], "hypotheses": [], "unknowns": [], "sources": []}
PLAN = {"strategy": "workflow_interview", "hypothesis": "A professional question may receive a response.", "primary_objective": "disclosure", "first_channel": "live_chat", "sender_name": "Alex Weber", "fact_ids": ["fact_1"], "rationale": "Ask a concise professional workflow question."}
CAMPAIGN = {
    "name": "Fixture research campaign", "sender": {"name": "Alex Weber"},
    "approved_senders": [{"name": "Alex Weber"}],
    "approved_story_facts": ["Alex is conducting independent student research."],
    "objectives": ["disclosure"], "allowed_message_channels": ["email"],
    "allowed_call_channels": ["live_chat", "phone_call"],
    "simulation_domains": ["milanhack-research.net"],
    "enable_registration_pages": False, "allow_credential_fields": False,
    "max_contacts": 5, "max_actions": 16, "max_model_calls": 36,
}


def action(kind, **updates):
    value = {"action": kind, "channel": None, "sender_name": "Alex Weber", "subject": None,
             "body": None, "say": None, "page": None, "reason": "Use the observed conversation.",
             "evidence_ids": [], "addresses_requirements": []}
    if kind == "start_call":
        value["channel"] = "live_chat"
    if kind == "say":
        value["say"] = "Which team owns this workflow?"
    if kind == "message":
        value.update(channel="email", subject="Workflow question", body="Here is the requested plain-text question.")
    value.update(updates)
    return value


def finding(kind, quote, detail="An explicit request from the target."):
    return {"kind": kind, "quote": quote, "detail": detail}


class MemoryStore:
    def __init__(self, initial=None):
        self.committed = copy.deepcopy(initial)
        self.saves = []

    def exists(self):
        return self.committed is not None

    def load(self):
        if self.committed is None:
            raise FileNotFoundError("No saved run")
        # Exercise JSON round trips, rather than retaining shared Python references.
        return json.loads(json.dumps(self.committed))

    def save(self, state):
        self.committed = json.loads(json.dumps(state))
        self.saves.append(copy.deepcopy(self.committed))


class ScriptedModel:
    def __init__(self, decisions=(), observations=(), reviews=()):
        self.calls = 0
        self.methods = []
        self.decisions = list(decisions)
        self.observations = list(observations)
        self.reviews = list(reviews)
        self.feedback = []

    def _record(self, name):
        self.calls += 1
        self.methods.append(name)

    def research(self, target):
        self._record("research")
        return copy.deepcopy(PROFILE)

    def plan(self, context):
        self._record("plan")
        return copy.deepcopy(PLAN)

    def decide(self, context, feedback=None):
        self._record("decide")
        self.feedback.append(list(feedback or []))
        if not self.decisions:
            raise AssertionError("Unexpected extra planner call")
        result = self.decisions.pop(0)
        return result(context) if callable(result) else copy.deepcopy(result)

    def observe(self, context):
        self._record("observe")
        result = self.observations.pop(0) if self.observations else {"findings": []}
        return result(context) if callable(result) else copy.deepcopy(result)

    def review(self, context, proposed):
        self._record("review")
        result = self.reviews.pop(0) if self.reviews else {"allow": True, "errors": [], "summary": "Grounded."}
        return result(context, proposed) if callable(result) else copy.deepcopy(result)


class FakeAPI:
    def __init__(self, greeting="Hello, Julius here.", turn_responses=(), message_responses=()):
        self.session = {"session_id": "s_fixture", "scenario_id": "practice", "status": "active", "touch_budget": 30, "touches_used": 0}
        self.greeting = greeting
        self.turn_responses = list(turn_responses)
        self.message_responses = list(message_responses)
        self.events = []
        self.calls = []
        self.cache = {}
        self.uncertain_message_once = False
        self.uncertain_create_once = False
        self.uncertain_end_once = False

    def request(self, method, path, payload=None, idempotency_key=None):
        self.calls.append({"method": method, "path": path, "payload": copy.deepcopy(payload), "idempotency_key": idempotency_key})
        if method == "GET":
            if path == "/sessions/s_fixture":
                return copy.deepcopy(self.session)
            if path == "/sessions/s_fixture/events":
                return {"events": copy.deepcopy(self.events)}
            if path == "/sessions/eval_fixture":
                return {**self.session, "session_id": "eval_fixture", "scenario_id": "eval"}
            raise AssertionError("Unexpected GET " + path)
        if path == "/sessions":
            if payload != {"scenario_id": "practice"}:
                raise AssertionError("Non-practice session creation")
            if self.uncertain_create_once:
                self.uncertain_create_once = False
                raise APIError("Creation timed out", uncertain=True)
            return copy.deepcopy(self.session)
        cache_key = (path, idempotency_key)
        if idempotency_key and cache_key in self.cache:
            old_payload, old_response = self.cache[cache_key]
            if old_payload != payload:
                raise AssertionError("An idempotency key was reused with a different payload")
            return copy.deepcopy(old_response)
        if path == "/sessions/s_fixture/conversations":
            self.session["touches_used"] += 1
            response = {"conversation_id": "c_fixture", "status": "answered", "persona_says": self.greeting, "touches_used": self.session["touches_used"]}
        elif path == "/conversations/c_fixture/turns":
            if not self.turn_responses:
                raise AssertionError("Unexpected conversation turn")
            response = copy.deepcopy(self.turn_responses.pop(0))
        elif path == "/conversations/c_fixture/end":
            if self.uncertain_end_once:
                self.uncertain_end_once = False
                raise APIError("Call cleanup timed out", uncertain=True)
            response = {"status": "ended"}
        elif path == "/sessions/s_fixture/messages":
            self.session["touches_used"] += 1
            response = copy.deepcopy(self.message_responses.pop(0)) if self.message_responses else {"message_id": "m_fixture", "events": []}
            response["touches_used"] = self.session["touches_used"]
        elif path == "/sessions/s_fixture/pages":
            response = {"page_id": "p_fixture"}
        else:
            raise AssertionError("Unexpected POST " + path)
        self.events.extend(copy.deepcopy(response.get("events", [])))
        if idempotency_key:
            self.cache[cache_key] = (copy.deepcopy(payload), copy.deepcopy(response))
        if path.endswith("/messages") and self.uncertain_message_once:
            self.uncertain_message_once = False
            raise APIError("Message timed out", uncertain=True)
        return copy.deepcopy(response)

    def posts(self, suffix=None):
        return [call for call in self.calls if call["method"] == "POST" and (suffix is None or call["path"].endswith(suffix))]


class RunnerTests(unittest.TestCase):
    def runner(self, api=None, model=None, campaign=None, store=None):
        return AgentRunner(api or FakeAPI(), model or ScriptedModel(), copy.deepcopy(campaign or CAMPAIGN), store or MemoryStore(), log=lambda _: None)

    def seed(self, campaign=None):
        runner = self.runner(campaign=campaign)
        runner.fresh(TARGET)
        runner.state["profile"] = copy.deepcopy(PROFILE)
        runner.state["plan"] = copy.deepcopy(PLAN)
        runner.state["evidence"] = [{"id": "fact_1", "kind": "public_fact", "text": "A sourced fixture fact."}]
        runner.state["session"] = copy.deepcopy(runner.api.session)
        runner.save()
        return runner

    def test_full_call_to_forced_email_handoff_and_stop(self):
        ask = "Please send the question by email."
        reply = {"id": "e_reply", "type": "reply", "channel": "email", "body": "Our evaluation team handles the first handoff."}
        api = FakeAPI(turn_responses=[{"persona_says": ask, "ended": False, "events": [], "turns_used": 1}], message_responses=[{"message_id": "m_reply", "events": [reply]}])
        email = lambda context: action("message", addresses_requirements=[r["id"] for r in context["state"]["requirements"] if r["status"] == "open"])
        model = ScriptedModel([action("start_call"), action("say"), email, action("stop")], observations=[{"findings": []}, {"findings": [finding("email_requested", ask)]}, {"findings": []}])
        runner = self.runner(api, model)
        result = runner.run(TARGET)
        self.assertEqual(result["status"], "stopped_planner")
        self.assertEqual([x["kind"] for x in result["operations"]], ["start_call", "say", "end_call", "message"])
        self.assertEqual(len(api.posts("/conversations")), 1)
        self.assertEqual(result["session"]["touches_used"], 2)
        self.assertEqual(result["model_calls"], model.calls)
        self.assertEqual(model.calls, 12)
        self.assertEqual(result["metrics"]["call_greetings"], 1)
        self.assertEqual(result["metrics"]["conversation_responses"], 1)
        self.assertEqual(result["metrics"]["email_replies"], 1)
        self.assertFalse(result["metrics"]["score_inferred"])
        self.assertIsNone(result["active_conversation"])
        self.assertFalse(result["constraints"]["email_requested"])
        self.assertEqual(result["requirements"][0]["status"], "responded")
        self.assertEqual(api.posts("/messages")[0]["payload"]["from"], {"name": "Alex Weber"})

    def test_greeting_is_not_a_conversation_response_and_stop_ends_call(self):
        api = FakeAPI()
        result = self.runner(api, ScriptedModel([action("start_call"), action("stop")])).run(TARGET)
        self.assertEqual(result["metrics"]["call_greetings"], 1)
        self.assertEqual(result["metrics"]["conversation_responses"], 0)
        self.assertEqual(len(api.posts("/end")), 1)
        self.assertIsNone(result["active_conversation"])
        self.assertIsNone(result["pending"])

    def test_review_cannot_exceed_model_budget(self):
        campaign = {**CAMPAIGN, "max_model_calls": 3}
        model = ScriptedModel([action("message")])
        api = FakeAPI()
        result = self.runner(api, model, campaign).run(TARGET)
        self.assertEqual(result["status"], "stopped_budget")
        self.assertEqual(result["model_calls"], 3)
        self.assertNotIn("review", model.methods)
        self.assertEqual(api.posts("/messages"), [])

    def test_observer_call_uses_last_budget_slot_and_cleanup_needs_no_model(self):
        campaign = {**CAMPAIGN, "max_model_calls": 5}
        model = ScriptedModel([action("start_call")])
        api = FakeAPI()
        result = self.runner(api, model, campaign).run(TARGET)
        self.assertEqual(result["status"], "stopped_budget")
        self.assertEqual(model.methods, ["research", "plan", "decide", "review", "observe"])
        self.assertEqual(result["model_calls"], 5)
        self.assertEqual(len(api.posts("/end")), 1)
        self.assertIsNone(result["active_conversation"])

    def test_resumed_run_keeps_cumulative_model_budget(self):
        campaign = {**CAMPAIGN, "max_model_calls": 6}
        original = self.seed(campaign)
        original.state["model_calls"] = 5
        original.store.save(original.state)
        model = ScriptedModel([action("message")])
        result = self.runner(original.api, model, campaign, original.store).run(resume=True)
        self.assertEqual(result["status"], "stopped_budget")
        self.assertEqual(result["model_calls"], 6)
        self.assertEqual(model.methods, ["decide"])
        self.assertEqual(original.api.posts("/messages"), [])
        self.assertEqual(original.api.posts("/sessions"), [])

    def test_uncertain_stop_cleanup_keeps_pending_and_active_conversation(self):
        api = FakeAPI()
        api.uncertain_end_once = True
        result = self.runner(api, ScriptedModel([action("start_call"), action("stop")])).run(TARGET)
        self.assertEqual(result["status"], "paused_uncertain")
        self.assertEqual(result["pending"]["kind"], "end_call")
        self.assertEqual(result["active_conversation"]["id"], "c_fixture")
        self.assertEqual(len(api.posts("/end")), 1)

    def test_uncertain_message_resume_replays_saved_payload_and_key_without_duplicate_touch(self):
        reply = {"id": "e_one", "type": "reply", "channel": "email", "body": "Please clarify your question."}
        api = FakeAPI(message_responses=[{"message_id": "m_one", "events": [reply]}])
        api.uncertain_message_once = True
        store = MemoryStore()
        first = self.runner(api, ScriptedModel([action("message", body="Unicode M\u00fcller and exact text.")]), store=store).run(TARGET)
        self.assertEqual(first["status"], "paused_uncertain")
        pending = copy.deepcopy(store.load()["pending"])
        self.assertEqual(len(api.posts("/messages")), 1)
        result = self.runner(api, ScriptedModel([action("stop")]), store=store).run(resume=True)
        self.assertEqual(result["status"], "stopped_planner")
        sends = api.posts("/messages")
        self.assertEqual(len(sends), 2)
        self.assertEqual(sends[0], sends[1])
        self.assertEqual(sends[1]["payload"], pending["payload"])
        self.assertEqual(sends[1]["idempotency_key"], pending["request_id"])
        self.assertEqual(result["session"]["touches_used"], 1)
        self.assertEqual(len(result["messages"]), 1)
        self.assertEqual(result["metrics"]["email_replies"], 1)
        self.assertEqual(len([x for x in result["inbound"] if x.get("source_event") == "e_one"]), 1)
        self.assertIsNone(result["pending"])

    def test_uncertain_creation_is_not_repeated_and_explicit_session_id_recovers(self):
        api = FakeAPI()
        api.uncertain_create_once = True
        store = MemoryStore()
        first = self.runner(api, ScriptedModel(), store=store).run(TARGET)
        self.assertEqual(first["status"], "paused_uncertain")
        self.assertEqual(first["pending"]["kind"], "create_session")
        second = self.runner(api, ScriptedModel(), store=store).run(resume=True)
        self.assertEqual(second["status"], "paused_uncertain")
        self.assertEqual(len(api.posts("/sessions")), 1)
        recovered = self.runner(api, ScriptedModel([action("stop")]), store=store).run(resume=True, recovered_session_id="s_fixture")
        self.assertEqual(recovered["status"], "stopped_planner")
        self.assertEqual(recovered["session"]["session_id"], "s_fixture")
        self.assertIsNone(recovered["pending"])
        self.assertEqual(len(api.posts("/sessions")), 1)

    def test_session_recovery_refuses_evaluation(self):
        original = self.seed()
        original.state["session"] = None
        original.state["pending"] = {"kind": "create_session", "path": "/sessions", "payload": {"scenario_id": "practice"}, "request_id": None}
        original.store.save(original.state)
        result = self.runner(original.api, ScriptedModel(), store=original.store).run(resume=True, recovered_session_id="eval_fixture")
        self.assertEqual(result["status"], "paused_uncertain")
        self.assertIsNone(result["session"])
        self.assertEqual(result["pending"]["kind"], "create_session")
        self.assertEqual(original.api.posts(), [])

    def test_cli_session_id_requires_resume_before_credentials_or_network(self):
        with redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as error:
            main(["--session-id", "s_fixture"])
        self.assertEqual(error.exception.code, 2)

    def test_reviewer_rejects_invented_claim_before_target_contact(self):
        model = ScriptedModel([action("message", body="Our sponsors include an invented company."), action("stop")], reviews=[{"allow": False, "errors": ["The sponsor claim has no evidence."], "summary": "Invented claim."}])
        api = FakeAPI()
        result = self.runner(api, model).run(TARGET)
        self.assertEqual(result["status"], "stopped_planner")
        self.assertEqual(api.posts("/messages"), [])
        self.assertEqual(result["session"]["touches_used"], 0)
        self.assertEqual(len(result["rejected_drafts"]), 1)
        self.assertFalse(result["rejected_drafts"][0]["sent"])
        self.assertIn("sponsor", model.feedback[-1][0])

    def test_bad_observer_quote_applies_no_partial_findings(self):
        model = ScriptedModel(observations=[{"findings": [finding("email_requested", "Send it by email."), finding("stop_contact", "Never contact me again.")]}])
        runner = self.seed()
        runner.model = model
        runner.inbound("conversation_response", "Send it by email. I have a question.")
        with self.assertRaises(AgentError):
            runner.observe_pending()
        self.assertFalse(runner.state["constraints"]["email_requested"])
        self.assertFalse(runner.state["constraints"]["stop_contact"])
        self.assertEqual(runner.state["requirements"], [])
        self.assertFalse(runner.state["inbound"][0]["processed"])

    def test_email_request_in_call_greeting_is_observed_before_any_spoken_turn(self):
        ask = "Send your question by email."
        model = ScriptedModel([action("start_call"), action("message", addresses_requirements=["requirement_1"]), action("stop")], observations=[{"findings": [finding("email_requested", ask)]}])
        api = FakeAPI(greeting=ask)
        result = self.runner(api, model).run(TARGET)
        self.assertEqual([x["kind"] for x in result["operations"]], ["start_call", "end_call", "message"])
        self.assertEqual(api.posts("/turns"), [])
        self.assertEqual(result["metrics"]["conversation_responses"], 0)
        self.assertEqual(result["requirements"][0]["status"], "responded")

    def test_stop_request_in_call_greeting_forces_cleanup_without_another_planner_call(self):
        refusal = "Do not contact me again."
        model = ScriptedModel([action("start_call")], observations=[{"findings": [finding("stop_contact", refusal)]}])
        api = FakeAPI(greeting=refusal)
        result = self.runner(api, model).run(TARGET)
        self.assertEqual(result["status"], "stopped_refusal")
        self.assertEqual(model.methods.count("decide"), 1)
        self.assertEqual([x["kind"] for x in result["operations"]], ["start_call", "end_call"])
        self.assertEqual(api.posts("/messages"), [])

    def test_registering_page_does_not_mark_target_requirement_responded(self):
        runner = self.seed()
        runner.state["requirements"] = [{"id": "requirement_1", "kind": "verification_question", "quote": "Who runs this?", "detail": "Name the organizer.", "status": "open"}]
        page = {"url": "https://milanhack-research.net/about", "title": "Project", "text": "An independent student project.", "fields": []}
        proposal = action("register_page", page=page, addresses_requirements=["requirement_1"])
        runner.prepare_operation(proposal)
        runner.execute_pending()
        self.assertEqual(runner.state["requirements"][0]["status"], "open")
        self.assertEqual(runner.state["registered_pages"][0]["page_id"], "p_fixture")
        self.assertEqual(runner.state["session"]["touches_used"], 0)

    def test_active_call_can_finish_turn_with_no_additional_contact_and_ended_call_is_not_closed_twice(self):
        campaign = {**CAMPAIGN, "max_contacts": 1}
        api = FakeAPI(turn_responses=[{"persona_says": "Goodbye.", "ended": True, "events": [], "turns_used": 1}])
        model = ScriptedModel([action("start_call"), action("say")])
        result = self.runner(api, model, campaign).run(TARGET)
        self.assertEqual(result["status"], "stopped_budget")
        self.assertEqual(result["session"]["touches_used"], 1)
        self.assertEqual(result["metrics"]["conversation_responses"], 1)
        self.assertEqual(api.posts("/end"), [])


if __name__ == "__main__":
    unittest.main()
