"""Protocol regression tests. All HTTP traffic is replaced by in-memory transports."""

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from protocol import API_BASE, APIError, RunStore, TargetAPI, _NoRedirect


KEY = "fixture_team_key_not_a_real_credential"


class FakeTransport:
    def __init__(self, outcomes):
        self.outcomes = list(outcomes)
        self.calls = []

    def __call__(self, method, url, headers, body, timeout):
        self.calls.append((method, url, headers, body, timeout))
        outcome = self.outcomes.pop(0)
        if isinstance(outcome, Exception):
            raise outcome
        return outcome


class TargetAPITests(unittest.TestCase):
    def test_unicode_json_headers_and_fixed_origin(self):
        transport = FakeTransport([(201, {}, b'{"message_id":"m_1"}')])
        api = TargetAPI(KEY, transport=transport)
        payload = {"to": "tom", "body": "Hello M\u00fcller \u2014 caf\u00e9"}
        self.assertEqual(api.request("POST", "/sessions/s_1/messages", payload, "request-1"), {"message_id": "m_1"})
        method, url, headers, body, timeout = transport.calls[0]
        self.assertEqual((method, url, timeout), ("POST", API_BASE + "/sessions/s_1/messages", 120))
        self.assertEqual(headers["Authorization"], "Bearer " + KEY)
        self.assertEqual(headers["Idempotency-Key"], "request-1")
        self.assertIn("charset=utf-8", headers["Content-Type"])
        self.assertEqual(json.loads(body.decode("utf-8")), payload)
        self.assertIn("M\u00fcller".encode("utf-8"), body)

    def test_timeout_retries_identical_idempotent_body(self):
        transport = FakeTransport([TimeoutError("timed out"), (200, {}, b'{"ok":true}')])
        sleeps = []
        api = TargetAPI(KEY, transport=transport, sleep=sleeps.append)
        self.assertEqual(api.request("POST", "/sessions/s_1/messages", {"body": "first"}, "fixed-id"), {"ok": True})
        self.assertEqual(len(transport.calls), 2)
        self.assertEqual(transport.calls[0], transport.calls[1])
        self.assertEqual(sleeps, [1.0])

    def test_reordered_pending_payload_serializes_to_identical_bytes(self):
        transport = FakeTransport([(200, {}, b"{}"), (200, {}, b"{}")])
        api = TargetAPI(KEY, transport=transport)
        api.request("POST", "/sessions/s_1/messages", {"body": "hello", "from": {"name": "MilanHack"}, "to": "julius"}, "same")
        api.request("POST", "/sessions/s_1/messages", {"to": "julius", "from": {"name": "MilanHack"}, "body": "hello"}, "same")
        self.assertEqual(transport.calls[0][3], transport.calls[1][3])
        self.assertEqual(transport.calls[0][2]["Idempotency-Key"], transport.calls[1][2]["Idempotency-Key"])

    def test_session_creation_never_retries_even_with_idempotency(self):
        transport = FakeTransport([TimeoutError("timed out")])
        api = TargetAPI(KEY, transport=transport, sleep=lambda _: self.fail("Unexpected retry"))
        with self.assertRaises(APIError) as error:
            api.request("POST", "/sessions", {"scenario_id": "practice"}, "unused-for-retry")
        self.assertTrue(error.exception.uncertain)
        self.assertFalse(error.exception.retryable)
        self.assertEqual(len(transport.calls), 1)

    def test_post_without_idempotency_never_retries(self):
        transport = FakeTransport([(503, {}, b'{"error":"busy"}')])
        api = TargetAPI(KEY, transport=transport)
        with self.assertRaises(APIError) as error:
            api.request("POST", "/conversations/c_1/turns", {"say": "Hello"})
        self.assertEqual(error.exception.status, 503)
        self.assertTrue(error.exception.uncertain)
        self.assertFalse(error.exception.retryable)
        self.assertEqual(len(transport.calls), 1)

    def test_get_retry_after_is_bounded_and_case_insensitive(self):
        transport = FakeTransport([(429, {"retry-after": "99999"}, b"busy"), (200, {}, b"[]")])
        sleeps = []
        api = TargetAPI(KEY, transport=transport, sleep=sleeps.append)
        self.assertEqual(api.request("GET", "/scenarios"), [])
        self.assertEqual(sleeps, [10.0])

    def test_definite_failures_are_not_retried_and_errors_hide_key(self):
        for status in (400, 401, 403, 404, 409, 413, 415, 422):
            with self.subTest(status=status):
                transport = FakeTransport([(status, {}, ("failure " + KEY).encode())])
                with self.assertRaises(APIError) as error:
                    TargetAPI(KEY, transport=transport).request("POST", "/sessions/s_1/messages", {}, "same")
                self.assertEqual(error.exception.status, status)
                self.assertFalse(error.exception.uncertain)
                self.assertFalse(error.exception.retryable)
                self.assertNotIn(KEY, str(error.exception))
                self.assertEqual(len(transport.calls), 1)

    def test_network_error_message_hides_key(self):
        transport = FakeTransport([TimeoutError("timeout " + KEY)])
        with self.assertRaises(APIError) as error:
            TargetAPI(KEY, transport=transport, max_attempts=1).request("GET", "/scenarios")
        self.assertNotIn(KEY, error.exception.message)

    def test_eval_and_alternate_session_creation_routes_are_rejected(self):
        transport = FakeTransport([])
        api = TargetAPI(KEY, transport=transport)
        cases = [("/sessions", {"scenario_id": "eval"}), ("/sessions", {}), ("/sessions/", {"scenario_id": "practice"}), ("/sessions/eval", {"scenario_id": "practice"})]
        for path, payload in cases:
            with self.subTest(path=path, payload=payload), self.assertRaises(ValueError):
                api.request("POST", path, payload)
        self.assertEqual(transport.calls, [])

    def test_external_or_query_paths_are_rejected_before_transport(self):
        transport = FakeTransport([])
        api = TargetAPI(KEY, transport=transport)
        for path in ("https://example.org/v1/scenarios", "//example.org/scenarios", "/scenarios?x=1", "/../scenarios", "/scenarios\n", "/sessions//new"):
            with self.subTest(path=path), self.assertRaises(ValueError):
                api.request("GET", path)
        self.assertEqual(transport.calls, [])

    def test_redirect_is_refused_and_never_retried(self):
        self.assertIsNone(_NoRedirect().redirect_request(None, None, 302, "Found", {}, "https://example.org"))
        transport = FakeTransport([(302, {"Location": "https://example.org"}, b"")])
        with self.assertRaises(APIError) as error:
            TargetAPI(KEY, transport=transport).request("GET", "/scenarios")
        self.assertEqual(error.exception.status, 302)
        self.assertFalse(error.exception.retryable)
        self.assertEqual(len(transport.calls), 1)

    def test_invalid_json_write_response_is_uncertain(self):
        transport = FakeTransport([(200, {}, b"not json")])
        with self.assertRaises(APIError) as error:
            TargetAPI(KEY, transport=transport).request("POST", "/sessions/s_1/messages", {}, "same")
        self.assertTrue(error.exception.uncertain)
        self.assertFalse(error.exception.retryable)


class RunStoreTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.path = Path(self.temporary.name) / "runs" / "state.json"
        self.store = RunStore(self.path, secrets=(KEY,))

    def test_first_and_repeated_saves(self):
        self.assertFalse(self.store.exists())
        self.store.save({"version": 1})
        self.assertTrue(self.store.exists())
        self.assertEqual(self.store.load(), {"version": 1})
        self.store.save({"version": 2})
        self.assertEqual(self.store.load(), {"version": 2})
        self.assertEqual(list(self.path.parent.glob("*.tmp")), [])

    def test_unicode_and_exact_pending_json_survive_round_trip(self):
        pending_json = '{ "say" : "M\u00fcller \\n next", "spacing": [ 1,  2 ] }'
        state = {"name": "M\u00fcller", "pending": {"json": pending_json, "request_id": "same-id"}}
        self.store.save(state)
        self.assertEqual(self.store.load(), state)
        self.assertEqual(self.store.load()["pending"]["json"], pending_json)

    def test_secret_rejection_preserves_last_committed_file(self):
        self.store.save({"safe": True})
        original = self.path.read_bytes()
        for state in ({"body": KEY}, {KEY: "value"}, {"pending": {"json": json.dumps({"body": "prefix " + KEY})}}):
            with self.subTest(state_type=type(state).__name__), self.assertRaises(ValueError) as error:
                self.store.save(state)
            self.assertNotIn(KEY, str(error.exception))
            self.assertEqual(self.path.read_bytes(), original)

    def test_replace_failure_preserves_committed_state_and_removes_temp(self):
        self.store.save({"pending": {"json": "original", "request_id": "unchanged"}})
        original = self.path.read_bytes()
        with patch("protocol.os.replace", side_effect=OSError("replace denied")):
            with self.assertRaises(OSError):
                self.store.save({"pending": None})
        self.assertEqual(self.path.read_bytes(), original)
        self.assertEqual(self.store.load()["pending"]["request_id"], "unchanged")
        self.assertEqual(list(self.path.parent.glob("*.tmp")), [])

    def test_write_fsync_failure_preserves_committed_state(self):
        self.store.save({"version": 1})
        original = self.path.read_bytes()
        with patch("protocol.os.fsync", side_effect=OSError("disk write failed")):
            with self.assertRaises(OSError):
                self.store.save({"version": 2})
        self.assertEqual(self.path.read_bytes(), original)
        self.assertEqual(list(self.path.parent.glob("*.tmp")), [])

    def test_load_rejects_secret_and_non_object_state(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text(json.dumps({"key": KEY}), encoding="utf-8")
        with self.assertRaises(ValueError):
            self.store.load()
        self.path.write_text("[]", encoding="utf-8")
        with self.assertRaises(ValueError):
            self.store.load()


if __name__ == "__main__":
    unittest.main()
