@echo off
setlocal DisableDelayedExpansion
title MilanHack - Offline agent tests
cd /d "%~dp0"
set "AGENT_TEST_PYTHON="
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
  if not errorlevel 1 set "AGENT_TEST_PYTHON=py -3"
)
if defined AGENT_TEST_PYTHON goto run_tests
where python >nul 2>nul
if not errorlevel 1 (
  python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
  if not errorlevel 1 set "AGENT_TEST_PYTHON=python"
)
if defined AGENT_TEST_PYTHON goto run_tests
echo Python 3.10 or newer is required. Install it from python.org/downloads/windows/.
echo Choose Add Python to PATH during installation, then open this file again.
set "AGENT_TEST_EXIT=1"
goto finished

:run_tests
echo Running offline tests. No keys, target contacts or paid model calls are needed.
echo.
%AGENT_TEST_PYTHON% -m unittest discover -s tests -p "test_*.py" -v
set "AGENT_TEST_EXIT=%errorlevel%"
echo.
if "%AGENT_TEST_EXIT%"=="0" (
  echo All offline tests passed.
) else (
  echo Tests failed. Copy the error text for your technical teammate.
)

:finished
echo.
pause
exit /b %AGENT_TEST_EXIT%
