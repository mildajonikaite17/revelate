# MilanHack — Autonomous revel8 Practice Agent (v6)

This program connects your team to the organizers' AI-twin simulator and uses OpenAI to choose what to do next. After you start a run, it researches public professional context, selects an approach and sender, writes messages, reads replies, remembers requirements, and adapts its next action without asking you to write each turn.

It uses the **existing keys you already have**. You do not need to create a new key.

| Existing credential | What it does | Where the program gets it |
| --- | --- | --- |
| Organizer TEAM KEY | Identifies your team to the Target API; simulator actions are logged for that team. | `REVEL8_TEAM_KEY`, or a hidden prompt when you start. |
| OpenAI API key | Lets the program request research, plans, next actions, observations and reviews. | `OPENAI_API_KEY`, or a separate hidden prompt. |

The organizer key does not authenticate to OpenAI. ChatGPT in your browser helps develop and inspect the program; this autonomous runner uses the OpenAI API directly. OpenAI API requests and web-search tools may use your account's paid API balance.

## Start on Windows

1. Download the repository ZIP and **extract it** into a normal folder.
2. Install **Python 3.10 or newer** if it is not installed. Enable **Add Python to PATH** during installation.
3. Double-click **`RUN_AGENT.bat`**.
4. If prompted, paste your existing organizer TEAM KEY and press Enter. Characters are hidden.
5. If prompted, paste your existing OpenAI API key and press Enter. Characters are hidden.
6. Leave the window open. The agent makes the remaining conversation decisions itself and prints each chosen action and its short reason.

If the keys are already set in your environment, those prompts are skipped. They are not written into the campaign or saved run files. No Python packages or SDK installation is required.

The default starts a **fresh practice session for Julius**. It does not continue an old manual client or v5 conversation. It never starts an evaluation session.

To run another option, open PowerShell in the extracted folder:

```powershell
# Default: one fresh Julius practice run.
.\RUN_AGENT.bat

# One fresh practice session per currently available AI twin, in sequence.
.\RUN_AGENT.bat --targets all

# Choose a target returned by the practice scenario.
.\RUN_AGENT.bat --targets robert

# Skip public web research; keep the scenario identity/role and mark unknowns.
.\RUN_AGENT.bat --no-web-search

# See the available command-line options without starting a run.
py -3 agent.py --help
```

Running the launcher again without `--resume` starts another fresh run. Do not launch multiple copies for the same saved run.

On macOS or Linux, open a terminal in the extracted folder and run `python3 agent.py` or `python3 agent.py --targets all` with Python 3.10 or newer.

## What to enter, and where

You **do not paste chat messages into Notepad or manually call the Target API**. The model creates those messages and adapts them after each reply.

| Input or output | Location | How to use it |
| --- | --- | --- |
| Existing keys | Environment variables or hidden startup prompts | Authentication only; never put them in source files or GitHub. |
| Campaign story, approved senders and limits | `campaign.json` | Edit before a new run to define what the agent is allowed to claim and attempt. |
| Target selection | `--targets julius`, `--targets robert`, or `--targets all` | Use target IDs supplied by the organizers' current practice scenario. |
| Conversation history and durable memory | `runs/<run-name>.json` | Saved automatically; used by `--resume`. Do not manually paste into it. |
| Readable transcript and observed outcomes | `runs/<run-name>.md` | Open after a run to inspect sent actions and replies. Share a reviewed copy with your team if needed. |

The current campaign uses an independent student workflow-research pretext. It asks for a short answer directly in the conversation or by email. It has no confirmed event, sponsors, speakers, past participants or organizing legal entity. Registration pages and credential fields are disabled by default.

Public research facts and the fictional campaign story have different roles: public facts need retrieved-source URLs; a permitted fictional identity comes from the campaign configuration. A page created by the agent is not independent evidence that an organization exists. Unsupported claims must be revised before sending.

## What makes it autonomous

The program runs a bounded loop:

1. **Research and plan:** gather public professional context, keep facts separate from hypotheses, choose a strategy, first channel and one approved sender. The sender then stays fixed for the run.
2. **Observe and remember:** extract requirements from actual replies, including requests for email or plain text, registration objections, verification questions and requests to stop. Store evidence with the conversation history.
3. **Decide:** choose the next message, conversational turn, channel transition or stop action using that memory and the remaining budget.
4. **Check and review:** run deterministic checks and a separate model review. Revise rejected drafts before sending, up to the configured attempt limit.
5. **Send and repeat:** call the simulator API, save its result, then make the next decision.

A phone-call action here is a text-based conversation with the simulator. The program does not place real phone calls or clone voices. Initial pages, if explicitly enabled in a future campaign, are simulator resources; their text matters, not CSS design.

## Limits and model settings

The supplied `campaign.json` sets these limits **per target run**:

| Setting | Default | Meaning |
| --- | --- | --- |
| `max_contacts` | `5` | Maximum contacts, also capped by the server's contact budget. |
| `max_actions` | `16` | Maximum normal outbound operations; conversational turns and page registration count too. A final end-call cleanup may add one operation. |
| `max_model_calls` | `36` | Maximum OpenAI requests across research, planning, observation, decisions and review. A failed attempted request still counts. |
| `max_output_tokens` | `2200` | Output-token limit for each model response. |
| `model` | `gpt-4.1` | The existing project's model setting. |
| `enable_web_search` | `true` | Permit public web research during the research step only. |

The campaign's `objectives` currently contains only `disclosure`. Its `objective_description` asks for one specific internal fact about systems, processes or plans that is absent from verified public research. Other objectives supported by the simulator are not enabled by this configuration. Adding an objective or changing a pretext also requires the relevant policy checks to permit it; editing a string alone does not bypass those checks.

Use a model available to your OpenAI project. If `gpt-4.1` is unavailable, change `model` in `campaign.json` or supply your chosen compatible model explicitly:

```powershell
.\RUN_AGENT.bat --model YOUR_AVAILABLE_MODEL_ID
```

The program does not automatically switch models. A replacement must support the Responses API and structured JSON output; public research also needs the web-search tool. Test changes to the story or limits with a new run; resumed conversations restore their saved campaign context.

## Reading the result

The window prints the saved JSON and Markdown paths. The transcript records actual API operations and responses. The summary counts observed events such as email replies, other message replies, conversation responses, opened links and submitted forms.

A link opening is only a link opening. A candidate internal detail is marked as unverified. These observations **are not an official score**, proof of sensitive disclosure, or proof that credentials were captured. The organizer's evaluation determines scoring.

Review the target's actual words and which requests the agent answered. A refused registration proposal may justify another permitted approach; a request to stop contact ends the attempt. A lack of email replies does not establish that every channel is exhausted.

## Resume and uncertain API outcomes

The program saves state before an outbound request. If the connection fails after a request may have reached the server, the saved operation remains pending. Resume the **same v6 JSON file** so the runner can inspect that state and reuse a documented idempotency key where appropriate:

```powershell
.\RUN_AGENT.bat --resume ".\runs\YOUR_RUN.json"
```

Messages, conversation starts and turns reuse the saved idempotency key and exact payload. A pending page registration reuses its exact URL and content; the API documents this as replacing the page at that URL. A pending end-call request is retried only as cleanup. If that cleanup receives an ambiguous HTTP 409, the runner retains the unresolved state and sends no further contact. Do not delete a pending operation to force a new request.

If **session creation** had an uncertain outcome, ask the organizers to identify the practice session created for your team. Only after you know that exact session ID, attach it to the saved run:

```powershell
.\RUN_AGENT.bat --resume ".\runs\YOUR_RUN.json" --session-id s_KNOWN_SESSION_ID
```

`--session-id` is specifically for recovering uncertain creation. It is not a way to import an arbitrary old session, a manual-client run, or a v5 history. For an unresolved end-call rejection, inspect the server state with the organizers rather than repeatedly relaunching the same run.

If authentication fails, check that you used the organizer key for the simulator and the OpenAI key for the model. A browser opened directly to an authenticated API endpoint does not automatically send the required authorization header; this program sends it for you.

## Tests and current validation

Double-click **`TEST_AGENT.bat`**, or run:

```powershell
py -3 -m unittest discover -s tests -p "test_*.py" -v
```

These are offline tests with fake APIs and fake model responses. They exercise request construction, state recovery, provenance checks, requirements, budget limits and metrics without spending API credits or contacting a target.

Release validation: all 70 offline tests passed on Python 3.12. The Windows launchers were reviewed here but could not be run on Windows in this environment.

This release has **not been tested against the live organizer API or with paid OpenAI calls**. Passing offline tests establishes the tested program behavior, not a demonstrated successful conversation or score.

## Upload the files to your shared GitHub repository

1. Open the repository you already created.
2. Choose **Add file → Upload files**.
3. Upload `agent.py`, `models.py`, `protocol.py`, `policy.py`, `campaign.json`, `RUN_AGENT.bat`, `TEST_AGENT.bat`, `README.md`, and `.gitignore`. Preserve the `tests/` folder and its contents.
4. Commit the upload. Teammates can then use **Code → Download ZIP**, extract it, and follow the Windows steps above.

Do not upload keys, environment files, the `runs/` folder, or raw transcripts containing sensitive scenario results. Git ignores are useful for command-line commits, but **GitHub's browser uploader does not enforce `.gitignore`**: select files carefully. The run files remain local for inspection and recovery.

## Relationship to the earlier client

This is a standalone **v6 successor**, not an in-place patch of the old v5 script: the v5 source was not supplied. The available v5 logs showed invented organizer/participant claims and replies that did not consistently respect target objections. This implementation adds source provenance, an approved pretext, fixed sender identity, reply-based memory and draft checks to address those problems.

The human-assisted PowerShell client remains a separate workflow. This program replaces its turn-by-turn copying with model decisions and saved state.

Organizer API documentation: [docs.md](https://target-api.apps.01.cf.eu01.stackit.cloud/docs.md). OpenAI integration references: [Responses structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs) and [web search](https://developers.openai.com/api/docs/guides/tools-web-search).
