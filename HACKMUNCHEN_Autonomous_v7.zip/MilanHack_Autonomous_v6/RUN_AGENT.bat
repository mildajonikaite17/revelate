@echo off
setlocal DisableDelayedExpansion
title MilanHack - Autonomous practice agent
cd /d "%~dp0"
set "AGENT_RUN_PYTHON="
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
  if not errorlevel 1 set "AGENT_RUN_PYTHON=py -3"
)
if defined AGENT_RUN_PYTHON goto run_agent
where python >nul 2>nul
if not errorlevel 1 (
  python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
  if not errorlevel 1 set "AGENT_RUN_PYTHON=python"
)
if defined AGENT_RUN_PYTHON goto run_agent
echo Python 3.10 or newer is required. Install it from python.org/downloads/windows/.
echo Choose Add Python to PATH during installation, then open this file again.
set "AGENT_RUN_EXIT=1"
goto finished

:run_agent
%AGENT_RUN_PYTHON% agent.py %*
set "AGENT_RUN_EXIT=%errorlevel%"

:finished
echo.
pause
exit /b %AGENT_RUN_EXIT%
