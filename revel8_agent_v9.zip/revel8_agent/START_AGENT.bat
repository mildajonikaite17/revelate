@echo off
cd /d "%~dp0"
echo Installing or checking Python packages...
py -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo.
echo Starting the practice agent. Keys will be hidden as you paste them.
py agent.py %*
echo.
pause
exit /b
:failed
echo Installation failed. Copy the error message for help.
pause
