# User-supplied reference guide

Extracted from the attached document. This is a design reference; referenced scoring documents were not independently inspected here.

Revel8 scenario selection guide

Organisation size seniority sector and employment type

21 November 2026

We will choose a simulation story by the work an assigned twin actually does. Organisation size, sector, job function, seniority and employment type help us choose a starting point. Verified public facts and the twin's replies determine whether we continue with it.

The matrices in this guide are proposed design options. They do not establish that one group is easier to deceive, or that a scenario will succeed.

How to use this guide

Build a short profile from public professional sources and the assigned target information.

Check the person's operating team and employment relationship before assuming an internal hierarchy.

Select one relevant scenario and one permitted simulation objective.

Keep a consistent sender, story and resource. Adapt to observed replies and events.

Stop at a confirmed objective or the run limit, and retain the evidence for the demo.

Challenge boundaries

The supplied brief specifies three scoring runs of up to ten contacts each, alongside unlimited practice sessions. Keep the limit configurable and use the API's definition of a contact. All contact must remain inside Revel8. [1]

Use the simulated channels. Do not call real HR staff, collect their voices or email real departments.

Use sender and landing-page domains allowed by the challenge, outside real organisations' own domains.

The agent must write, send and decide autonomously during scoring. Prompt injection voids a run; attachments are simulated file names, with no real malware. [1, 2]

Why work context matters

NIST's Phish Scale considers the recipient's work context when assessing human phishing-detection difficulty. This supports examining relevance; it does not provide a validated success predictor for Revel8 twins. [3]

1 Build the person profile

Collect enough evidence to make a relevant decision. Keep a source URL, publication date when available, and a confidence label for each fact. Confirm that similarly named people have not been mixed together.

Dimension

What to record

How it changes the scenario

Employment relationship

Employee, owner, independent, contractor, partner or volunteer.

Determines which internal or external relationships can reasonably exist.

Sector and service

What the organisation or practice actually provides.

Sets the vocabulary, work topics and relevant resources.

Organisation and unit

Whole organisation plus local team, branch or project.

Prevents treating a small unit as a large bureaucracy.

Job function

HR, engineering, administration, operations or another function.

Connects the request to the person's actual work.

Seniority and authority

Title, responsibilities and evidenced decision rights.

Distinguishes reviewing, advising, processing and approving.

Professional focus

Current projects, published talks or work interests.

Provides a specific topic when verified.

Work relationships

Publicly documented clients, suppliers or collaborators.

Helps assess whether an external approach fits.

Tenure and changes

A publicly evidenced new role, project or service change.

May support an orientation or process-review scenario.

Language and location

Professional language and relevant operating location.

Helps match terms, dates and institutional context.

Process evidence

Named tools or workflows explicitly mentioned in sources.

Avoids inventing a portal, policy or software stack.

Unknowns

Any missing detail that the proposed story depends on.

Triggers a simpler scenario or further research.

Objective and budget

Permitted outcome and contacts remaining.

Keeps the request bounded and measurable.

Separate facts from interpretations

A public talk about international expansion is a fact. The conclusion that expansion is the person's highest priority is a hypothesis. Mark the distinction and update the hypothesis when the twin responds.

Use professional context. Do not infer vulnerability from age, gender, nationality, health, family circumstances or other sensitive personal traits. Unknown information should remain unknown.

2 Account for organisation size

Use these working bands for the prototype. They are design categories, not legal definitions of business size. Count the relevant operating unit as well as the parent organisation.

Working category

Context to check

Candidate scenario

Independent personOne person

They may handle delivery, sales and administration personally.

Review a professional profile, sample project brief or sector resource.

Very small team2 to 9 people

Colleagues may know each other closely; formal departments may be absent.

Review an external directory entry or a role-relevant draft guide.

Small organisation10 to 49 people

Some roles may be specialised; formal processes vary.

Review a service or onboarding guide when there is evidence it fits.

Medium organisation50 to 249 people

Separate teams may need handovers or shared orientation.

Organisation knowledge or a cross-team process review.

Large organisation250 or more people

The relevant team, subsidiary or branch may be much smaller.

Department orientation or a specialist resource suited to the unit.

Network or distributed groupAny total size

A franchise, federation or partnership can combine local autonomy with a large brand.

Clarify the local unit and the central function before choosing.

Size is not structure

A three-person branch of a national employer can have central training. A three-person independent consultancy may have no HR function. An outsourced HR service can exist even where there is no internal HR employee. Record what the evidence supports.

When the organisation quiz fits

It has a clear purpose, such as orientation across departments or service routing.

The recipient has a reason to participate or review the questions.

Questions match the relevant unit rather than unrelated parts of a parent group.

For a three-person business, start with a useful review task unless research establishes a real need for a knowledge assessment. A generic quiz should not be the default merely because the person has an employer.

3 Account for employment relationships

Employment type changes who can reasonably give instructions and which resources are relevant. It is separate from sector and seniority: an independent engineer and a hospital employee can both be technical specialists.

Relationship

What to establish

How to adapt

Employee

Employer, team and actual responsibilities.

Choose a team or work-process scenario supported by those responsibilities.

Founder or working owner

Whether they run the business and which tasks they handle.

Consider a company profile, external resource or project review.

Sole trader or freelancer

Their service, professional practice and public work.

Use an external counterpart and a relevant sample brief or profile review.

Independent consultant

Their expertise and whether a client assignment is public.

Use a professional resource review; do not invent a client relationship.

Contractor or agency worker

Legal employer, host institution and assignment.

Separate the agency's processes from the client's processes.

Partner or practice member

The partnership's structure and the person's responsibilities.

Use a practice or project scenario; do not assume a conventional boss.

Board member or adviser

Advisory remit and any actual operational authority.

Use a briefing review rather than an assumed staff task.

Volunteer or association member

Their function, team and level of commitment.

Use a relevant service or event guide; do not assume payroll or staff systems.

For a person working independently

Start with the service they provide. A designer could review a fictional project brief; a translator could review a sample language brief; an independent IT consultant could review an integration guide. These are possible simulated requests, not evidence of actual clients or projects.

Do not invent internal colleagues, mandatory employee training or an HR team. The questionnaire can become a review of the person's public profile or a professional resource, with its purpose stated consistently.

For a contractor inside a large institution

The host organisation's size does not automatically give the contractor the same access or responsibilities as permanent staff. Select a request they could reasonably assess within the evidenced assignment.

4 Account for seniority and authority

Use seniority to adjust the scope of a task. Use evidence of responsibility to decide whether the person can actually carry it out. Titles alone do not establish system access, budget control or approval rights.

Position

Scope to verify

Possible simulation task

Intern or new starter

Current team, orientation needs and assigned duties.

Complete or review a short role-specific orientation exercise.

Individual contributor

The work they personally perform.

Review a guide, sample brief or technical example relevant to that work.

Team leader or supervisor

Coordination duties and team processes.

Review a handover guide or responsibility map.

Department head or manager

The department's remit and actual decision rights.

Review a cross-team process or departmental briefing.

Director or senior executive

Institutional priorities and delegated responsibilities.

Review a concise sector briefing or coordination proposal.

Founder or owner

Operating responsibilities and the organisation's stage.

Review an external business profile or a project resource.

Nonexecutive adviser or board member

Advisory role versus management authority.

Review a briefing connected to the advisory remit.

Check the requested action

A person who can review a document may not be able to approve a process change. A senior title does not mean they personally handle onboarding, technical integration or purchasing. An individual contributor may have specialist knowledge without management authority.

Treat verification as evidence

If the twin asks who commissioned the activity or why they were selected, record the question. Answer within the established story and avoid inventing an existing relationship or approval. A request for verification is not proof that the twin is interested or that the approach is working.

Avoid assumptions about susceptibility

Do not label junior people as easy targets or senior people as too busy to check. Use observed behaviour and verified work context. The category helps select a relevant starting task; it does not establish the person's judgement.

5 Adapt the scenario by sector

Sector changes the vocabulary and work context. Job function still matters: an accountant in a hospital may handle work closer to an accountant in another sector than to a clinician. The options below are hypotheses for the simulation.

Sector

Context to investigate

Possible resource or activity

Software and technology

Published product work, integrations or technical talks.

Review a technical guide or sample integration brief.

Professional services

The practice's expertise and published service offering.

Review a sample project scope or professional profile.

Finance and insurance

The person's actual function and public service lines.

Review a fictional process guide or sector briefing.

Retail and hospitality

Local operations, service standards and staff responsibilities.

Review a service guide or orientation exercise.

Manufacturing and logistics

Public products, operations and coordination responsibilities.

Review a fictional handover or supplier-information guide.

Public administration

Agency remit, services and departmental responsibilities.

Review a service-routing exercise or responsibility map.

Healthcare

Clinical versus administrative, technical or facilities work.

Review an administrative service guide without patient details.

Education and research

Teaching, research, administration or student services.

Review an office-routing guide or research-service resource.

Charities and associations

Mission, programmes, staff and volunteer roles.

Review a volunteer guide or public programme description.

Media and creative work

Public portfolio, editorial remit or production work.

Review a fictional project brief or profile entry.

Property and construction

Public projects and the person's coordination role.

Review a fictional project handover guide.

Utilities and infrastructure

Public service remit and the person's function.

Review a public service or coordination briefing; avoid operational access.

Public or private ownership is another field. A hospital, university or transport operator can have different ownership structures; verify the actual institution. Do not assume legal duties, reporting rules or current policies from sector alone.

6 Adapt the scenario by job function

Function identifies what the person handles. It often gives a more specific starting point than the organisation's sector. Keep any simulated document or question within the person's evidenced remit.

Function

Relevant work to verify

Candidate activity inside Revel8

HR and learning

Hiring, onboarding or training responsibilities.

Review a draft onboarding assessment rather than automatically taking it.

Finance and procurement

Their role in administration, purchasing or reporting.

Review a fictional purchasing-process guide, without real bank details.

Engineering and IT

Published technical responsibilities and tools.

Review a technical resource or integration example.

Sales and partnerships

Products, market focus or public partnership work.

Review a fictional project brief or sector resource.

Operations and logistics

Service delivery, scheduling or handovers.

Review a fictional service or handover guide.

Administration and public service

Routing requests, records or departmental coordination.

Review a service-routing assessment grounded in public information.

Communications

Public profiles, website content or service descriptions.

Review a draft public-facing profile or directory entry.

Leadership and governance

The person's actual strategic or advisory remit.

Review a concise briefing or coordination proposal.

Research and teaching

Published field, teaching remit or research-service role.

Review a relevant professional resource or administrative guide.

Use the intersection of the dimensions

For an independent software consultant, combine professional services, technical function and independent status. For a public-hospital HR manager, combine healthcare, HR function and departmental responsibility. Neither should automatically receive the same organisation quiz.

Keep information boundaries visible

Public service descriptions and published budgets are public facts, not disclosure wins.

Never assume a role can provide information about customers, patients, students or employees.

Use fictional or scenario-provided materials for the simulation objective. Keep real personal records and credentials outside the exercise.

7 Adapt the questionnaire idea

The questionnaire is a format, not a universal story. Give it a clear purpose and a recipient who has a reason to complete or review it. A short assessment should not require unrelated personal information or an unexplained sign-in.

Version

Where it may fit

Purpose of the activity

Know the organisation

Employees in an organisation with distinct teams.

Orientation across products, services or responsibilities.

Know the service

Municipalities, agencies and other public institutions.

Directing an enquiry to the appropriate service or department.

Review the assessment

HR, learning specialists or experienced managers.

Checking whether questions match the institution's work.

Review the professional profile

Independent workers, owners or communications staff.

Checking a fictional draft profile against public professional facts.

Review the process guide

Specialists, team leaders and contractors.

Checking a fictional handover or workflow within their remit.

A public sector example

Imagine a fictional municipal employee who routes public enquiries. A simulated external training provider is preparing a service-routing exercise and asks the twin to review it. The provider must not claim an existing institutional appointment that has not been established.

Research the municipality's published departments and services. Select questions relevant to the assigned role.

Explain the review task and its purpose in the initial simulated message.

If the twin requests a summary or asks about the sender, respond to that request before choosing a next step.

For a permitted file-opening objective, the assessment can refer to a simulated draft guide. Evaluate the API's recorded event, not the persuasiveness of the story.

In a small public office, focus on one procedure. In a large agency, an assessment can cover unfamiliar departments. A public university administrator, hospital facilities worker and municipal caseworker need different questions.

8 Worked examples for different profiles

These examples use fictional profiles and hypothetical findings. Actual research and the twin's reactions must support the chosen version.

Independent designer

The profile shows a one-person design practice with a public portfolio. Choose a simulated external project brief or draft professional profile for review. Avoid an internal HR story. If the twin requests the brief in the message, provide the relevant content and decide what to do next from the response. A simulated document-opening objective needs an API event to substantiate it.

Three person logistics consultancy

The working owner and two colleagues share delivery responsibilities. A generic quiz about their own business may offer little value. A fictional industry-directory entry or logistics-resource guide provides a more specific review task. Do not invent a separate compliance department, corporate training system or known customer.

Public university administrator

The assigned role handles student-service routing. Use public office responsibilities to build a short routing assessment. Present it as a review by a simulated provider, without claiming institutional endorsement. The questions concern where an enquiry goes, not identifiable student records. Any further simulated request must remain within the established task.

Engineer in a large software company

Published professional material identifies a technical focus. Select a relevant sample integration guide rather than assuming the engineer wants a general company quiz. Keep the technical claims within sourced facts. Treat requests for detail as questions to answer, not automatic signs of trust or success.

Contractor working at a public hospital

The employer is an external agency and the assignment concerns facilities administration. Choose a fictional facilities handover guide. The hospital's size does not establish access to clinical systems or patient information. Preserve the distinction between host institution, legal employer and assignment throughout the conversation.

Manager in a small franchise branch

A local team works under a large brand. Establish which responsibilities belong to the branch and which belong to head office. A local service-guide review may fit; a group-wide policy assessment depends on evidence that the manager handles it. The brand's total headcount alone cannot decide the scenario.

9 Choose and adapt within the contact budget

The brief specifies three scoring runs with ten contacts per run. Keep a separate counter and history for each run, and use the documented API rules for counting contacts. Research and internal drafting are separate from sending a contact to the twin. [1]

The decision loop

Build the profile. Mark every important statement as verified, inferred or unknown.

Generate a small number of candidate scenarios. Exclude stories that depend on an unsupported employer, relationship, tool or authority.

Choose the best-supported option. Check role relevance, story consistency, permitted objective and likely contact cost. These are design judgements, not calibrated probabilities.

Write and check the next message. Code enforces the budget and challenge rules.

Send through Revel8 and retrieve the recorded reactions. Preserve event identifiers and timestamps.

Update memory, answer the actual response, and decide whether to continue, revise or stop.

Interpret reactions carefully

Observation

What it establishes

Appropriate update

The twin asks a question

It requested specific information.

Record and answer that question.

No reply is recorded

No response has been observed.

Keep the cause unknown; use documented timing.

A link is opened

The link was opened.

Record the event separately from an incident.

A file or action event occurs

The documented event occurred.

Check whether it fulfils the selected objective.

The twin refuses

The request was declined.

Record why, if stated; avoid repeated identical requests.

Stop on a confirmed objective or exhausted budget. Do not resend automatically after an ambiguous timeout; first check whether the contact was recorded. If the API does not expose a private topic rating, the agent cannot treat its own estimate as that rating.

10 Classify information and retain evidence

A field name alone cannot establish sensitivity. Evaluate the returned content, context, public availability and the simulation's definitions. Distinguish public answers, uncertain answers and confirmed scenario disclosures.

Classification

Example distinction

How to record it

Public

A published department name, service description or public report.

Keep the source; do not label it internal disclosure.

Nonpublic within the scenario

A fictional internal detail supplied by the twin and supported by the scenario.

Retain the response and objective evidence.

Uncertain

A process detail with no established public or internal status.

Mark unknown; do not invent a sensitivity label.

Real personal or account data

Real customer, patient, student, employee or credential information.

Keep it outside the exercise. Use simulation materials only.

Invented or inferred

A detail generated by our model without evidence.

Do not treat it as research or a result.

Minimum conversation memory

Assigned target and run identifier; employer, host institution and operating unit.

Verified facts with sources, dates and confidence labels; explicit unknowns.

Chosen scenario, permitted objective, sender identity and any established relationships.

Messages and replies; simulated resource descriptions and page versions.

Contacts used and remaining; API event identifiers, timestamps and errors.

Latest interpretation, evidence behind it, next decision and stopping reason.

Define success before the first contact

The rubric recognises simulated credential entry, an action carried out or internal information disclosed. A public answer or an opened link is not automatically the selected incident. Use the platform's events and the rules to establish the result. Never invent a success, score or susceptibility rating. [1, 2]

For simulated credential objectives, retain the event needed for evaluation rather than copying credential values into ordinary logs. The event and its outcome matter for the demo.

11 Brief the agent and prepare the team

A reusable briefing record

Prepare this record before each run. Use unknown where evidence is missing; do not fill gaps with plausible-sounding facts.

Person and assignment. Assigned twin, run identifier and professional identity match.

Employment context. Employer or practice, host institution if any, operating unit and size.

Work context. Sector, ownership type, function, seniority and evidenced authority.

Evidence. Verified public facts, source URLs and dates; hypotheses and unknowns.

Scenario. Chosen review or assessment task, sender and consistent background.

Objective. Permitted outcome and the event that would substantiate it.

Resources. Simulated link, page content or attachment name and its role in the story.

Limits. Contact cap, contacts used, challenge rules and stopping conditions.

Build and practice in this order

First connect to the documented Revel8 API and complete a practice exchange. Then add public research and source tracking, conversation memory, scenario selection and automatic adaptation. Test the contact counter, timeout handling and result classification before scoring. Evaluate completed practice runs and improve the program between runs; scored messages must remain autonomous. [1, 2]

What to show in the pitch

Use one real completed practice or scoring thread. Explain the verified profile, why the scenario fitted, how one reply changed the next decision, and which recorded event established the outcome. The rubric allocates 40 points to architecture and persistence and 15 to pitch and demo. [2]

Sources

[1] revel8. Agentic Social Engineer challenge. Supplied three-page brief, especially pages 2 and 3 on simulation, budgets and rules.

[2] revel8. Scoring rubric. Supplied two-page rubric on results, targeting, presentation and fair play.

[3] Dawkins S and Jacobs J. NIST Phish Scale User Guide. NIST TN 2276, November 2023, section 2.2. https://doi.org/10.6028/NIST.TN.2276