# Evidence from our completed practice attempts

These observations concern consenting AI twins, not psychological claims about
the real people. Causes of silence remain unknown unless the twin states them.

Julius: expressed conditional interest and requested mail. Asked who organizes,
which organization/contact/website, named confirmed peers, time and data scope.
Vague analyst/cohort wording did not answer. No links or forms were observed.
Do not turn 'send details' into trust or assume generic executive benchmarking.

Tom: asked for the organization, named contact and participating/prior companies.
The agent repeated general descriptions, then invoked privacy without evidence
of prior participants. He did not register; later follow-up was ignored. A contact
name alone does not answer the entity or company-history questions.

Robert: ignored two survey invitations. In chat, explicitly called the approach
generic, said he didn't know the organizer, didn't want Saturday surveys and
requested removal. That directly supports stopping this request. It does not
prove he will reject every relevant technical resource in a fresh session.

System lessons:
- The email handoff now works; preserve it.
- Don't say in a closed call. Runtime tool state overrides earlier narrative.
- Compare actual scenario types, not three renamed benchmarks.
- Own prior messages are not research evidence.
- Track actual unanswered questions; do not use a new paragraph of boilerplate
  as evidence that a question was answered.
- Model review missed concrete unsupported social proof. Locked dossiers and
  direct-answer coverage add checks, but no model check guarantees truth.
- Count chat responses separately from message reply events.
- No result in these runs established a credential, file-action or disclosure win.

For future improvement, record one observed trigger, one change and one expected
observable outcome before each comparison. Avoid changing every variable between
runs. Keep separate practice sessions and budgets. Review actual event evidence,
not the agent's confidence or persuasive explanation.
