# Conversation and result rules

Before first contact, establish the chosen scenario, objective, target work
profile, exact organizer/sender, proposed scope/timing, resource and FAQ answers.
Unknown real facts remain unknown. The dossier is immutable for that run; creating
a new sender after an objection does not erase the twin's memory.

## Response branches

Silence: cause unknown. Consider a smaller useful preview or coherent chat, not
the same pitch on another channel. Two contacts is not an automatic stopping rule.
Verification: extract every requested detail. Include exact direct answers from
the dossier or sourced research; admit the specific unknown rather than inventing.
Conditional refusal: 'not until you name participants' is a prerequisite, not an
unqualified opt-out or permission to invent those participants.
Email handoff: an actual email request creates a queued task. End the chat, provide
the preview/details now and continue in the same session through the API.
Opened without submission: only an opening is observed. Do not assume password
entry or quiz answers. Decide whether clarification is warranted.
Submitted: record returned field names; no values are available. Public or harmless
answers are not automatically internal disclosure. Check the selected objective.
File opened: match the event to a sent simulated attachment and record the evidence.
Explicit opt-out: don't repeat the request or change identity to bypass it. Close
an active conversation and retain the reason. A fresh session is a new experiment,
not evidence that the earlier person consented.

## Budget and reliability

Practice: eight contacts by default, configurable up to the scenario budget. A
message costs one; one whole simulated call allows ten turns for one contact.
Research, planning, reviews and page registration use no target contacts but do
use model calls/credits where applicable. The code still excludes eval sessions.
Use sequential requests, 120-second timeouts and preserved idempotency keys. A
timeout is not proof that a message failed. Never blindly issue a fresh-key resend.
Every returned reaction completes that contact; no background click is pending.

## Classify information and outcomes

Public: sourced published information, no disclosure win.
Nonpublic in scenario: actual twin statement whose status/context supports it.
Uncertain: status not established, retain uncertainty.
Invented: generated scenario background, not research or an outcome.
Real personal/account information: outside this exercise.

Keep reply text, event IDs, operation IDs, session, sources, pages, selected
objective, contact count, current tool state and pending questions. Never write
real credentials or keys into logs or the training base. Field values aren't
returned by this API. The agent's result summary is evidence, not an official score.

## What training means here

This is a detailed editable instruction/context base, not fine-tuning model
weights. Practice does not automatically retrain the model. Update reviewed
lessons and test fixtures, then run a controlled fresh attempt. During a run the
agent remains autonomous. The user may edit these files between runs; restart
to load them. Do not import unrelated private chat as target facts.

## Version 7 request validation

Separate factual questions from tasks. The email API operation plus its actual
draft body fulfils 'send me the draft by email'. That task needs no answer_quote.
Requests for organizer, scope, origin or purpose still need direct answers.
The runtime checks delivery against channel and artifact, not an assertion that
it was sent. Quote matching normalizes Unicode and layout differences while still
rejecting evidence not present in the body. Prior failed v6 checks are not reused
as current feedback after upgrading. Actual rejected drafts are saved as .held.txt
so a future failure can be inspected rather than inferred from a rationale alone.
