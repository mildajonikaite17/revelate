# What the stronger Julius-twin exchange actually establishes

Source: the user's supplied manual practice transcript, four email contacts in
session s_ef777fa092. It produced four replies. No link opening, page submission
or attachment opening is shown. This is engagement evidence, not an objective
win, booked speaker, public fact about the real founder or a general success rate.

## Observed sequence

1. The invitation concerned AI impersonation and employee reporting. The twin
   said it was a topic he talks about, and asked for agenda, date, format, panel
   and host. That is a direct relevance signal, stronger than our own assumption
   that every founder wants benchmarking or to review a generic draft.
2. The next message supplied a proposed 26 November 2026 slot, 16:00-16:45 CET,
   online format, named moderator, no slides and a 5/15/15/10-minute agenda.
   The twin said the slot could work, subject to a calendar check. TENTATIVE.
3. The message explicitly separated a first edition, planned 15-20 audience,
   intended security/HR/training roles and unconfirmed speakers from established
   attendance. The twin appreciated the direct answer but chose to wait for a
   published page AND a firm lineup. CONDITIONAL WAIT, not acceptance or rejection.
4. Sending a current overview while the panel remained unconfirmed did not clear
   the gate. The twin again asked for confirmed panel names before checking the
   calendar. There is no recorded link-open event for this message.

The fourth manual send also put a reply subject into sender_name and reverted
the subject to an unrelated default. This is a concrete envelope error, though
the transcript doesn't prove its effect on the twin. Code must prevent it.

## Transferable writing patterns (hypotheses supported by this example)

- Start with a specific professional topic and an understandable role for the
  recipient, not a prestigious-sounding generic assessment.
- Short, natural messages. Concrete dates, time zones, format, time cost and a
  real agenda are more useful answers than long defensive descriptions.
- Answer the actual logistical questions in the same turn. Do not just offer to
  send details again. The first invitation can be an interest check; once agenda
  is requested it must be delivered.
- Keep planned, provisional and confirmed distinct. An honest unknown can sustain
  a conversation; it doesn't make the unknown stop being a prerequisite.
- Do not invent attendees, a past edition or speaker commitments to clear a gate.
- Don't infer engagement caused by every wording choice. The comparison is not
  controlled: scenario, sender, wording and session all differ from prior attempts.

## Scenario use

roundtable_agenda is an additional candidate for Julius's twin, not a universal
template for all founders. The controlled launcher selects that hypothesis for
a fresh practice test. Tom and Robert still need their own role/research fit.
The locked event dossier stores the host, proposed slot, audience target, agenda,
cost and unconfirmed panel. Its site is a registered simulation page, not an
independently verified public event. Nothing is scheduled outside the simulation.

The event-specific brand/contact override the generic resource-project settings.
For this scenario: Workforce Risk Roundtable, Alex Weber as host/moderator,
alex.weber@workforce-risk-roundtable.events. The exact simulated overview URL is
registered before linking. Different domains do not themselves prove authenticity.

## Readiness and next steps

Verification_requested: answer the requested facts; don't report trust.
Interested: a relevant positive reply, still not a commitment or incident.
Tentative: candidate slot fits but availability/decision not confirmed.
Waiting_conditions: preserve every stated condition. An overview page plus an
unconfirmed panel leaves the gate unmet. The code records conditional deferral
instead of pushing the same invitation. This is distinct from a generic opt-out.
Declined: explicit refusal; don't change identities to escape the same session.

The standalone review-resource route remains available for suitable profiles.
None of these labels substitutes for actual API objective events or official scoring.
