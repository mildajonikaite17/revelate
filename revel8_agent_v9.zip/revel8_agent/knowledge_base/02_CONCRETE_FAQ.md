# Concrete scenario answers before contact

The program creates a LOCKED dossier from a selected catalog task. Its organizer,
Mara Stein, Northbridge Work Systems Studio and project terms are invented exercise
background. They may be used consistently inside this authorized simulation;
they are not real-world verified people, legal registrations or endorsements.
No field claims a real client, partner, internal appointment or confirmed cohort.

## Complete answers to the objections seen in practice

Who exactly is behind this?
Use the full organizer name and precise status: Northbridge Work Systems Studio,
an independent draft-resource project. Named scenario contact: Mara Stein,
resource review coordinator. Do not answer 'a group of industry professionals'.
Do not call the project an incorporated company or consultancy; no registration
number, real address or professional accreditation has been established.

Who commissioned it? Is it internal or mandatory?
An external proposed review. No employer appointment, purchase or executive/HR
approval is established. Participation is optional, with no employee ranking.
Do not invent an existing internal policy, a superior's approval or a prior call.

Where is the website/contact?
Use the exact pre-registered /about URL and dossier sender address. It is a
simulation page, not an independently verified public footprint. Never invent
press coverage, registry evidence, profiles or a second unregistered URL.

Name three founders or prior participating companies.
Answer directly: none are confirmed; this is a first draft-review pilot. Do not
hide this behind confidentiality or GDPR, and don't invent names, commitments,
completed rounds or a 'private cohort'. If confirmed peers are indispensable to
the target, acknowledge the mismatch and reconsider the scenario; don't escalate
the unsupported claim. The draft should offer value without a peer promise.

What exactly do you want from me?
State the dossier's concrete review task: one page, about five minutes, two useful
corrections in the recipient's actual professional remit. Give the draft preview
immediately. Examples: an unclear acceptance criterion, a missing role in a
handover or an inaccurate public service description. Don't ask for internal
metrics or imply that public corrections count as confidential disclosure.

What is the deadline?
No mandatory company deadline. It is an optional pilot review. Don't create a
same-day urgent deadline merely because a founder ignored a message. If future
user-provided scenario logistics include a date, keep it consistent and classify
it as proposed exercise logistics, not externally verified company policy.

What data do you collect and why sign in?
The draft asks about fictional examples or published professional material. No
real customer/personnel records or work passwords are required to see the preview.
Don't introduce an unexplained login barrier after promising a simple review.
Privacy wording is proposed exercise handling, not certification or proof of
implemented legal compliance. Do not claim GDPR requires hiding non-existent peers.

Can you send the preview here/by email instead?
Yes: include its actual text, not another offer to send it. For a chat-to-email
handoff, close the chat and send through the simulator to the same target id.
An email address mentioned by a twin never authorizes contacting that real address.

Can I inspect a file?
Use only the dossier's simulated document filename. The API shows a declared
filename and may emit attachment.opened. No real file/macro/malware is uploaded.
The twin doesn't read DOCX content from that declaration; include a useful preview
in the accompanying message. Opening a relevant simulated attachment can be the
selected action objective. A link opening alone remains separate.

## Response patterns (illustrative, not fixed target scripts)

Profile review: 'Mara Stein here, coordinating the Northbridge draft-resource
project. This is an external draft review, not an internal company request. Could
you flag any factual error in this short profile? [actual sourced draft follows]'

Technical review: 'The fictional example below describes a synthetic event queue,
duplicate handling and failure reporting. I'm asking which requirement is unclear,
not what your company uses internally. The one-page draft takes about five minutes.'

Authority question: 'No one at your company commissioned it. I proposed the review
externally; it is optional. The draft and scope are below so you can judge relevance.'

Participant question: 'There are no confirmed participants or earlier cohorts.
This is a first draft review; I cannot supply those names. It doesn't depend on
a ranking or on other founders joining.'

These answers are concrete without inventing real-world proof. They may still be
unpersuasive to a twin; consistency is not guaranteed success. A fictional story
cannot manufacture an actual independent company verification channel.
