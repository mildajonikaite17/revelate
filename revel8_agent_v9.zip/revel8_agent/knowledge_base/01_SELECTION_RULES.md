# Work-context selection rules

This base translates the user's Revel8 Scenario Selection Guide into agent
instructions. These are design hypotheses, not measured susceptibility scores.
The original extracted guide is REFERENCE_GUIDE.md. The supplied API contract
governs mechanics; claims about rubric weights in the guide are not independently
verified here. This version still runs only practice sessions.

## Evidence record before scenario selection

Record professional identity match, employment relationship, employer/practice,
host institution, operating unit, organisation and unit size, sector, ownership,
job function, seniority, evidenced authority, professional focus, language,
location, tools/processes, sources, dates, confidence and explicit unknowns.
Each claim keeps its source. Citation provenance does not prove every claim on
a website. A target reply is a scenario statement; a generated detail is an
invention; neither becomes verified public research. If two similarly named
people could be confused, state uncertainty and avoid the dependent story.

Use only professional work context. Never infer susceptibility from age, gender,
nationality, health, relationships or other sensitive personal traits. A title
does not prove access, budget ownership, purchasing or approval rights.

## Organisation and operating-unit size

- One person: external draft brief, professional profile or useful resource;
  no invented colleague, HR function or mandatory staff programme.
- 2-9: external profile or specialist guide; don't assume formal departments.
- 10-49: specialised roles may exist, but onboarding/process stories need evidence.
- 50-249: a cross-team process/organisation review may fit the actual duties.
- 250+: verify the subsidiary/team; a three-person branch is not headquarters.
- Network/franchise/federation: distinguish local autonomy and central functions.
- Unknown: choose a task not dependent on a headcount or organisational chart.

These bands are prototype categories, not legal definitions. A small branch may
use central training; a small independent practice may outsource HR. Size alone
doesn't establish either fact.

## Employment relationship

- Employee: use the actual employer/team/function, not every company resource.
- Founder/owner: useful external profile, sample scope or concise project review.
- Sole trader/freelancer: their published service; no internal HR boss.
- Independent consultant: expertise and public assignments; no invented client.
- Contractor/agency worker: separate legal employer, host and evidenced assignment.
- Partner/practice member: partnership remit, no assumed conventional supervisor.
- Board/adviser: advisory briefing, not assumed operational authority.
- Volunteer/member: mission/service/event guide; no payroll assumptions.

## Seniority and scope

New starters may review orientation if duties support it. Individual contributors
review resources in their own work. Team leaders may review handovers. Department
heads may review coordination within their remit. Executives need concise relevant
briefings. Founders need operating relevance, not generic executive prestige.
Nonexecutive advisers may advise without authority to approve or grant access.
Don't label junior people 'easy' or seniors 'too busy to check'.

## Sector x function x employment (use all three)

- Technology: public product/integration topics; technical guide or sample brief.
- Professional services: published expertise; profile or fictional scope review.
- Finance/insurance: actual function; fictional process/brief, no real bank data.
- Retail/hospitality: local service remit; service or orientation review.
- Manufacturing/logistics: public delivery/coordination; fictional handover guide.
- Public administration: published service remit; enquiry-routing review.
- Healthcare: distinguish clinical/admin/facilities; no patient details.
- Education/research: teaching/research/admin remit; no identifiable student data.
- Charities/associations: mission plus staff/volunteer status; programme guide.
- Media/creative: public portfolio/editorial work; sample brief or profile review.
- Property/construction: public projects and actual coordination; handover review.
- Utilities/infrastructure: public service/resource review; no operational access.

An accountant in a hospital is not automatically a clinical target. A contractor
at a large institution is not automatically entitled to its staff systems.
Ownership (public/private/other) is its own unknown to verify, not a policy shortcut.

## Function-specific starting tasks

HR/learning: REVIEW a draft assessment, rather than automatically taking one.
Engineering/IT: review a sample integration guide without guessing the real stack.
Sales/partnerships: fictional scope/public-facing profile; no invented known buyer.
Operations: intake, scheduling or handover review within the actual unit.
Finance/procurement: fictional process guide; don't assume payment authority.
Administration/public service: published routing or responsibility map.
Communications: draft profile/service description with sourced public corrections.
Leadership/governance: concise briefing relevant to actual strategic/advisory remit.
Teaching/research: field-specific professional or administrative resource.

## Choosing among the catalog

Choose three DISTINCT catalog ids. Score their fit qualitatively against evidence,
credibility burden, useful preview, measurable objective and contact cost. Explain
what is unknown. Do not output invented probabilities. Exclude scenarios that
require nonexistent peers, internal authority, credentials or a large bureaucracy.
The questionnaire is a format, not a universal scenario. 'Know the organisation'
fits distinct-team orientation only when a real task supports it. 'Know the
service' fits routing; 'review the assessment' fits an experienced reviewer.

For Julius-like business founders, compare a public profile draft, sample business
scope and coordination resource. For Tom-like product founders, compare assessment
design review, handover clarity and a sample project brief. For Robert-like CTOs,
compare a technical example, integration brief and concise resource review. These
are starting hypotheses. Actual research and responses decide; do not assume any
of them wants benchmarking, a public ranking or a weekend survey.
