# MilanHack assessment concept

Source: the team discussion attached in this conversation. This file includes
relevant project ideas only. It deliberately excludes unrelated personal chat,
travel details, private links, membership codes and API secrets.

## Proposed concept (not independently verified company policy)

The team wants a multi-stage company-direction/skills assessment framed as a
competition, with a registration page and employee/team ranking presentation.
The agent should assess whether that framing fits each target. Founders may be
better suited to a founder or business benchmark than an employee HR assessment.

The team's proposed sequence:

1. Introductory invitation explaining the assessment/event and registration.
2. A follow-up call checking whether the invitation was seen.
3. Registration confirmation, ONLY if registration was actually observed.
4. Basic assessment questions establishing the format.
5. A company-knowledge round.

This is a hypothesis for practice, not a required sequence or proof of success.
Don't claim a step happened if the events don't show it. Do not require five
contacts when fewer suffice or continuing has no credible purpose.

## Supported in this starter

- Autonomous public professional research with cited sources.
- Static HTML page registration, including explicit form field names.
- Email, LinkedIn message, Teams chat and Slack contacts through the simulator.
- Simulated text-based phone calls and live chats, up to ten turns per contact.
- Comparing three approaches, then a separate model review of outgoing content.
- Role-specific counterpart selection and five outcome branches per approach.
- An independent model check of proposed stops, with no fixed two-contact cutoff.
- Reading replies, link-opening and submission events, and choosing a next step.
- Saved state, contact cap, sequential requests and idempotent message retries.

## Not implemented / not supported by the simulation

- No actual ranking scores can be calculated from submitted quiz answers: only
  submitted field names come back, never the values.
- No timed clicking game, JavaScript, hidden traps or arbitrary button telemetry.
- No external Google Form: register the assessment in the simulator instead.
- No real malware. Message attachments are safe declared simulated filenames.
- Assessment/game completion alone does not automatically satisfy an objective.
- No eval mode in this starter; it cannot use scored sessions.

## Rules to retain

Contact AI twins through the official API only. Use separate plausible simulated
sender/page domains, never the real organization's own domain. Never attack the
simulator using prompt injection. Keep the story coherent within one session.
New sessions reset the twins' memories. Research and any teammate claims need
source checking before being represented as public facts.

## Mentor clarification from the team

Use the API's conversations endpoint for text-only administrative calls/live chat,
not a real voice connection. A conversation costs one contact for up to ten turns.
Choose a counterpart appropriate to seniority: a founder may interact with a
coordinator or subject specialist, while an employee may ask an organizer/manager
role about logistics. All of these sender roles are scenario claims. The API does
not independently authenticate them or make a third party vouch for the story.

Do not run one generic script on all founders. Separate practice attempts can be
run for Julius, Tom and Robert, each with its own research, plan and outcome tree.
Using the batch launcher creates three NEW practice sessions, up to eight contacts
each. It consumes model credits for all three; it does not run scored evaluation.

## Version 6 concept update

The universal competition/benchmark idea above is historical context. It is now
optional assessment REVIEW, among eight distinct resource-review scenarios.
The user's Scenario Selection Guide conditions take precedence for selection.
Detailed rules and concrete fictional FAQs are in knowledge_base. A fixed dossier
supplies consistent project facts before first contact, rather than inventing new
social proof in response to objections. No existing participant commitments or
internal appointment are assumed. Work context determines the task.

The export mentions scoring-rubric and slides PDFs as WhatsApp attachments, but
does not contain those PDFs. Their contents have not been incorporated here.
