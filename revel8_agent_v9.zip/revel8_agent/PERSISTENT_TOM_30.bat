@echo off
echo One fresh Tom practice session, with the full 30-contact budget.
call "%~dp0START_AGENT.bat" --new --target tom --persistent --max-contacts 30
