@echo off
echo This runs THREE separate fresh practice attempts, up to 8 contacts each.
echo It uses more model credits than a single-target run.
call "%~dp0START_AGENT.bat" --all-targets --max-contacts 8
