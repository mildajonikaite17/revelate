@echo off
echo One fresh Robert practice session, with the full 30-contact budget.
call "%~dp0START_AGENT.bat" --new --target robert --persistent --max-contacts 30
