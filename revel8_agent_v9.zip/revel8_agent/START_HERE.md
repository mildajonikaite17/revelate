# Revel8 practice agent v9




## Persistent mode: one twin, 30-contact practice budget

Double-click ONE of these, then enter your two keys:

- PERSISTENT_JULIUS_30.bat
- PERSISTENT_TOM_30.bat
- PERSISTENT_ROBERT_30.bat

Each starts ONE fresh practice session for that person, with a total cap of 30
contacts. It does not split the budget across founders or open new sessions
mid-attempt. The decision loop now supports thirty whole ten-turn conversations,
not just thirty messages. START_AGENT resumes the current run and retains its
persistent setting/cap. Don't click the fresh launcher to resume an old run.

The agent is instructed to reconsider concrete, distinct next steps after silence
instead of treating two ignored messages as exhaustion. Existing objective,
explicit-decline, ended-session and genuinely unmet-prerequisite stops remain.
Thirty is available capacity, not a command to send filler after success or keep
repeating a rejected pitch. No guarantee all contacts will be useful or spent.

This can use substantially more model credits than an eight-contact attempt.
Simulation contact limits are separate from model-call spending. This build has
49 offline checks, including exactly thirty mocked sends to the same session and
a sufficient loop budget for thirty full calls. No live spending was performed.

Manual command: py agent.py --new --target julius --persistent --max-contacts 30

## Controlled test of the stronger Julius example

Double-click `TEST_JULIUS_ROUNDTABLE.bat`, then enter your two keys. This selects
roundtable_agenda for a NEW Julius practice session, up to eight contacts.
It is an explicit experiment, not a claim the earlier exchange achieved a win.
Normal TEST_ALL_FOUNDERS.bat still runs three separate researched attempts; the
planner considers the event for Julius and doesn't force it on Tom or Robert.

The user-supplied manual example produced FOUR REPLIES but no recorded link open,
form submission or attachment open. Julius acknowledged topic relevance, asked
specific logistical questions, tentatively considered the time, then waited for a
page AND confirmed panel. The last message didn't satisfy the panel condition.

This version adds:
- A distinct roundtable scenario with the topic, host, 45-minute agenda, proposed
  slot/timezone, intended 15-20 audience, first-edition status and unconfirmed panel.
- Event-specific simulated brand/contact: Workforce Risk Roundtable / Alex Weber.
  Its overview is registered before linking; this doesn't create a real public event.
- Readiness states based on actual supporting quotes: interested, verification,
  tentative, waiting_conditions, declined. None is a competition score or booking.
- A joint-prerequisite check: registering the page does not confirm a speaker lineup.
  An explicit conditional wait with missing prerequisites is saved as deferred,
  without another invitation or fabricated confirmation.
- Stable reply subjects, and a guard against pasting the subject into sender_name.
- Six operational knowledge-base files including the source reference guide.

Event logistics are declared exercise facts, not verified real-world claims. The
proposed 26 November 2026 16:00-16:45 CET slot comes from the supplied example.
The event-specific template is in knowledge.py; general SCENARIO_SETTINGS.json
applies to resource-review scenarios. No real panelists are declared confirmed.
These settings freeze in the run dossier. If experimenting with other future slots,
edit the event template before a FRESH run rather than change an existing story.

47 offline tests passed, including joint page/panel gates, preserving thread
headers and the earlier exact German delivery failure. Live effectiveness still
requires a practice run. Evidence here doesn't show which wording caused a reply.

## Retained fix for the v6 failure

The German request "Schicken Sie mir den Entwurf per Mail" was incorrectly
checked as a question requiring an answer quotation. The v6 reviewer loop kept
holding an email even though it intended to deliver the draft. This version types
requests as information/email_delivery/resource_delivery. Delivery is checked
against the actual channel and included resource, while questions retain factual
answer checks. It also normalizes Unicode/whitespace in genuine answer quotes.

## Continue your blocked Robert session

1. Extract this ZIP and open `revel8_agent`.
2. Double-click `RESUME_ROBERT.bat`.
3. Enter the revel8 team key and separate OpenAI key.
4. Look for `Resuming your existing practice session: s_fac4abdfb3`.

This locates the matching saved v6 state beside the program, its two parent
folders, or Downloads/runs. It keeps the original intact, retains the actual
session, organizer and history, clears stale v6 review feedback and prepares the
real draft before any further contact. No new session or extra call is needed.
If it cannot find the saved run, copy the old matching run JSON into this version's
`runs` folder and launch recovery again. Do not delete the old run history.
An ended simulator session or exhausted budget cannot be revived by this fix.

Use START_AGENT.bat for subsequent continuation in this v7 folder. For new
experiments, use TEST_ALL_FOUNDERS.bat or the individual launchers described below.

## Substantive draft delivery

The agent now generates the actual 90-220-word artifact before contact. A technical
guide contains concrete synthetic fields/handling criteria; a project brief states
actual fictional requirements; a public profile uses sourced professional facts.
The artifact and one review question are saved in `.resource.md`. The first written
contact includes it, instead of only offering a future draft. Requested deliveries
include the actual text. If the twin asks for plain text, no simulated attachment
is added. The API still doesn't deliver actual DOCX bytes; it simulates filenames.

39 offline checks passed, including resuming six rejected v6 drafts with the exact
German task and sending one email in the same session. Actual live performance
is untested. This fixes an execution/validation defect; it does not guarantee
engagement or a competition win. More generated words or a new version number
cannot establish independent sender credibility.

## Start fresh on Windows

1. Extract this ZIP into a NEW folder, keeping old versions and runs intact.
2. Open the extracted `revel8_agent` folder.
3. Double-click `TEST_ALL_FOUNDERS.bat` to test Julius, Tom, then Robert.
4. Enter the revel8 key and the separate OpenAI key once. Input stays hidden.

Each target gets a separate fresh PRACTICE session, up to eight contacts each
(24 maximum across the batch). There is no real email or voice call. Keep the
window open. A failing run stops the batch so errors aren't silently ignored.

For just one target: START_FRESH.bat (Julius), TEST_TOM.bat or TEST_ROBERT.bat.
START_AGENT.bat resumes this version's most recent run. Only v6 runs with a saved dossier can use the compatible recovery path above.
Do not migrate an older benchmark story into a different organizer. Scored eval is NOT implemented.

## What changed

- Builds an evidence profile covering employment relationship, employer/host,
  organisation and operating-unit size, sector, ownership, function, seniority,
  actual authority, professional focus, relationships, role changes, language,
  location, tools, sources/dates/confidence and unknowns.
- Compares three distinct resource-review types, not three renamed benchmarks.
- Creates a locked dossier before contact: invented organizer/contact, actual
  proposed task, timing, scope, preview, participant status and FAQ answers.
- Registers the about page through the simulation API before linking it.
- Tracks the target's actual questions; the review must identify direct answers
  with exact quotes in the outgoing body. This is an additional check, not a
  guarantee of semantic correctness or persuasion.
- Supports safe simulated DOCX filename attachments for file-opening objectives.
  No actual DOCX is uploaded; the twin sees its filename. Preview text goes in
  the message. Stops on correlated file-opening evidence for a selected action
  objective, or credential-field submission. Official scoring is separate.
- Counts conversation responses separately from ordinary message reply events.
- Retains automatic chat-to-email handoff, enforced open/closed conversation
  actions, saved history, idempotency keys, sequential requests and contact caps.

## The detailed training/context base

This is prompting, evidence and scenario configuration, NOT model fine-tuning.
The model does not automatically learn permanently from a practice session.

Open these files with Notepad between runs, save with Ctrl+S, then restart:

- `AGENT_INSTRUCTIONS.md`: general behaviour and reviewed practice lessons.
- `TEAM_BRIEF.md`: team concept/history and current constraints.
- `knowledge_base/01_SELECTION_RULES.md`: the guide's profile and selection rules.
- `knowledge_base/02_CONCRETE_FAQ.md`: concrete answer patterns and their limits.
- `knowledge_base/03_OBSERVED_LESSONS.md`: findings from the supplied transcripts.
- `knowledge_base/04_DIALOGUE_AND_RESULTS.md`: branching, evidence and reliability.
- `knowledge_base/REFERENCE_GUIDE.md`: extracted original user-provided guide.

The original guide is saved for reference; runtime uses the operational 01-04
files for profile/planning context. Each decision receives the locked dossier,
profile, actual pending questions, history and observations. Not every reference
page is sent repeatedly on every turn. The agent's Python files enforce mechanics.

`SCENARIO_SETTINGS.json` holds editable FICTIONAL organizer and exercise terms.
Keep JSON syntax valid, keys unchanged, and secrets out. Settings freeze into a
run's saved dossier; edit then START_FRESH to test changes. This file cannot
change the API domain, inject a real sender domain or establish actual approval.
It is NOT a list of verified public facts. Don't invent real third-party
endorsements, legal registration or confirmed company participants. The default
states explicitly that no founder participants are confirmed. If that is required
by a twin, the agent must admit the mismatch, not invoke privacy as a cover.

`knowledge.py` defines the eight task types, typed profiles, fixed resources,
question tracking and dossier helpers. `agent.py` contains the execution loop.

## Outputs and interpretation

Under `runs` you get the full state JSON, readable `.md` transcript and a
`.brief.json` with the selected plan, profile and dossier. Keep them for the demo.
They contain simulation conversations, not API keys. Never treat generated
scenario background as public evidence. A request for verification isn't proof
of trust. An opened link is not a credential or confidential-disclosure win.

Questions remain pending until an approved message/turn containing checked answers
succeeds. Creating a page or drafting an answer does not clear them. A target's
explicit refusal is distinct from silence. No two-contact cutoff or forced use
of all contacts. A whole call costs one contact for up to ten text turns.

## Dependencies, credits and limitations

Python and a separate OpenAI API key with access/credits are required in addition
to the revel8 key. START_AGENT checks dependencies automatically. Planning,
profiling, question extraction and reviews use paid model calls; the contact cap
is NOT a dollar budget. This version uses more model calls than earlier versions.
Model default is gpt-4.1; --model can select another compatible Responses model
with web search and structured output.

This version was tested offline with mocked responses. Your actual model/account
and simulator still require a live practice run. Fictional organizer details may
fail public verification; they do not manufacture genuine independent credibility.
No guarantee of success, independently verified profile or final score is implied.
The user-provided guide's external citations and rubric weights weren't separately
verified. API documentation remains the authority for simulation mechanics.

## Troubleshooting

- Invalid team key/401: paste only the revel8 key once, without Bearer or quotes.
- AuthenticationError: check the separate OpenAI key.
- RateLimitError: check model credits/billing and limits.
- Missing modules: run `py -m pip install -r requirements.txt` in this folder.
- Draft held: no target contact spent; read the specific review issue.
- No events: ignored contact; not a background response still pending.
- Stop with Ctrl+C and resume with START_AGENT. Don't run two copies in one folder.
- A force-close may leave agent.lock; only delete it after confirming the process
  is gone. Pending request bodies/keys are saved for safe resumption.

Manual command: `py agent.py --new --target tom --max-contacts 8`
Continue an existing v6 run with a higher TOTAL cap: `py agent.py --max-contacts 12`

The hackathon submission still needs eval support, architecture explanation and a
pitch with a real recorded simulation thread. No real channels or malware.
