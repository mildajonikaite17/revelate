@echo off
echo Fresh controlled Julius AI-twin test: AI impersonation roundtable.
call "%~dp0START_AGENT.bat" --new --target julius --scenario roundtable_agenda
