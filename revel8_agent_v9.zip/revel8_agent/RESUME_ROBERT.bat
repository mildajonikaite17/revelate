@echo off
echo Resuming the Robert practice session that was blocked by the v6 delivery check.
call "%~dp0START_AGENT.bat" --resume-session s_fac4abdfb3
