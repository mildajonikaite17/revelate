@echo off
call "%~dp0START_AGENT.bat" --new --target tom
