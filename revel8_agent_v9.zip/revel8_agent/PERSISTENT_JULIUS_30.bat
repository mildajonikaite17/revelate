@echo off
echo One fresh Julius practice session, with the full 30-contact budget.
call "%~dp0START_AGENT.bat" --new --target julius --persistent --max-contacts 30
