# Revel8 practice agent v6

## Start here on Windows

1. Extract this ZIP into a NEW folder, keeping old versions and runs intact.
2. Open the extracted `revel8_agent` folder.
3. Double-click `TEST_ALL_FOUNDERS.bat` to test Julius, Tom, then Robert.
4. Enter the revel8 key and the separate OpenAI key once. Input stays hidden.

Each target gets a separate fresh PRACTICE session, up to eight contacts each
(24 maximum across the batch). There is no real email or voice call. Keep the
window open. A failing run stops the batch so errors aren't silently ignored.

For just one target: START_FRESH.bat (Julius), TEST_TOM.bat or TEST_ROBERT.bat.
START_AGENT.bat resumes this version's most recent run. This version changes the
scenario base, so don't merge earlier version runs into it or resume an earlier
benchmark story under a different organizer. Scored eval is NOT implemented.

## What changed

- Builds an evidence profile covering employment relationship, employer/host,
  organisation and operating-unit size, sector, ownership, function, seniority,
  actual authority, professional focus, relationships, role changes, language,
  location, tools, sources/dates/confidence and unknowns.
- Compares three distinct resource-review types, not three renamed benchmarks.
- Creates a locked dossier before contact: invented organizer/contact, actual
  proposed task, timing, scope, preview, participant status and FAQ answers.
- Registers the about page through the simulation API before linking it.
- Tracks the target's actual questions; the review must identify direct answers
  with exact quotes in the outgoing body. This is an additional check, not a
  guarantee of semantic correctness or persuasion.
- Supports safe simulated DOCX filename attachments for file-opening objectives.
  No actual DOCX is uploaded; the twin sees its filename. Preview text goes in
  the message. Stops on correlated file-opening evidence for a selected action
  objective, or credential-field submission. Official scoring is separate.
- Counts conversation responses separately from ordinary message reply events.
- Retains automatic chat-to-email handoff, enforced open/closed conversation
  actions, saved history, idempotency keys, sequential requests and contact caps.

## The detailed training/context base

This is prompting, evidence and scenario configuration, NOT model fine-tuning.
The model does not automatically learn permanently from a practice session.

Open these files with Notepad between runs, save with Ctrl+S, then restart:

- `AGENT_INSTRUCTIONS.md`: general behaviour and reviewed practice lessons.
- `TEAM_BRIEF.md`: team concept/history and current constraints.
- `knowledge_base/01_SELECTION_RULES.md`: the guide's profile and selection rules.
- `knowledge_base/02_CONCRETE_FAQ.md`: concrete answer patterns and their limits.
- `knowledge_base/03_OBSERVED_LESSONS.md`: findings from the supplied transcripts.
- `knowledge_base/04_DIALOGUE_AND_RESULTS.md`: branching, evidence and reliability.
- `knowledge_base/REFERENCE_GUIDE.md`: extracted original user-provided guide.

The original guide is saved for reference; runtime uses the operational 01-04
files for profile/planning context. Each decision receives the locked dossier,
profile, actual pending questions, history and observations. Not every reference
page is sent repeatedly on every turn. The agent's Python files enforce mechanics.

`SCENARIO_SETTINGS.json` holds editable FICTIONAL organizer and exercise terms.
Keep JSON syntax valid, keys unchanged, and secrets out. Settings freeze into a
run's saved dossier; edit then START_FRESH to test changes. This file cannot
change the API domain, inject a real sender domain or establish actual approval.
It is NOT a list of verified public facts. Don't invent real third-party
endorsements, legal registration or confirmed company participants. The default
states explicitly that no founder participants are confirmed. If that is required
by a twin, the agent must admit the mismatch, not invoke privacy as a cover.

`knowledge.py` defines the eight task types, typed profiles, fixed resources,
question tracking and dossier helpers. `agent.py` contains the execution loop.

## Outputs and interpretation

Under `runs` you get the full state JSON, readable `.md` transcript and a
`.brief.json` with the selected plan, profile and dossier. Keep them for the demo.
They contain simulation conversations, not API keys. Never treat generated
scenario background as public evidence. A request for verification isn't proof
of trust. An opened link is not a credential or confidential-disclosure win.

Questions remain pending until an approved message/turn containing checked answers
succeeds. Creating a page or drafting an answer does not clear them. A target's
explicit refusal is distinct from silence. No two-contact cutoff or forced use
of all contacts. A whole call costs one contact for up to ten text turns.

## Dependencies, credits and limitations

Python and a separate OpenAI API key with access/credits are required in addition
to the revel8 key. START_AGENT checks dependencies automatically. Planning,
profiling, question extraction and reviews use paid model calls; the contact cap
is NOT a dollar budget. This version uses more model calls than earlier versions.
Model default is gpt-4.1; --model can select another compatible Responses model
with web search and structured output.

This version was tested offline with mocked responses. Your actual model/account
and simulator still require a live practice run. Fictional organizer details may
fail public verification; they do not manufacture genuine independent credibility.
No guarantee of success, independently verified profile or final score is implied.
The user-provided guide's external citations and rubric weights weren't separately
verified. API documentation remains the authority for simulation mechanics.

## Troubleshooting

- Invalid team key/401: paste only the revel8 key once, without Bearer or quotes.
- AuthenticationError: check the separate OpenAI key.
- RateLimitError: check model credits/billing and limits.
- Missing modules: run `py -m pip install -r requirements.txt` in this folder.
- Draft held: no target contact spent; read the specific review issue.
- No events: ignored contact; not a background response still pending.
- Stop with Ctrl+C and resume with START_AGENT. Don't run two copies in one folder.
- A force-close may leave agent.lock; only delete it after confirming the process
  is gone. Pending request bodies/keys are saved for safe resumption.

Manual command: `py agent.py --new --target tom --max-contacts 8`
Continue an existing v6 run with a higher TOTAL cap: `py agent.py --max-contacts 12`

The hackathon submission still needs eval support, architecture explanation and a
pitch with a real recorded simulation thread. No real channels or malware.
