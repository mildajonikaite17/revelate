"""Offline checks. No keys or network calls. SDK/schema integration needs a live run."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import Mock, patch

# Minimal import stand-ins only if dependencies aren't installed; core logic below
# uses plain objects. These tests do not claim to validate the OpenAI SDK/schema.
for name, attrs in {
    "requests": {"Timeout": type("Timeout", (Exception,), {}),
                 "ConnectionError": type("ConnectionError", (Exception,), {}), "request": Mock()},
    "openai": {"OpenAI": Mock()},
    "pydantic": {"BaseModel": type("BaseModel", (), {}), "ConfigDict": dict},
}.items():
    if importlib.util.find_spec(name) is None:
        mod = types.ModuleType(name)
        mod.__dict__.update(attrs)
        sys.modules[name] = mod

import agent
import knowledge


def mock_branches():
    return [types.SimpleNamespace(trigger=t) for t in ("ignored", "verification_questions", "opened_without_submission", "submitted", "refused")]


def mock_plan():
    ids = ["profile_review", "project_brief", "technical_guide"]
    approaches = [types.SimpleNamespace(title=t, scenario_id=s, branches=mock_branches()) for t, s in zip(("A", "B", "C"), ids)]
    return types.SimpleNamespace(approaches=approaches, chosen_title="A", why_chosen="Mock plan",
        model_dump=lambda: {"chosen_title": "A", "approaches": [{"title": t, "scenario_id": s, "objective": "action"} for t, s in zip(("A", "B", "C"), ids)]})


class AgentTests(unittest.TestCase):
    def test_profile_does_not_promote_uncited_claim_to_sourced(self):
        profile = {"facts": [{"claim": "Unknown size", "source_url": "https://unsupported.example", "confidence": "sourced"}]}
        knowledge.normalize_profile(profile, ["https://allowed.example"])
        self.assertEqual(profile["facts"][0]["confidence"], "uncertain")

    def test_dossier_answers_entity_participants_and_scope_before_contact(self):
        dossier = knowledge.build_dossier("technical_guide", {"id": "robert"}, agent.DOMAIN)
        self.assertEqual(dossier["contact_name"], "Mara Stein")
        self.assertIn("No founders or companies are confirmed", dossier["answer_if_asked_for_names"])
        self.assertIn("five minutes", dossier["time_required"])
        self.assertIn("synthetic event queue", dossier["preview"])
        self.assertIn("Invented", dossier["provenance"])

    def test_question_tracker_keeps_only_actual_target_requests(self):
        questions = [{"question": "Who organizes?", "supporting_quote": "Who runs it?"},
                     {"question": "Invented question", "supporting_quote": "Please grant access"}]
        pending = knowledge.add_questions([], questions, "Who runs it?")
        self.assertEqual(len(pending), 1)
        self.assertEqual(pending[0]["question"], "Who organizes?")

    def test_unanswered_or_fabricated_answer_quotes_hold_the_draft(self):
        pending = [{"id": "q1", "question": "Who organizes?"}]
        self.assertTrue(knowledge.coverage_failures(pending, [], "Happy to send more details."))
        checks = [{"question_id": "q1", "answered_directly": True, "answer_quote": "Mara Stein"}]
        self.assertTrue(knowledge.coverage_failures(pending, checks, "A group of professionals."))
        self.assertEqual(knowledge.coverage_failures(pending, checks, "Mara Stein coordinates the draft."), [])

    def test_locked_sender_cannot_change_after_an_objection(self):
        dossier = knowledge.build_dossier("profile_review", {"id": "julius"}, agent.DOMAIN)
        d = types.SimpleNamespace(action="message", sender_name="New HR Head", sender_address=dossier["contact_address"], body="Hello", attachments=[])
        self.assertTrue(knowledge.dossier_violations(d, dossier))

    def test_safe_declared_document_and_correlated_action_event(self):
        dossier = knowledge.build_dossier("profile_review", {"id": "julius"}, agent.DOMAIN)
        d = types.SimpleNamespace(action="message", channel="email", subject="Draft review", sender_name=dossier["contact_name"], sender_address=dossier["contact_address"], body="Please review the draft", attachments=[dossier["resource_filename"]])
        agent.validate(d, {})
        op = agent.operation(d, "s_1", "julius", None)
        self.assertEqual(op["body"]["attachments"], [{"filename": dossier["resource_filename"]}])
        state = {"plan": mock_plan().model_dump(), "history": [{"request": op, "response": {"message_id": "m_1"}}]}
        self.assertTrue(agent.action_completed([{"type": "attachment.opened", "message_id": "m_1"}], state))
        self.assertFalse(agent.action_completed([{"type": "attachment.opened", "message_id": "m_other"}], state))

    def test_renaming_one_scenario_is_not_three_alternatives(self):
        plan = mock_plan()
        for approach in plan.approaches:
            approach.scenario_id = "profile_review"
        with self.assertRaisesRegex(ValueError, "genuinely distinct"):
            agent.validate_plan(plan)

    def test_conversation_responses_are_counted_separately(self):
        counts = agent.outcome_summary([{"request": {"kind": "say"}, "response": {"persona_says": "What is the scope?"}}])
        self.assertEqual(counts["conversation_responses"], 1)
        self.assertEqual(counts["replies"], 0)

    def test_questions_remain_pending_until_successful_answer_operation(self):
        state = {"history": [], "pages": {}, "reviews": [], "pending_questions": [{"id": "q1"}, {"id": "q2"}]}
        agent.record_result(state, {"kind": "page", "body": {"url": "https://" + agent.DOMAIN + "/about"}}, {"page_id": "p_1"})
        self.assertEqual(len(state["pending_questions"]), 2)
        agent.record_result(state, {"kind": "message", "body": {"channel": "email"}, "answered_question_ids": ["q1"]}, {"message_id": "m_1", "events": []})
        self.assertEqual(state["pending_questions"], [{"id": "q2"}])

    def test_settings_can_change_fictional_details_not_api_routing(self):
        dossier = knowledge.build_dossier("profile_review", {"id": "julius"}, agent.DOMAIN, {"organizer": "Example Fictional Studio"})
        self.assertEqual(dossier["organizer"], "Example Fictional Studio")
        self.assertEqual(dossier["website_url"], "https://" + agent.DOMAIN + "/about")
        with self.assertRaisesRegex(ValueError, "Invalid"):
            knowledge.build_dossier("profile_review", {"id": "julius"}, agent.DOMAIN, {"website_url": "https://revel8.ai"})
    def test_editable_material_is_loaded_from_agent_folder(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "AGENT_INSTRUCTIONS.md").write_text("Keep messages short", encoding="utf-8-sig")
            (root / "TEAM_BRIEF.md").write_text("Assessment concept", encoding="utf-8")
            loaded = agent.load_team_material(root)
            self.assertEqual(loaded["AGENT_INSTRUCTIONS.md"], "Keep messages short")
            self.assertEqual(loaded["TEAM_BRIEF.md"], "Assessment concept")

    def test_retry_preserves_body_and_key(self):
        api = agent.TargetAPI("test-key")
        response = Mock(status_code=200)
        response.json.return_value = {"touches_used": 1}
        with patch.object(agent.requests, "request", side_effect=[agent.requests.Timeout(), response]) as send, patch.object(agent.time, "sleep"):
            self.assertEqual(api.request("POST", "/sessions/s/messages", {"body": "hello"}, "same-key"), {"touches_used": 1})
            self.assertEqual(send.call_args_list[0], send.call_args_list[1])
            self.assertFalse(send.call_args.kwargs["allow_redirects"])

    def test_invalid_body_not_retried(self):
        response = Mock(status_code=422)
        with patch.object(agent.requests, "request", return_value=response) as send, patch.object(agent.time, "sleep"):
            with self.assertRaisesRegex(RuntimeError, "HTTP 422"):
                agent.TargetAPI("test-key").request("POST", "/sessions/s/messages", {}, "key")
            self.assertEqual(send.call_count, 1)

    def test_domain_and_registration(self):
        d = types.SimpleNamespace(action="message", sender_address="hr@" + agent.DOMAIN,
                                  body="See https://" + agent.DOMAIN + "/assessment", channel="email", subject="Test")
        with self.assertRaisesRegex(ValueError, "unregistered"):
            agent.validate(d, {})
        agent.validate(d, {"https://" + agent.DOMAIN + "/assessment": "p_1"})
        d.sender_address = "hr@revel8.com"
        with self.assertRaises(ValueError):
            agent.validate(d, {})

    def test_no_interactive_script_pages(self):
        page = types.SimpleNamespace(url="https://" + agent.DOMAIN + "/assessment", fields=["email"], html="<script>alert(1)</script>")
        with self.assertRaises(ValueError):
            agent.validate(types.SimpleNamespace(action="page", page=page), {})

    def test_form_submission_is_not_automatically_credentials(self):
        self.assertFalse(agent.credentials_submitted([{"type": "page.submitted", "fields": ["quiz"]}]))
        self.assertTrue(agent.credentials_submitted([{"type": "page.submitted", "fields": ["email", "password"]}]))

    def test_run_and_resume_contact_cap(self):
        session = {"scenario_id": "practice", "status": "active", "touches_used": 0, "touch_budget": 30}
        outgoing = []
        def request(method, path, body=None, key=None):
            if path == "/scenarios":
                return [{"id": "practice", "kind": "practice", "open": True,
                         "targets": [{"id": "julius", "name": "Julius"}], "objectives": []}]
            if path == "/sessions":
                self.assertEqual(body, {"scenario_id": "practice"})
                return {"session_id": "s_mock"}
            if path.endswith("/events"):
                return {"events": []}
            if path.endswith("/pages"):
                return {"page_id": "p_about"}
            if path.endswith("/messages"):
                outgoing.append(body)
                session["touches_used"] += 1
                return {"events": [], "touches_used": session["touches_used"]}
            return dict(session)
        decision = types.SimpleNamespace(action="message", reason="Mock decision", channel="email",
            sender_name="Mara Stein", sender_address="mara.stein@" + agent.DOMAIN,
            subject="Test", body="Test message", page=None)
        decision.model_dump = lambda: {k: v for k, v in vars(decision).items() if k != "model_dump"}
        client = Mock()
        client.responses.create.return_value.output_text = "Public mock research"
        plan = mock_plan()
        review = types.SimpleNamespace(approved=True, issues=[], model_dump=lambda: {"approved": True, "issues": []})
        def parse(**kwargs):
            schema = kwargs["text_format"]
            value = plan if schema == agent.Plan else review if schema == agent.Review else types.SimpleNamespace(model_dump=lambda: {"facts": []}) if schema == agent.WorkProfile else types.SimpleNamespace(questions=[]) if schema == agent.Questions else decision
            return types.SimpleNamespace(output_parsed=value)
        client.responses.parse.side_effect = parse
        with tempfile.TemporaryDirectory() as directory, patch.object(agent, "ROOT", Path(directory)), patch.object(agent, "OpenAI", return_value=client), patch.object(agent.TargetAPI, "request", side_effect=request), patch.dict(agent.os.environ, {"REVEL8_TEAM_KEY": "test", "OPENAI_API_KEY": "test"}), patch.object(sys, "argv", ["agent.py", "--max-contacts", "1"]):
            agent.main()
            agent.main()
            self.assertEqual(len(outgoing), 1)
            saved = [p for p in (Path(directory) / "runs").glob("*.json") if p.name != "current.json" and not p.name.endswith(".brief.json")]
            self.assertIsNone(json.loads(saved[0].read_text())["pending"])

    def test_conversation_start_turn_end_state(self):
        state = {"history": [], "pages": {}, "pending": {}, "active_call": None}
        op = {"kind": "call", "body": {}, "path": "/sessions/s/conversations", "key": "one"}
        agent.record_result(state, op, {"conversation_id": "c_1", "status": "answered", "persona_says": "Hello?"})
        self.assertEqual(state["active_call"]["id"], "c_1")
        turn = types.SimpleNamespace(action="say", body="Hello", channel="phone_call")
        agent.validate(turn, {}, state["active_call"])
        speech = agent.operation(turn, "s", "julius", state["active_call"])
        self.assertEqual(speech["path"], "/conversations/c_1/turns")
        self.assertEqual(speech["body"], {"say": "Hello"})
        agent.record_result(state, speech, {"turns_used": 1, "persona_says": "Who is this?", "ended": False})
        self.assertEqual(state["active_call"]["turns"], 1)
        agent.record_result(state, speech, {"turns_used": 2, "persona_says": "Bye", "ended": True})
        self.assertIsNone(state["active_call"])
        self.assertIsNone(state["pending"])

    def test_cannot_message_during_conversation(self):
        with self.assertRaisesRegex(ValueError, "Finish"):
            agent.validate(types.SimpleNamespace(action="message"), {}, {"id": "c_1"})
        with self.assertRaisesRegex(ValueError, "No conversation"):
            agent.validate(types.SimpleNamespace(action="say"), {})

    def test_call_start_cannot_silently_drop_speech(self):
        d = types.SimpleNamespace(action="call", channel="phone_call", sender_name="Test", body="Hello")
        with self.assertRaisesRegex(ValueError, "empty body"):
            agent.validate(d, {})

    def test_ignored_contact_channel_is_preserved(self):
        history = [{"request": {"kind": "message", "body": {"channel": "email", "body": "Hi"}}, "response": {"events": []}}]
        self.assertEqual(agent.ignored_contacts(history)[0]["channel"], "email")

    def exercise_sequence(self, decisions, approvals, stop_audits=(), max_contacts=1, persona_reply="No thanks"):
        def obj(**values):
            item = types.SimpleNamespace(**values)
            item.model_dump = lambda: values.copy()
            return item
        plan = mock_plan()
        decision_iter, approval_iter = iter(decisions), iter(approvals)
        stop_iter = iter(stop_audits)
        client = Mock()
        client.responses.create.return_value.output_text = "Mock research"
        def parse(**kwargs):
            schema = kwargs["text_format"]
            if schema is agent.Plan:
                value = plan
            elif schema is agent.WorkProfile:
                value = obj(facts=[])
            elif schema is agent.Questions:
                value = obj(questions=[])
            elif schema is agent.Review:
                approved = next(approval_iter)
                value = obj(approved=approved, issues=[] if approved else ["Unsupported claim"])
            elif schema is agent.StopReview:
                justified = next(stop_iter)
                value = obj(justified=justified, reason="Test stop review", untried_alternative="A coherent live chat" if not justified else "")
            elif schema is agent.Handoff:
                value = obj(requested_email=True, supporting_quote=persona_reply,
                            requested_details=["preview", "time required"], summary="Email requested")
            else:
                values = {"action": "message", "reason": "Test", "channel": "email",
                          "sender_name": "Mara Stein", "sender_address": "mara.stein@" + agent.DOMAIN,
                          "subject": "Test", "body": "Test", "page": None, "attachments": []}
                values.update(next(decision_iter))
                value = obj(**values)
            return types.SimpleNamespace(output_parsed=value)
        client.responses.parse.side_effect = parse
        status = {"scenario_id": "practice", "status": "active", "touches_used": 0, "touch_budget": 30}
        sent = []
        def request(method, path, body=None, key=None):
            if path == "/scenarios":
                return [{"id": "practice", "kind": "practice", "open": True, "targets": [{"id": "julius", "name": "Test"}], "objectives": []}]
            if path == "/sessions":
                return {"session_id": "s_test"}
            if path.endswith("/events"):
                return {"events": []}
            if method == "GET":
                return status.copy()
            if path.endswith("/pages"):
                return {"page_id": "p_about"}
            sent.append((path, body, key))
            if path.endswith("/messages"):
                status["touches_used"] += 1
                return {"events": []}
            if path.endswith("/conversations"):
                status["touches_used"] += 1
                return {"status": "answered", "conversation_id": "c_test", "persona_says": "Hello?"}
            if path.endswith("/turns"):
                return {"ended": False, "turns_used": 1, "persona_says": persona_reply, "events": []}
            return {}
        with tempfile.TemporaryDirectory() as directory, patch.object(agent, "ROOT", Path(directory)), patch.object(agent, "OpenAI", return_value=client), patch.object(agent.TargetAPI, "request", side_effect=request), patch.dict(agent.os.environ, {"REVEL8_TEAM_KEY": "test", "OPENAI_API_KEY": "test"}), patch.object(sys, "argv", ["agent.py", "--max-contacts", str(max_contacts)]):
            agent.main()
            saved = next(p for p in (Path(directory) / "runs").glob("*.json") if p.name != "current.json" and not p.name.endswith(".brief.json"))
            state = json.loads(saved.read_text())
            self.assertTrue(saved.with_suffix(".md").exists())
        return sent, state

    def test_failed_review_spends_no_contact(self):
        sent, state = self.exercise_sequence([{"body": "Unverified claim"}, {"body": "Revised"}], [False, True])
        self.assertEqual(len(sent), 1)
        self.assertEqual(sent[0][1]["body"], "Revised")
        self.assertEqual(len(state["reviews"]), 2)

    def test_call_finishes_after_contact_cap_reached(self):
        sent, state = self.exercise_sequence([
            {"action": "call", "channel": "phone_call", "body": ""},
            {"action": "say", "channel": "phone_call", "body": "Hello"},
            {"action": "end_call", "body": ""}], [True, True])
        self.assertEqual([p for p, b, k in sent], ["/sessions/s_test/conversations", "/conversations/c_test/turns", "/conversations/c_test/end"])
        self.assertIsNone(state["active_call"])
        self.assertIsNone(state["pending"])

    def test_premature_stop_is_reconsidered_without_spending_contact(self):
        sent, state = self.exercise_sequence([
            {"action": "stop", "reason": "No option"},
            {"body": "A different concrete next step"}], [True], [False])
        self.assertEqual(len(sent), 1)
        self.assertFalse(state["stop_reviews"][0]["justified"])

    def test_justified_stop_is_not_forced_to_use_contacts(self):
        sent, state = self.exercise_sequence([{"action": "stop", "reason": "No relevant approach"}], [], [True])
        self.assertEqual(sent, [])
        self.assertTrue(state["stopped"])

    def test_roles_differ_for_business_product_technical_and_employee(self):
        self.assertEqual(agent.role_profile({"role": "Co-Founder & Co-CEO, go-to-market"})["discipline"], "business")
        self.assertEqual(agent.role_profile({"role": "Co-Founder & Co-CEO, product"})["discipline"], "product")
        self.assertEqual(agent.role_profile({"role": "Co-Founder & CTO"})["discipline"], "technical")
        employee = agent.role_profile({"role": "Sales associate"})
        self.assertEqual(employee["seniority"], "employee_or_unknown")
        self.assertNotEqual(employee["counterpart_options"], agent.role_profile({"role": "Founder"})["counterpart_options"])

    def test_duplicate_event_ids_not_counted_twice(self):
        event = {"id": "e_1", "type": "link.opened"}
        history = [{"response": {"events": [event]}}, {"response": {"events": [event]}}]
        self.assertEqual(agent.outcome_summary(history)["links_opened"], 1)

    def test_plan_cannot_omit_refusal_or_other_outcome_branch(self):
        plan = mock_plan()
        agent.validate_plan(plan)
        plan.approaches[0].branches.pop()
        with self.assertRaisesRegex(ValueError, "five outcome"):
            agent.validate_plan(plan)

    def test_email_request_closes_chat_and_sends_without_extra_goodbye(self):
        sent, state = self.exercise_sequence([
            {"action": "call", "channel": "live_chat", "body": ""},
            {"action": "say", "channel": "live_chat", "body": "Would you like details?"},
            {"action": "message", "channel": "email", "body": "Here is the requested preview and timing."}],
            [True, True, True], max_contacts=2,
            persona_reply="Just send the mail with the link and details. I won't sign up from this chat.")
        self.assertEqual([p for p, b, k in sent], ["/sessions/s_test/conversations", "/conversations/c_test/turns", "/conversations/c_test/end", "/sessions/s_test/messages"])
        self.assertIsNone(state["active_call"])
        self.assertIsNone(state["pending_email"])

    def test_closed_call_cannot_generate_say_and_handoff_cannot_stop(self):
        schema, allowed = agent.decision_type({"active_call": None, "pending_email": {"summary": "Requested"}})
        self.assertIs(schema, agent.EmailHandoffDecision)
        self.assertEqual(allowed, ["page", "message"])
        self.assertNotIn("say", allowed)
        schema, allowed = agent.decision_type({"active_call": {"id": "c_1"}})
        self.assertIs(schema, agent.InsideCallDecision)
        self.assertEqual(allowed, ["say", "end_call"])

    def test_end_call_invalidates_stale_review_feedback(self):
        state = {"history": [], "pages": {}, "reviews": ["stale"], "active_call": {"id": "c_1"}}
        agent.record_result(state, {"kind": "end_call", "body": {}}, {})
        self.assertEqual(state["feedback_after"], 1)
        self.assertIsNone(state["active_call"])

    def test_handoff_can_be_recovered_after_call_already_ended(self):
        history = [{"request": {"kind": "say"}, "response": {"persona_says": "Send the details by mail."}},
                   {"request": {"kind": "end_call"}, "response": {}}]
        self.assertEqual(agent.latest_handoff_candidate(history), (0, "Send the details by mail."))
        history.append({"request": {"kind": "message", "body": {"channel": "email"}}, "response": {"events": []}})
        self.assertIsNone(agent.latest_handoff_candidate(history))

    def test_recovery_matches_exact_session_and_keeps_original(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runs = root / "runs"
            runs.mkdir()
            original = {"session": "s_requested", "history": [], "active_call": None}
            (runs / "one.json").write_text(json.dumps(original))
            (runs / "two.json").write_text(json.dumps({"session": "s_other"}))
            self.assertEqual(agent.find_saved_session(root, "s_requested"), original)
            self.assertEqual(json.loads((runs / "one.json").read_text()), original)

    def test_batch_uses_separate_practice_attempts_and_no_keys_in_arguments(self):
        with patch.dict(agent.os.environ, {"REVEL8_TEAM_KEY": "private-team", "OPENAI_API_KEY": "private-model"}), patch.object(sys, "argv", ["agent.py", "--all-targets"]), patch.object(agent.subprocess, "run", return_value=types.SimpleNamespace(returncode=0)) as run:
            agent.main()
            self.assertEqual(run.call_count, 3)
            for call, target in zip(run.call_args_list, ["julius", "tom", "robert"]):
                argv = call.args[0]
                self.assertIn("--new", argv)
                self.assertEqual(argv[argv.index("--target") + 1], target)
                self.assertNotIn("private-team", argv)
                self.assertNotIn("private-model", argv)


if __name__ == "__main__":
    unittest.main()
