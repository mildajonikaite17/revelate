# Your first revel8 AI agent

## Easiest Windows start (updated version)

Extract this ZIP to a NEW folder so your previous run remains intact. Open the
`revel8_agent` folder and double-click `START_FRESH.bat` to start a new practice
attempt, or `START_AGENT.bat` to resume this folder's current run. The launcher
finds its own folder and checks packages automatically. You do not need to find
an address bar, type `cd`, or open Command Prompt yourself.

## Where to put your information

There are TWO editable files beside `agent.py`:

- `AGENT_INSTRUCTIONS.md`: behaviour, rules, writing preferences and observed
  practice lessons. This becomes part of the model's instructions on each run.
- `TEAM_BRIEF.md`: your team's assessment concept and relevant background. This
  becomes context for research and each decision, not verified public evidence.

Open these with Notepad (right-click -> Open with -> Notepad), edit and press
Ctrl+S. Close/stop a running agent before editing, then restart it to load changes.
Put new strategy information in these files, NOT the API key prompt, a Command
Prompt command, or OpenAI's chat/playground. The Python program loads them.

This is prompting/context configuration, not fine-tuning. The model's weights do
not change. Practice runs do not automatically teach future new sessions. Add
short, reviewed lessons to AGENT_INSTRUCTIONS.md yourself. It is already seeded
with relevant ideas from your team chat and lessons from your observed attempts.
Keep secrets out of both files. Your WhatsApp export has not been included.

Restarting does not erase a stopped session's state. To TEST edited instructions
from a clean slate, use `START_FRESH.bat`. It creates one new practice session.

This starter researches one practice AI twin, chooses its next contact, registers
static assessment pages when useful, sends messages, reads reactions and adapts.
All target contact goes through the fixed revel8 simulation API. No real email is
sent and no landing page is hosted. It cannot play a clicking game, obtain real
passwords, or read submitted field values.

## Windows: first run

1. Extract the downloaded ZIP. Open the extracted `revel8_agent` folder. Make sure
   you see `agent.py` and `requirements.txt`.
2. Click File Explorer's address bar, type `cmd`, and press Enter. This opens
   Command Prompt in the correct folder.
3. Install dependencies:

   ```bat
   py -m pip install -r requirements.txt
   ```

4. Start:

   ```bat
   py agent.py
   ```

5. At `Revel8 team key (hidden):`, paste your existing revel8 key and press Enter.
   At `OpenAI API key (hidden):`, paste a separate OpenAI developer API key.
   Nothing appears while entering keys; that is expected. They are not saved.

The second key must have API access and available billing/credits. A ChatGPT
subscription and the revel8 key do not themselves configure that access. Ask the
hackathon organizers about sponsored model access before buying anything. This
version uses OpenAI's Responses API, structured output and web search. If the
organizers supply a different provider, adapt the two model calls in `agent.py`.

The agent starts a NEW practice session, rather than reusing the earlier manually
created HR session. It allows up to five contacts in total per run, including
previous launches. It can stop sooner. Public research and decisions use paid
model API calls; web search may also be billed. No evaluation sessions are used.

## What appears on screen

- Researching: reads public professional information with web search.
- Practice session: identifies this practice attempt.
- Choosing next step: the model chooses a page, message or stop.
- Sending: shows the actual outgoing message.
- EVENT / REPLY: shows what the simulation returned. An empty event list is an
  ignored contact, not a delayed response you need to wait for.
- Credential-field submission observed: password field submission was reported;
  this is observable evidence, not the final competition score.

## Continue or start over

Run the same command to resume the current run after a timeout. Pending requests
retain their body and idempotency key to avoid spending a contact twice. If a
server explicitly rejects a request with 400/422, the model gets feedback and can
change it; transient failures are retried with backoff. Sessions created just
before an unlikely creation/save crash can be orphaned, but have used no contacts.

Continue the current run with a higher TOTAL contact cap:

```bat
py agent.py --max-contacts 10
```

Start a clean practice attempt (no memory/trust carried over):

```bat
py agent.py --new --target julius
```

Other practice targets: `tom`, `robert`. On resume, the saved target is used.
Model default: `gpt-4.1`; choose another compatible model with `--model MODEL_ID`.
It must support web search and Responses structured outputs.

Stop with Ctrl+C. Do not run two copies in this folder. If a force-close leaves
`agent.lock`, first ensure the earlier process is gone, then delete that lock.
Run state, research and transcripts are saved under `runs`. These files contain
simulation conversations and should be kept private. Keys are not written there.
Source never executes AI-generated code or lets the model change the API host.

## Scope and limitations

This is a starter, not a guaranteed winning submission. It supports pages and
four message channels; calls, images, attachments and eval mode are not included.
No dashboard is needed to run it. It retains the assessment competition idea but
lets the model decide whether it fits the researched target. Domain checks force
all page/sender claims onto a separate simulated domain; domain availability and
ownership are not verified. The model may decline or stop. No guard or outcome
classifier replaces organizer review. Do not run this against real people.

Before presenting, inspect actual practice results and prepare the required
architecture page and five-minute pitch with one real simulation thread.

## Architecture

Public web research -> saved source notes -> model decision -> validated API
operation -> simulator events -> saved history -> next model decision.

## Troubleshooting

- `py` not recognized: install Python and reopen Command Prompt.
- `No module named ...`: run the dependency installation command again.
- Target API HTTP 401: check the revel8 key.
- AuthenticationError: check the separate OpenAI key.
- RateLimitError: check model credits/billing and provider rate limits.
- NotFoundError / BadRequestError: confirm your model supports the configured APIs.
- Target API HTTP 409: session ended or contacts exhausted; start a new practice run.
- Agent already running: don't launch a second copy. See lock instructions above.

Official model setup references:
https://developers.openai.com/api/docs/quickstart
https://developers.openai.com/api/docs/guides/tools-web-search
https://developers.openai.com/api/docs/guides/structured-outputs
