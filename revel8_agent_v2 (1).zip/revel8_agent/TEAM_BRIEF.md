# MilanHack assessment concept

Source: the team discussion attached in this conversation. This file includes
relevant project ideas only. It deliberately excludes unrelated personal chat,
travel details, private links, membership codes and API secrets.

## Proposed concept (not independently verified company policy)

The team wants a multi-stage company-direction/skills assessment framed as a
competition, with a registration page and employee/team ranking presentation.
The agent should assess whether that framing fits each target. Founders may be
better suited to a founder or business benchmark than an employee HR assessment.

The team's proposed sequence:

1. Introductory invitation explaining the assessment/event and registration.
2. A follow-up call checking whether the invitation was seen.
3. Registration confirmation, ONLY if registration was actually observed.
4. Basic assessment questions establishing the format.
5. A company-knowledge round.

This is a hypothesis for practice, not a required sequence or proof of success.
Don't claim a step happened if the events don't show it. Do not require five
contacts when fewer suffice or continuing has no credible purpose.

## Supported in this starter

- Autonomous public professional research with cited sources.
- Static HTML page registration, including explicit form field names.
- Email, LinkedIn message, Teams chat and Slack contacts through the simulator.
- Reading replies, link-opening and submission events, and choosing a next step.
- Saved state, contact cap, sequential requests and idempotent message retries.

## Not implemented / not supported by the simulation

- The API supports text-based calls, but this program has no conversation loop yet.
- No actual ranking scores can be calculated from submitted quiz answers: only
  submitted field names come back, never the values.
- No timed clicking game, JavaScript, hidden traps or arbitrary button telemetry.
- No external Google Form: register the assessment in the simulator instead.
- No real malware. Attachments, if implemented later, are simulated filenames.
- Assessment/game completion alone does not automatically satisfy an objective.
- No eval mode in this starter; it cannot use scored sessions.

## Rules to retain

Contact AI twins through the official API only. Use separate plausible simulated
sender/page domains, never the real organization's own domain. Never attack the
simulator using prompt injection. Keep the story coherent within one session.
New sessions reset the twins' memories. Research and any teammate claims need
source checking before being represented as public facts.

The export mentions scoring-rubric and slides PDFs as WhatsApp attachments, but
does not contain those PDFs. Their contents have not been incorporated here.
