"""Offline checks. No keys or network calls. SDK/schema integration needs a live run."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import Mock, patch

# Minimal import stand-ins only if dependencies aren't installed; core logic below
# uses plain objects. These tests do not claim to validate the OpenAI SDK/schema.
for name, attrs in {
    "requests": {"Timeout": type("Timeout", (Exception,), {}),
                 "ConnectionError": type("ConnectionError", (Exception,), {}), "request": Mock()},
    "openai": {"OpenAI": Mock()},
    "pydantic": {"BaseModel": type("BaseModel", (), {}), "ConfigDict": dict},
}.items():
    if importlib.util.find_spec(name) is None:
        mod = types.ModuleType(name)
        mod.__dict__.update(attrs)
        sys.modules[name] = mod

import agent


class AgentTests(unittest.TestCase):
    def test_editable_material_is_loaded_from_agent_folder(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "AGENT_INSTRUCTIONS.md").write_text("Keep messages short", encoding="utf-8-sig")
            (root / "TEAM_BRIEF.md").write_text("Assessment concept", encoding="utf-8")
            loaded = agent.load_team_material(root)
            self.assertEqual(loaded["AGENT_INSTRUCTIONS.md"], "Keep messages short")
            self.assertEqual(loaded["TEAM_BRIEF.md"], "Assessment concept")

    def test_retry_preserves_body_and_key(self):
        api = agent.TargetAPI("test-key")
        response = Mock(status_code=200)
        response.json.return_value = {"touches_used": 1}
        with patch.object(agent.requests, "request", side_effect=[agent.requests.Timeout(), response]) as send, patch.object(agent.time, "sleep"):
            self.assertEqual(api.request("POST", "/sessions/s/messages", {"body": "hello"}, "same-key"), {"touches_used": 1})
            self.assertEqual(send.call_args_list[0], send.call_args_list[1])
            self.assertFalse(send.call_args.kwargs["allow_redirects"])

    def test_invalid_body_not_retried(self):
        response = Mock(status_code=422)
        with patch.object(agent.requests, "request", return_value=response) as send, patch.object(agent.time, "sleep"):
            with self.assertRaisesRegex(RuntimeError, "HTTP 422"):
                agent.TargetAPI("test-key").request("POST", "/sessions/s/messages", {}, "key")
            self.assertEqual(send.call_count, 1)

    def test_domain_and_registration(self):
        d = types.SimpleNamespace(action="message", sender_address="hr@" + agent.DOMAIN,
                                  body="See https://" + agent.DOMAIN + "/assessment")
        with self.assertRaisesRegex(ValueError, "unregistered"):
            agent.validate(d, {})
        agent.validate(d, {"https://" + agent.DOMAIN + "/assessment": "p_1"})
        d.sender_address = "hr@revel8.com"
        with self.assertRaises(ValueError):
            agent.validate(d, {})

    def test_no_interactive_script_pages(self):
        page = types.SimpleNamespace(url="https://" + agent.DOMAIN + "/assessment", fields=["email"], html="<script>alert(1)</script>")
        with self.assertRaises(ValueError):
            agent.validate(types.SimpleNamespace(action="page", page=page), {})

    def test_form_submission_is_not_automatically_credentials(self):
        self.assertFalse(agent.credentials_submitted([{"type": "page.submitted", "fields": ["quiz"]}]))
        self.assertTrue(agent.credentials_submitted([{"type": "page.submitted", "fields": ["email", "password"]}]))

    def test_run_and_resume_contact_cap(self):
        session = {"scenario_id": "practice", "status": "active", "touches_used": 0, "touch_budget": 30}
        outgoing = []
        def request(method, path, body=None, key=None):
            if path == "/scenarios":
                return [{"id": "practice", "kind": "practice", "open": True,
                         "targets": [{"id": "julius", "name": "Julius"}], "objectives": []}]
            if path == "/sessions":
                self.assertEqual(body, {"scenario_id": "practice"})
                return {"session_id": "s_mock"}
            if path.endswith("/events"):
                return {"events": []}
            if path.endswith("/messages"):
                outgoing.append(body)
                session["touches_used"] += 1
                return {"events": [], "touches_used": session["touches_used"]}
            return dict(session)
        decision = types.SimpleNamespace(action="message", reason="Mock decision", channel="email",
            sender_name="Test", sender_address="test@" + agent.DOMAIN,
            subject="Test", body="Test message", page=None)
        client = Mock()
        client.responses.create.return_value.output_text = "Public mock research"
        client.responses.parse.return_value.output_parsed = decision
        with tempfile.TemporaryDirectory() as directory, patch.object(agent, "ROOT", Path(directory)), patch.object(agent, "OpenAI", return_value=client), patch.object(agent.TargetAPI, "request", side_effect=request), patch.dict(agent.os.environ, {"REVEL8_TEAM_KEY": "test", "OPENAI_API_KEY": "test"}), patch.object(sys, "argv", ["agent.py", "--max-contacts", "1"]):
            agent.main()
            agent.main()
            self.assertEqual(len(outgoing), 1)
            saved = [p for p in (Path(directory) / "runs").glob("*.json") if p.name != "current.json"]
            self.assertIsNone(json.loads(saved[0].read_text())["pending"])


if __name__ == "__main__":
    unittest.main()
