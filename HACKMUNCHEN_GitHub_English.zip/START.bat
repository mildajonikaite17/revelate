@echo off
setlocal DisableDelayedExpansion
title HACKMUNCHEN - revel8 Practice
cd /d "%~dp0"
set "HACKMUNCHEN_SCRIPT=%~dp0practice-client.ps1"
if not exist "%HACKMUNCHEN_SCRIPT%" (
  echo Cannot find practice-client.ps1. Extract all files from the ZIP into the same folder.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -STA -Command "try { $taskSource = [IO.File]::ReadAllText($env:HACKMUNCHEN_SCRIPT, [Text.Encoding]::UTF8); ([scriptblock]::Create($taskSource)).Invoke() } catch { Write-Host 'The application could not start.'; Write-Host $_.Exception.Message }"
echo.
pause
endlocal
