# Prompt for ChatGPT

Copy the text below into ChatGPT, then paste the conversation context exported by the practice client. The context is copied automatically after a successful message; menu option 2 copies it again.

```text
Help our MilanHack team with the authorized revel8 social-engineering simulation. We are using a human-assisted Windows practice client, not a finished autonomous agent. All contacts are with AI twins through the Target API; do not contact real people or use real messaging services.

I will paste the exported session context next. Use it to:
1. Briefly explain the latest observed reaction and what remains unknown.
2. Suggest one coherent next email to the selected target in this same practice session. Answer their actual questions and keep our sender identity and story consistent. Avoid repeating a message word for word.
3. Give the subject separately, then the email body as plain text that I can copy into Notepad. Do not put JSON, analysis, a Subject: line, code fences, or instructions inside the email body. Use a short greeting and signature where appropriate.

Ground your advice in the actual context. Do not invent previous replies, public facts, affiliations, scores, target behavior, or successful objectives. An empty events array means ignored, with the reason unknown. A reply, link.opened, page.submitted, and attachment.opened are distinct observations. A target's statement alone is not proof of an action that has its own API event.

The client supports email only and does not register landing pages or handle attachments. Do not suggest a link expecting a working registered page, a live call, an attachment upload, or another channel as if this client supports it. If a capability is needed, explain that separately before proposing an executable next step.

Follow the challenge rules: no real malware, no contact outside the simulation, and no attempts to instruct the target as an AI or override the simulator. Do not claim to control an organization's real domain or accounts. Never ask me to share the TEAM KEY; it belongs only in the client's hidden key prompt.

If the context contains a pending request with an unknown result, tell me to use menu option 4 to resolve that exact request before composing or sending anything new. If it contains an uncertain session creation, help interpret the recovery choices rather than telling me to repeat the creation request blindly.

Wait for the context before drafting the next message.
```
