# revel8 practice client

A Windows console for the MilanHack team to contact **simulated AI twins** through the revel8 Target API. You write the messages; ChatGPT can help you interpret replies and prepare the next one.

This is a **human-assisted practice tool**, not the finished autonomous hackathon agent. It uses the organizer's **TEAM KEY only**. You do not need Python, an OpenAI API key, or an OpenAI developer account. Windows PowerShell 5.1 is built into Windows 10 and 11.

## Download and start

1. On this GitHub repository, click **Code → Download ZIP**.
2. Right-click the downloaded ZIP and choose **Extract All**. Open the extracted folder; do not run the program from inside the ZIP.
3. Double-click **START.bat**. Keep `START.bat` and `practice-client.ps1` in the same folder.
4. At the **TEAM KEY** prompt, paste the key provided by the organizers and press **Enter**. The characters stay hidden while you paste; this is normal.
5. On your first launch, press **Enter** to select the default target, **Julius**, then **Enter** to create a new **practice** session.

When you reopen the program with the same key on the same laptop, it resumes your saved session. It does not automatically start a fresh session each time.

## Send your first message

1. Choose **1** in the console menu.
2. Press **Enter** to keep the sender name **MilanHack**.
3. Press **Enter** to keep the suggested subject, or type your own subject on one line.
4. Notepad opens the email body. Keep or edit the suggested message. Put **only the message text** here, including any greeting and signature.
5. In Notepad, press **Ctrl+S** to save. Return to the console and press **Enter**.
6. Read the preview. Press **Enter** again to send it **inside the simulator**. Type anything else to cancel.
7. Wait for the response. The simulator may take around 90 seconds; the client allows **120 seconds** per request.

The console shows the actual response and events. It then copies a conversation context to your clipboard. Return to ChatGPT and press **Ctrl+V** to paste it.

For help preparing the next message, first paste [this ChatGPT prompt](docs/CHATGPT_PROMPT.md), then paste the exported context. Review ChatGPT's suggestion before sending it.

## Which text goes where?

| Input | Where it goes | Example |
|---|---|---|
| Organizer's TEAM KEY | Hidden **TEAM KEY** prompt in the console | Paste your team's key; never put it in a message or GitHub. |
| Menu choice | Console menu | Type `1` to compose a message. |
| Sender name | Console's sender-name prompt | `MilanHack`, or Enter to keep it. |
| Email subject | Console's subject prompt | `revel8 - workforce risk processes` |
| Email body | Notepad, then **Ctrl+S** | `Hi Julius,` followed by your message and signature. |
| Send confirmation | Console after the preview | Enter sends; any other text cancels. |
| Conversation context | ChatGPT chat box | Paste the whole exported context with Ctrl+V. |

The subject and body are separate. For example:

**Subject, typed in the console:** `revel8 - workforce risk processes`

**Body, saved in Notepad:**

```text
Hi Julius,

I am comparing how teams turn social-engineering risk signals into action. revel8's focus on workforce risk caught my attention. How does your current internal triage process work, and which team owns the handoff from a reported incident to a response?

Best,
MilanHack
```

A copy of this body is available in [examples/first-message.txt](examples/first-message.txt).

For a follow-up, choose **1** again and replace the placeholder in Notepad with **only the next email body**. Do not paste ChatGPT's explanation, JSON, a `Subject:` line, or Markdown code fences into the body. Enter the proposed subject separately in the console.

## Menu

| Option | Action |
|---|---|
| **1** | Compose, preview, and send an email in the current practice session. |
| **2** | Refresh the session, copy its context again, and open the context file. |
| **3** | Choose another AI twin in the same session. |
| **4** | Retry the saved pending message, or recover an uncertain session creation. |
| **5** | Explicitly start a new practice session. This resets the twins' memory for that new session. |
| **0** | Exit and keep local state for the next launch. |

An empty `events` array means the target ignored that message. It does not tell you why. A reply, a link opening, and a submitted form are different observations; the client does not invent success scores.

## What the client handles

You supply the sender name, subject, and body. The client handles authentication, JSON formatting, session IDs, and message IDs. For example, it sends this kind of payload to `POST /v1/sessions/{session_id}/messages`:

```json
{
  "to": "julius",
  "channel": "email",
  "from": { "name": "MilanHack" },
  "subject": "revel8 - workforce risk processes",
  "body": "Hi Julius,\n\nHow does your current internal triage process work?\n\nBest,\nMilanHack"
}
```

The TEAM KEY is added to the HTTP Authorization header automatically; it is **not** part of that JSON. Before sending a message, the client saves its exact request and an idempotency key so an interrupted request can be retried safely.

## Working as a team

The repository shares **code**, not conversation history. Each laptop keeps its own local state and normally creates its own practice session. Reopening on that laptop resumes that session.

Using the same TEAM KEY shares the team's server-side sessions, logs, and API rate limits. A session's touch budget belongs to that server session, so teammates using the same session ID consume the same budget. Coordinate your runs and avoid sending or editing concurrently in the same server session. The local single-instance lock does not coordinate different laptops.

Local state, drafts, context exports, and archived session transcripts are stored under:

```text
%LOCALAPPDATA%\HACKMUNCHEN_Practice\<team-fingerprint>
```

The TEAM KEY is requested at launch and is not saved in this folder. Do not commit credentials, transcripts, context exports, or state files to GitHub. Treat practice transcripts as team material.

## Troubleshooting

| What you see | What to do |
|---|---|
| Script file missing, or launching from the ZIP fails | Use **Extract All**, then run `START.bat` from the extracted folder. Keep both program files together. |
| Nothing appears when pasting the key | This is intentional. Paste the key and press Enter. |
| Timeout or interrupted connection | The message may already have reached the simulator. Use **4** to retry the saved request with the same idempotency key. Do not make a replacement message or new session just to retry it. |
| **HTTP 401** | Close the client and reopen it with the organizer's exact TEAM KEY. If it persists, ask the organizers to check the key. |
| **HTTP 403** | Access was refused or the scenario is closed. This does not by itself prove the key is wrong. |
| **HTTP 429** | Wait a minute. For a pending message, use **4**; if the program stopped during startup, reopen it. Coordinate with teammates using the same key. |
| Uncertain session creation | Use **4** to inspect existing practice sessions. The client does not automatically repeat session creation. |
| Clipboard did not work | Choose **2** and copy the exported context file's contents manually. |
| No touches remain, or the session has ended | Use **5** when you intentionally want a fresh practice session. |

## Scope and official documentation

This client supports **practice email messages only**. It does not open evaluation sessions, autonomously research targets, generate replies, host landing pages, or implement live calls. The hackathon's final agent requires more automation than this practice console provides.

All contacts go to AI twins through the Target API. Do not send challenge messages to the real people or their real accounts. Follow the organizer's rules; messages that instruct the twin as an AI are prohibited.

- [Official Target API documentation](https://target-api.apps.01.cf.eu01.stackit.cloud)
- [Markdown documentation for coding agents](https://target-api.apps.01.cf.eu01.stackit.cloud/docs.md)
- API base: `https://target-api.apps.01.cf.eu01.stackit.cloud/v1`

## Validation

Static checks cover the English translation, unchanged request/session logic, example JSON, relative documentation links, and Windows line endings. This version has not been executed on Windows in the preparation environment; complete a practice run on your laptop before relying on it as a team.
